var showCourse = function (data) {
    for (var i = 0; i < data.length; i++) {
        console.log(data[i].courseName + "\t" + data[i].duration);
    }
};
var courseRecords = [
    { courseName: "Python", duration: "20 days", courseMode: "online", certification: true },
    { courseName: "SQL", duration: "30 days", courseMode: "blended", certification: false },
    { courseName: "JavaScript", duration: "40 days", courseMode: "classroom", certification: true },
    { courseName: "Angular", duration: "35 days", courseMode: "online", certification: true },
    { courseName: "Selenium", duration: "20 days", courseMode: "classroom", certification: false }
];
showCourse(courseRecords);
//update course duration to more 10 days if it is certification course
var updated = courseRecords.map(function (item, i) {
    if (item.certification) {
        var days = Number(item.duration.split(" ")[0]);
        item.duration = days + 10 + " days";
    }
    return item;
});
console.log("Updated Courses");
console.log(updated);
//filter certification courses and show them creating new array
var certificationCourses = courseRecords.filter(function (item, index) {
    if (item.certification == true)
        return item;
});
console.log("Certification Courses are,");
console.log(certificationCourses);
/*
for(var i=0;i<courseRecords.length;i++)
{
    if(courseRecords[i].certification){
        let days = Number(courseRecords[i].duration.split(" ")[0]);
        console.log(days+10+" days");
    }
}

*/ 
