package org.example;

public class Runner {
    public static void main(String args[]){
        Stack stack= new Stack();
        stack.push(7);
        stack.push(8);
        stack.push(6);
        stack.push(5);
        stack.push(9);
stack.pop();
        stack.show();
        System.out.println(stack.peek());
        System.out.println(stack.size());

//        stack.push(3);


    }
}
