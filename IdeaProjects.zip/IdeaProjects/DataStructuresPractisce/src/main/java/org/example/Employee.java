package org.example;
//
//public record Employee {
//}
