package org.example;

class Animal{
    void eat(){System.out.println("eating...");}
}
class Dog extends Animal{
    void eat(){System.out.println("eating bread...");}
    void bark(){System.out.println("barking...");}
    void work(){
        super.eat();}


//        void eat()System.out.println("eating bread. in child..");
//
////        bark();
//    }
}
class TestSuper2{
    public static void main(String args[]){
        Animal d=new Animal();
        d.eat();
    }}