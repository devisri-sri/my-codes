package org.example;

public class QueueRunner {
    public static void main(String args[]){
    Queue q= new Queue();
    q.enQueue(8);
        q.enQueue(1);
        q.enQueue(4);
        q.enQueue(3);
        q.deQueue();
        q.enQueue(10);
        q.show();
}
}