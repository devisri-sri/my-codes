package org.example;


public class Main {
    public static void main(String[] args) {
        LinkedList list;
        list = new LinkedList();
        list.insert(2);
        list.insert(4);
list.insertAtStart(25);
list.insertAt(2,56);
list.insert(67);
        list.show();
    }
}