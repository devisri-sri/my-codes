import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

class Employee {
    private int empId;
    private String name;
    private String city;

    public Employee(int empId, String name, String city) {
        this.empId = empId;
        this.name = name;
        this.city = city;
    }

    public int getEmpId() {
        return empId;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return empId == employee.empId && name.equals(employee.name) && city.equals(employee.city);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empId, name, city);
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", name='" + name + '\'' +
                ", city='" + city + '\'' +
                '}';
    }
}

public class Main {
    public static void main(String[] args) {
        String filePath = "C:\\Users\\DBOLLAM\\Downloads\\csvtojson.txt"; // Path to your file
        List<Employee> employees = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                int empId = Integer.parseInt(parts[0]);
                String name = parts[1];
                String city = parts[2];
                employees.add(new Employee(empId, name, city));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Remove duplicates using Set
//        Set<Employee> uniqueEmployees = new HashSet<>(employees);

//         Sort employees based on empId
        employees.stream().distinct()
                .sorted(Comparator.comparingInt(Employee::getEmpId))
                .collect(Collectors.toList()).forEach(System.out::println);

        Collections.sort(employees,Comparator.comparingInt(Employee::getEmpId));
        employees.forEach(System.out::println);
        // Print sorted and unique employees
//        for (Employee emp : sortedEmployees) {
//            System.out.println(emp);

    }
}
