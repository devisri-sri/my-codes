package java8Streams;

public class RemoveElement {
    public static void main(String [] args){
        int nums[]={3,4,5,6,2,7,8,6,6,8};
        int val=6;
        int v_size=0;
        for(int i=0;i<nums.length;i++){
            if(nums[i]!=val){
                nums[v_size]= nums[i];
                v_size++;
            }
        }
        System.out.println( v_size);

    }
}
