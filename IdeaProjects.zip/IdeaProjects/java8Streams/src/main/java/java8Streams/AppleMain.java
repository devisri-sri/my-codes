package java8Streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AppleMain {
    public static void main(String args[]){
        List<Apple> list= new ArrayList<>();
        list .add(new Apple("pink",12,78900));
        list .add(new Apple("Red",6,100000));
        list .add(new Apple("Yellow",2,34567));
        list .add(new Apple("Red",9,5647));
//list needs to be added as per size
list.stream().sorted(Comparator.comparing(Apple::getSize)).forEach(System.out::println);
        list.stream().sorted(Comparator.comparing(Apple::getPrice)).forEach(System.out::println);
        Map<String,List<Apple>> map= list.stream().collect(Collectors.groupingBy(Apple::getColor));
        System.out.println(map);

    }
}
