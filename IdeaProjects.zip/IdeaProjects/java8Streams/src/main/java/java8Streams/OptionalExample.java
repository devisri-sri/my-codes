package java8Streams;

import java.util.Optional;

public class OptionalExample {
    public static void main(String args[]) {
        String str = "";
        Optional<String> optional = Optional.ofNullable(str);
        if (optional.isPresent()) {
            System.out.println("value is present"+optional.get());
        } else {
            System.out.println("no value present"+optional.orElse("default"));

        }
        //java 8
        Optional.ofNullable(str).ifPresent(
                s -> System.out.println("Value is present: " + s));
        //java 9 & above
//        Optional.ofNullable(str).ifPresentOrElse(
//                s -> System.out.println("Value is present: " + s),
//                () -> System.out.println("Value is absent")
//        );
    }
}
