package java8Streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class copart {
    public static void main(String args[]) {
        List<Apple> list = new ArrayList<>();
        list.add(new Apple("pink", 12, 78900));
        list.add(new Apple("Red", 6, 100000));
        list.add(new Apple("Yellow", 2, 34567));
        list.add(new Apple("Red", 9, 5647));
        list.add(new Apple("pink", 12, 78090));

        list.stream().sorted(Comparator.comparing(Apple::getSize).thenComparing(Apple::getPrice)).
    forEach(System.out::println);
    }

}