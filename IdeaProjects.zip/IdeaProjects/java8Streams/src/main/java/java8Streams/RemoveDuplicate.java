package java8Streams;

import java.util.HashSet;
import java.util.Set;

public class RemoveDuplicate {
    public static void main(String args[]){
        int nums[]={3,4,5,6,2,7,8,6,6,8};

Set<Integer> set= new HashSet<>();
for(int num:nums){
    set.add(num);
}
        System.out.println( set);
int j=0;
for(int num:set){
    nums[j++]=nums[j];
}
        for(int num:nums){
            System.out.println( num);
        }
        System.out.println( set.size());

}
    }
