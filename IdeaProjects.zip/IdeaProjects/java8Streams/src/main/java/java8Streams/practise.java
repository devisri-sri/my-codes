package java8Streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class practise {
    public static void main(String args[]) {
        int a[] = {6, 7, 8};
        int b[] = {3, 4, 1, 6};
        int c[] = new int[10];
        c = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).distinct().sorted().toArray();
        System.out.println(Arrays.toString(c));

        List<Integer> num = Arrays.asList(4, 6, 2, 3, 1);
       int maxNum= num.stream().map(n -> n * 2).max(Integer::compare).get();
        System.out.println(maxNum);
    }
}
