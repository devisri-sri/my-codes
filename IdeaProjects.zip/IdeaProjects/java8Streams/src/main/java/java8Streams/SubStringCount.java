package java8Streams;

public class SubStringCount {
    public static int countSubstring(String string, String subString) {
        int count = 0;
        int index = 0;
        while ((index = string.indexOf(subString, index)) != -1) {
            System.out.println(string.indexOf(subString, index));
            count++;
            index += 1;
        }
        return count;
    }

    public static void main(String[] args) {
        String givenString = "ababababa";
        String subString = "aba";
        int result = countSubstring(givenString, subString);
        System.out.println("The sub string '" + subString + "' appears " + result + " times in the given string.");
    }
}
