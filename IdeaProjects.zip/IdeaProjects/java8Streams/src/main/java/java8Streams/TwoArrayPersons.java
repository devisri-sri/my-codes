package java8Streams;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TwoArrayPersons {
    public static void main(String args[]) {
        String [][]persons={{"Alice","28","female"},
                {"Bob","28","male"},
                {"charlie","30","female"},
                {"akka","22","female"}};
        Map<String, List<String>>map= Stream.of(persons).
                filter(p->Integer.parseInt(p[1])>25)
                .collect(Collectors.groupingBy(p->p[2],Collectors.mapping(p->p[0],Collectors.toList())));
        System.out.println(map);
    }

}