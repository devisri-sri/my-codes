package java8Streams;

public class DuplicateDel {
    public static void main(String args[ ]) {
        int nums[] = {3, 4, 5, 6, 1, 78, 3, 3, 4, 4,6,2};
        int index = 1;
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] != nums[i + 1]) {
                nums[index++] = nums[i + 1];
            }
        }
System.out.println(index);
    }
}