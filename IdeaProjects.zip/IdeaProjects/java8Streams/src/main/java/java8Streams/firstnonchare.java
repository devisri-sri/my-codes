package java8Streams;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static jdk.nashorn.internal.objects.NativeArray.forEach;

public class firstnonchare {
    public static void main(String args[]) {
//        String str= "abgtgyuiab";
//        Map<Character,Long> map= str.chars().mapToObj(c->(char)c)
//                .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()));
//      map.entrySet().stream().filter(e->e.getValue()>1).skip(1).limit(1).map(Map.Entry::getKey)
//              .forEach(System.out::println);

        String words = "hello amma, Hello akka";

        String str[] = words.split("\\s");
        Map<String, Integer> map = new HashMap<>();

        for (String word : str) {
            String low = word.toLowerCase();
//            System.out.println(word);
            map.put(low, map.getOrDefault(low, 0) + 1);
        }
        map.entrySet().stream().forEach(System.out::println);
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry);
        }


        List<Integer> list = Arrays.asList(12, 11, 13);
        int sum = list.stream().reduce(0, Integer::sum);
        System.out.println(sum);
    }


}