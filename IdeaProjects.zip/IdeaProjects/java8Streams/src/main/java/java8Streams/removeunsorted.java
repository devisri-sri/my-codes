package java8Streams;

import java.util.HashSet;
import java.util.Set;

public class removeunsorted {
    public static void main(String args[]){
        int nums[]={2,5,7,8,9,8,3,2,5,5,5};
        Set<Integer> set = new HashSet<>();
        int index=0;
        for (int i = 0; i < nums.length; i++) {
            // If the current element is not in the set, it's a unique element
            if (!set.contains(nums[i])) {
                set.add(nums[i]); // Add it to the set
                nums[index++] = nums[i]; // Copy it to the next available position in the array
            }
        }
        for (int i = 0; i < index; i++) {
            System.out.println(nums[i]);
}}}
