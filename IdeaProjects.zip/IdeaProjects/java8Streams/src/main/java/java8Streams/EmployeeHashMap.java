import java8Streams.Employee;

import java.util.HashMap;
import java.util.Map;

public class EmployeeHashMap {
    private Map<Employee, String> map;

    public EmployeeHashMap() {
        map = new HashMap<>();
    }

    // Method to add an employee to the map
    public void addEmployee(Employee employee, String value) {
        map.put(employee, value);
    }

    // Method to get the value associated with an employee
    public String getValue(Employee employee) {
        return map.get(employee);
    }

    // Method to print all key-value pairs in the map
    public void printAll() {
        for (Map.Entry<Employee, String> entry : map.entrySet()) {
            System.out.println("Employee: " + entry.getKey().getEmpId() + ", Value: " + entry.getValue());
        }
    }

    public static void main(String[] args) {
        EmployeeHashMap employeeHashMap = new EmployeeHashMap();

        // Adding employees to the map
        Employee emp1 = new Employee(1001, "John");
        employeeHashMap.addEmployee(emp1, "Value1");

        Employee emp2 = new Employee(1002, "Alice");
        employeeHashMap.addEmployee(emp2, "Value2");

        Employee emp3 = new Employee(1001, "John Updated");
        employeeHashMap.addEmployee(emp3, "Value3"); // This should override the value for emp1

        // Printing all key-value pairs
        employeeHashMap.printAll();

        // Getting value for an employee
        System.out.println("Value for emp1: " + employeeHashMap.getValue(emp1)); // Should print "Value3"
    }
}
