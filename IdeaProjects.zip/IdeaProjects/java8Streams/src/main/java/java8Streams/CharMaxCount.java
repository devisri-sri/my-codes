package java8Streams;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CharMaxCount {
    public static void main(String args[]){
        String str="ABCBCBAAAAA";
        String input="pplesrlul";
//        Map.Entry<Character,Integer> count=str.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),
//                Collectors.counting())).entrySet().stream().max(Map.Entry.comparingByValue()).orElse(null);
        Map.Entry<Character, Long> maxEntry = str.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);

        Character mostCommonCharacter = maxEntry != null ? maxEntry.getKey() : null;
        Long highestCount = maxEntry != null ? maxEntry.getValue() : null;
System.out.println(mostCommonCharacter);
        Map<Character,Long> count=input.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(Function.identity(),
               LinkedHashMap::new, Collectors.counting()));
        count.entrySet().stream().forEach(System.out::println);
//        char c=count.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).get();
//        System.out.println(c);
    }}
