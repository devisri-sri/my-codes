package leetcode;

public class ValidPalindrome {
    public static void main(String args[]){
        String s= "A man, a plan, a canal: Panama";
//     String str=  s.toLowerCase();
//     StringBuilder sb= new StringBuilder();
//     for(char c:str.toCharArray()){
//         if(Character.isLetterOrDigit(c)){
//             sb.append(c);
//         }
//     }
//     String org=sb.toString();
//     String rev= sb.reverse().toString();
//            System.out.println(org.equals(rev));

        String str= s.replaceAll("[^a-zA-Z0-9]","").toLowerCase();
        System.out.println(str);
        Boolean flag=false;
        if(str.isEmpty() || str.length()==1){
            flag=true;
        }
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)==str.charAt(str.length()-i-1)){
                    flag= true;
                }else{
                    flag=false;
                    break;
                }
            }
        System.out.println(flag);
            }
        }

