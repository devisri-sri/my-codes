package leetcode;
public class MinSubArrayIndex {
        public static void main(String args[]) {
            int nums[] = {2,3,1,2,4,3};
            int target = 7, left = 0, right = 0, sum = 0, minLength = Integer.MAX_VALUE;
            int start = -1, end = -1; // variables to store start and end indices of the subarray
            for (right = 0; right < nums.length; right++) {
                sum += nums[right];
                while (sum >= target) {
                    if (right - left + 1 < minLength) {
                        minLength = right - left + 1;
                        start = left; // update start index
                        end = right;}
                    sum -= nums[left];
                    left++;}}
            if (start != -1 && end != -1) {
                for (int i = start; i <= end; i++) {
                    System.out.print(nums[i] + " "); // Print elements of the subarray
                }
                System.out.println();
            } else {
                System.out.println("No subarray satisfies the condition.");
            }
        }
    }




