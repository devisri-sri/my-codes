package leetcode;

public class MajorityElement {
    public static void main(String args[]) {
        int nums[] = {9,2,2,3,6,7,6,6,2,2};
        int count = 0;
        int cand = 0;
        for (int i = 0; i < nums.length; i++) {
            if (count == 0) {
                cand =nums[i];
            }
            if(cand==nums[i]) {
                count++;
            }
            else{
                count--;
            }
        }
        System.out.println(cand);
    }
}
