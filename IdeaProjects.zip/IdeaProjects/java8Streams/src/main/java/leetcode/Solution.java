
import java.util.Scanner;

class Solution {

    static String removeConsecutiveDuplicates(String input)
    {
        if (input == null || input.length() <= 1) {
            return input;
        }

        StringBuilder sb = new StringBuilder();
        char prevChar = input.charAt(0);
        sb.append(prevChar);

        // Iterate through the input string starting from the second character
        for (int i = 1; i < input.length(); i++) {
            char currentChar = input.charAt(i);
            // If the current character is different from the previous one, append it to the result
            if (currentChar != prevChar) {
                sb.append(currentChar);
                prevChar = currentChar;
            }
        }

        return sb.toString();
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        String ans = removeConsecutiveDuplicates(input);
        System.out.println(ans);
    }
}