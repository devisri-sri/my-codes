package leetcode;

public class Anagaram {
    public  static void main(String args[]){
        String s="eat";
        String t= "att";
        int freq[]= new int[26];
        if(s.length()!= t.length()){
            System.out.println(false);
        }
        for(int i=0;i<s.length();i++){
            freq[s.charAt(i)-'a']++;
            freq[t.charAt(i)-'a']--;
        }
        for(int c:freq){
            if(c!=0){
                System.out.println(false);
            }
        }
        System.out.println(true);


    }
}
