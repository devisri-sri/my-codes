package leetcode;

public class SubSequence {
    public static void main(String args[]){
        String s="adbc";
        String t="ahbgdc";
        int i=0;
        for(int j=0;j<t.length();j++){
            if(i<s.length() && s.charAt(i)==t.charAt(j)){
                i++;
            }
        }


        System.out.println(i==s.length());
    }
}
