package leetcode;

public class MinSizeSaubArray {

    public static void main(String args[]) {
        int nums[] = {1, 2, 1, 3, 1,1};
        int target = 7, left = 0, right = 0, sum = 0, minLength = Integer.MAX_VALUE;
        for (right = 0; right < nums.length; right++) {
            sum += nums[right];
            while (sum >= target) {
                minLength = Math.min(minLength, right - left + 1);
                sum -= nums[left];
                left++;
            }

        }
        System.out.println(minLength == Integer.MAX_VALUE ? 0 : minLength);

    }
}

