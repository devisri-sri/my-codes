package leetcode;

public class UpperCse {
    public static void main(String args[]){
        String str="GOogle";

        if(str.charAt(0)==str.toUpperCase().charAt(0) && str.charAt(1)==str.toUpperCase().charAt(1)){
            System.out.println("is upper");
        }
        else{
        System.out.println("is not upper");
    }}
}
