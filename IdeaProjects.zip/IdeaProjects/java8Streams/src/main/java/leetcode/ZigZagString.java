package leetcode;
import java.util.HashMap;
public class ZigZagString {
    public static void main(String[] args) {
        String s = "PAYPALISHIRING";
        int numRows = 3;
        System.out.println(conversion(s,numRows));
    }
    public static String conversion(String s, int numRows) {
        if (numRows == 1) {
            return s;}
        HashMap< Integer,StringBuilder> hm = new HashMap<>();
        Boolean incr = true;
        int pos = 0;
        for (char c : s.toCharArray()) {
            if (pos == numRows) {
                incr = false;
            } else if (pos == 1) {
                incr = true;
            }
            if (incr) {
                pos++;
            } else {
                pos--;
            }
            if(!hm.containsKey(pos)){
                hm.put(pos,new StringBuilder());
            }
            hm.get(pos).append(c);
        }
        StringBuilder res= new StringBuilder();
        for(int i :hm.keySet()){
            res.append(hm.get(i));
        }
        return res.toString();
    }
}
