package leetcode;

import java.util.Arrays;

public class anagram {
    public static void main(String args[]){
        String s1="anagram";
        String s2= "naamarg";
        System.out.println(anagram.isAnagram(s1,s2));

    }
    public static boolean isAnagram(String s1,String s2){
        if(s1.length()!=s2.length()){
            return false;
        }
        char[] s1Chars = s1.toCharArray();
        char[] s2Chars = s2.toCharArray();

        Arrays.sort(s1Chars);
        Arrays.sort(s2Chars);

        String sortedS1 = new String(s1Chars);
        String sortedS2 = new String(s2Chars);

        System.out.println(sortedS1.equals(sortedS2));
        int [] freq= new int[26];
        for(int i=0;i<s1.length();i++){
            freq[s1.charAt(i)-'a']++;
            freq[s2.charAt(i)-'a']--;
        }
        for(int count:freq){
            if(count!=0){
                return false;
            }
        }
        return true;
    }
}
