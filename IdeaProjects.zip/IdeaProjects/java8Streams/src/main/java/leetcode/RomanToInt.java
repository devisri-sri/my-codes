package leetcode;
import java.util.HashMap;
import java.util.Map;
public class RomanToInt {
    public static void main(String args[]){
        Map<Character,Integer> map=new HashMap<>();
        map.put('I',1);
        map.put('V',5);
        map.put('X',10);
        map.put('L',50);
        map.put('C',100);
        map.put('D',500);
        map.put('M',1000);
       String str="LVIII";
       int value=0;
       char[] s=str.toCharArray();
       for(char c:s){
            value+=map.get(c);}
       System.out.println(value);
        class Solution {
            public int romanToInt(String s) {
                Map<Character,Integer> map=new HashMap<>();
                map.put('I',1);
                map.put('V',5);
                map.put('X',10);
                map.put('L',50);
                map.put('C',100);
                map.put('D',500);
                map.put('M',1000);
                int sum=0;
                char[] str=s.toCharArray();
                for(int i=0;i<s.length()-1;i++){
                    if((map.get(str[i+1])<= map.get(str[i]))){
                        sum=sum+map.get(str[i]);
                    }
                    else{
                        sum=sum-map.get(str[i]);
                    }}
                return sum+map.get(str[s.length()-1]);
            }
        }
    }
}
