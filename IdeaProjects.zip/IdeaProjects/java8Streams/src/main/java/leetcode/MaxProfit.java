package leetcode;

public class MaxProfit {
    public static void main(String args[]){
        int nums[]={7,9,8,4,1};
        int min=Integer.MAX_VALUE;
        int max_profit=0;
        for(int i=0;i<nums.length;i++){
            if(nums[i]<min){
                min=nums[i];

            }
            else if(nums[i]-min>max_profit){
                max_profit=nums[i]-min;

            }
        }
        System.out.println(max_profit);
    }
}
