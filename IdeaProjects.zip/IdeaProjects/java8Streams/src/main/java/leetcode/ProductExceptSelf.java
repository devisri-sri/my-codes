package leetcode;

public class ProductExceptSelf {
    public static void main(String args[]) {
        int nums[] = {5,6,3,9};
        int[] result = productSelf(nums);
        // Print the result array
        for (int num : result) {
            System.out.print(num + " ");
        }}
    public static int[] productSelf(int[] nums) {
        int result[] = new int[nums.length];
        int leftProduct = 1;
        for (int i = 0; i < nums.length; i++) {
            result[i] = leftProduct;
            leftProduct *= nums[i];}
        // Calculate product of all elements to the right of each element and multiply with existing result
        int rightProduct = 1;
        for (int i = nums.length - 1; i >= 0; i--) {
            result[i] *= rightProduct;
            rightProduct *= nums[i];}
        return result;
    }
}
