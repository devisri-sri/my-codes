package leetcode;

import java.util.Arrays;

public class PlusOne {
    public static void main(String args[]) {
        int digits[] = {7,9};
        int n = digits.length;

        // Adding one to the digits
        for (int i = n - 1; i >= 0; i--) {
            digits[i]++;
            if (digits[i] < 10) {
                break; // No carry, we're done
            }
            digits[i] = 0; // Set the current digit to 0 and continue to the next digit
        }

        // If there's still a carry after the loop, create a new array with one additional digit
        if (digits[0] == 0) {
            int[] result = new int[n + 1];
            result[0] = 1;
            digits = result;
        }

        // Print the result
        System.out.println(Arrays.toString(digits));
    }
}
