package leetcode;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateNotConescutive {
    public static <Charcter> void main(String args[]) {
        String str = "aabbbccdedefqwf";
        char[] s = str.toCharArray();
        Set<Character> set = new LinkedHashSet<>();
        for (char c : s) {
            set.add(c);
        }
        StringBuilder sb = new StringBuilder();
        for (char c : set) {
            sb.append(c);
        }
        System.out.println(set);
    }
}
