package leetcode;

import java.util.Arrays;

public class BuyCandy {
    public static void main(String args[]) {
        int nums[] = {1,0,2};
        int d[] = new int[nums.length];
        Arrays.fill(d,1);
        for (int i = 1; i < nums.length; i++) {
            if(nums[i]>nums[i-1]){
                d[i]=d[i-1]+1;
            }
        }
        for (int i = nums.length-2; i >=0; i--) {
            if(nums[i]>nums[i+1]){
                d[i]=Math.max(d[i],d[i+1]+1);
            }
        }
        System.out.println(Arrays.stream(d).sum());
    }
}