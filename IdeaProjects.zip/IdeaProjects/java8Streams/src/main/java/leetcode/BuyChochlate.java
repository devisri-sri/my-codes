package leetcode;

public class BuyChochlate {
    public static void main(String args[]){
        int [] prices={3,1,3};
        int money=3;
        int min=Integer.MAX_VALUE;
        int secondMin=min;
        for(int price:prices){
            if(min>price){
                secondMin=min;
                min=price;
            }
            else if(secondMin>price){
                secondMin=price;
            }
        }
        int left=money-(min+secondMin);
        System.out.println(left>=0?left:money);
    }
}
