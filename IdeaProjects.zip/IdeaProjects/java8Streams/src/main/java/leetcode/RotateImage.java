package leetcode;

public class RotateImage {
    public static void main(String args[]){
        int matrix[][]={{1,2,3},{4,5,6},{7,8,9}};

    int res[][]=new int[matrix.length][matrix[0].length];
    int k=matrix.length-1;
        for(int i=0;i<matrix.length;i++){
        for(int j=0;j<matrix[0].length;j++){
            res[j][k]=matrix[i][j];
//            System.out.print(res[j][k] +" ");
        }
        k--;
    }
        for(int i=0;i<res.length;i++){
        for(int j=0;j<res.length;j++){
            matrix[i][j]=res[i][j];
            System.out.print(matrix[i][j] +" ");
        }
            System.out.println(" ");

        }
}
}
