package leetcode;

public class RemoveConsecutive {
    public static void main(String args[]) {
        String str = "aabbbccdede";
        System.out.println(RemoveConsecutive.removeConsecutiveDuplicates(str));
    }static String removeConsecutiveDuplicates(String input) {
        if (input == null || input.length() == 1) {
            return input;
        }
        StringBuilder sb = new StringBuilder();
        char prev = input.charAt(0);
        sb.append(prev);
        for (int i = 1; i < input.length(); i++) {
            char current = input.charAt(i);
            if (current != prev) {
                sb.append(current);
                prev = current;
            }}
//        return input.replaceAll("(.)\\1+","$1");  --simple way
        return sb.toString();
    }
}



