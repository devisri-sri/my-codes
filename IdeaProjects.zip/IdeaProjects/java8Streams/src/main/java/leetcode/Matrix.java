package leetcode;

public class Matrix {
    public static void main(String args[]){
        int a[][]={{1,2,3},{4,5,6},{7,8,9}};
        int t[][]=new int[a.length][a[0].length];
        for (int i=a.length-1;i>=0;i--){
            for(int j=a[0].length-1;j>=0;j--){
                t[i][j]=a[i][j];
                System.out.print(t[i][j] + " ");
            }
            System.out.println(" ");
        }
        for (int i=t.length-1;i>=0;i--){
            for(int j=0;j<t[0].length;j++){
                System.out.print(t[j][i] + " ");
            }
            System.out.println(" ");
        }
    }
}
