package leetcode;

import java.util.HashMap;
import java.util.Map;

public class TwoSUM {
    public static void main(String args[]) {
        int a[]={2,3,6,11,9,32};
        int target=15;
        Map<Integer,Integer>map= new HashMap<>();
        for(int i=0;i<a.length;i++){
            int sum=target-a[i];
            if(map.containsKey(sum)){
                a[0]=map.get(sum);
                a[1]=i;
                break;
            }
            map.put(a[i],i);
        }
        System.out.println("1st "+ a[0] + " 2nd is " +a[1]);
    }

}
