package leetcode;

public class StringIndex {
    public static void main(String args[]){
        String str = "Hello, world!";
        int index = str.indexOf("world");
// The value of 'index' will be 7, as "world" starts at index 7 in the string "Hello, world!"
System.out.println(str.charAt(7));
        System.out.println(index);
    }
}
