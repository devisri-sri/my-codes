package leetcode;

import java.util.Arrays;
import java.util.stream.Collectors;

public class reverseString {

    public static void main (String args[]) {
        String s = "the sky is blue";
        String [] str= s.trim().split(" ");
        for(int i=str.length-1;i>=0;i--){
            System.out.print(str[i]+" ");
//           Arrays.asList(s.split(" ")).reversed().stream().filter(e -> !e.equals("")).collect(Collectors.joining(" "));

        }
    }
}
