package leetcode;

public class smallElement {
    public static void main(String args[]) {
        int n=81000;
        String ans="";
        for(int div=9;div>=2;div--){
            while(n%div==0){
                n=n/div;
                 ans=div+ans;
            }
        }
        if(n!=1){
            System.out.println("not possible");
        }
        else{
            System.out.println(ans);

        }
    }



}
