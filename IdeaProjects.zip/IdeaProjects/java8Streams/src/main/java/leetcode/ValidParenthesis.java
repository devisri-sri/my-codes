package leetcode;
import java.util.Stack;
public class ValidParenthesis {
    public static boolean isValid(String s) {
        Stack<Character> stack = new Stack<>();
        for (char c : s.toCharArray()) {
            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            } else if (c == ')' && !stack.isEmpty() && stack.peek() == '(') {
                stack.pop();
            } else if (c == ']' && !stack.isEmpty() && stack.peek() == '[') {
                stack.pop();
            } else if (c == '}' && !stack.isEmpty() && stack.peek() == '{') {
                stack.pop();
            } else {
                return false; // If any other character or mismatched closing bracket encountered
            }
        }

        return stack.isEmpty(); // If stack is empty, all brackets are correctly matched
    }

    public static void main(String[] args) {
        String input1 = "()[]{}";
        String input2 = ")([)(]";
        String input3 = "{[]}";

//        System.out.println(input1 + " is valid: " + isValid(input1));
//        System.out.println(input2 + " is valid: " + isValid(input2));
        System.out.println(input3 + " is valid: " + isValid(input3));
    }
}
