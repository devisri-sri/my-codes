package leetcode;

public class Removeelement {
    public static void main(String args[]){
        int  nums []= {3,2,2,3};
        int val=3;
        int val_size=0;

        for(int i=0;i<nums.length;i++){
            if(nums[i]!=val){
                nums[val_size]=nums[i];
                val_size++;
            }
        }
        for(int i=0;i<val_size;i++){
            System.out.println(nums[val_size]);
        }

    }
}
