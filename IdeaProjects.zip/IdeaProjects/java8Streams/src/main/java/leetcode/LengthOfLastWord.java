package leetcode;

public class LengthOfLastWord {

        public static void main (String args[]) {
            String s="luffy is still joyboy";
            String str[]= s.split(" ");

           int last= str.length;
            System.out.println(str[last-1].toCharArray().length);

            for(int i=0;i<str.length;i++){
               if(str[last-1]==str[i]){
                  int len= str[last-1].toCharArray().length;
                   System.out.println(len);
               }
           }
        }
    }

