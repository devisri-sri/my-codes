package leetcode;

public class GasStation {
    public static void main(String args[]){
        int gas[]={1,2,3,4,5};
        int cost[]={3,4,5,1,2};
        int n= gas.length;
        int tank=0,startStation=0,totalgas=0,totalCost=0;
        for(int i=0;i<n;i++){
            totalgas=totalgas+gas[i];
            totalCost=totalCost+cost[i];
            tank=tank+gas[i]-cost[i];
                    while(tank<0){
                        startStation=i+1;
                        tank=0;
                    }

        }
        int result = totalgas >= totalCost ? startStation : -1;
        System.out.println(result);

    }
}
