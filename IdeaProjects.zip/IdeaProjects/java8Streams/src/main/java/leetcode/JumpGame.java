package leetcode;

public class JumpGame{
    public static void main (String args[]){
        int nums[]={2,3,1,1,4};
        int last=nums.length-1;
        for(int i=nums.length-1;i>=0;i--){
            if(i+nums[i]>=last){
                last=i;

            }
            System.out.println(last);
        }
        if(last==0){
            System.out.println("true");
        }
        else{
            System.out.println("false");

        }

    }
}