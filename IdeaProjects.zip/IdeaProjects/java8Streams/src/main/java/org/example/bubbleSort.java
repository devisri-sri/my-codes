package org.example;
//O(n2)
public class bubbleSort {
    public static void main(String args[]) {
        int nums[] = {3, 4, 1, 6, 7, 11, 34};
        int steps=0;
        for (int i = 0; i < nums.length; i++) {
            for (int j = 0; j < nums.length-1; j++) {

                if(nums[i]<nums[j]){
                int temp = nums[i];
                nums[i] = nums[j];
                nums[j] = temp;
            }}
            steps++;
            System.out.println(steps);

            System.out.println();

            for(Integer a: nums){
                System.out.print(a+" ");
            }
        }
    }
}
