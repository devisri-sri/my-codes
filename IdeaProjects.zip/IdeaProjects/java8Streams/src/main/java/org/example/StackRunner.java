package org.example;

public class StackRunner {
    public static void main(String args[]){
        Stack stack= new Stack();
        stack.push(7);
        stack.push(0);
        stack.push(3);
        stack.pop();
        stack.push(17);
        stack.push(107);
        stack.push(187);
        stack.show();
    }
}
