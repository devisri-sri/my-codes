package org.example;

public class Queue {
    int queue[]= new int[5];
    int size;
    int rear;
    int front;
    public void enqueue(int data){
        queue[rear]=data;
        rear=rear+1;
        size++;
    }
    public void show(){
        for(int i=0;i<size;i++){
            System.out.println(queue[i]);
        }
    }
}
