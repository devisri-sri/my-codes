package org.example;


public class CharCount {
    public static void main(String args[]){
        String str="am world gehgu";
        int[] charCount=new int[256];
        char[]a= str.toCharArray();
        for(char c: a){

if(Character.isLetter(c)||Character.isDigit(c)){
    int index=(int)c;
    charCount[index]++;
}
        }
        for(int i=0; i<charCount.length;i++){
            if(charCount[i]!=0){
                System.out.println("'" + (char)i + "' = "+ charCount[i]);

            }
        }
    }
}