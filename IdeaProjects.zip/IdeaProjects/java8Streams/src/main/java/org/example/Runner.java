package org.example;

public class Runner {
    public static void main(String args[]){
    LinkedLIst list= new LinkedLIst();
    list.insert(7);
        list.insert(9);
        list.insert(1);
        list.insert(1);
        list.insert(1);
        list.insert(1);
        list.insert(1);
        list.show();
}
}