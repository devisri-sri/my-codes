package org.example;
//O(n)
public class LinearSearch {
    public static void main(String args[]) {
        int a[] = {2, 4, 5, 7, 8, 9, 11};
        int target = 8;
        int result = linearSearch(a, target);
        if (result != -1) {
            System.out.println("element found");
        } else {
            System.out.println("element not found");
        }
    }

    public static int linearSearch(int nums[], int target) {
        int steps=0;
        for (int i = 0; i < nums.length; i++) {
steps++;
            if (nums[i] == target) {
                return i;
            }

        }
        System.out.println(steps);

        return -1;
    }
}
