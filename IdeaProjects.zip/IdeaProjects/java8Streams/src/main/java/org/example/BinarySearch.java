package org.example;
import java.util.Arrays;
//O(log2n)
public class BinarySearch {
    public static void main(String args[]) {
//        int nums[]=new int[250];
        int nums[]={3,4,5,6,7,2,9};
        Arrays.sort(nums);
        int target=2;
        int result=binarySearch(nums,target);
        if(result!=-1){
            System.out.println("element found");
        }else{
        System.out.println("element not found");}}
    public static int  binarySearch(int nums[],int target){
        int left=0;
        int right=nums.length-1;
        int steps=0;
        while(left<=right){
            steps++;

            int mid= (left+right)/2;
            if(nums[mid]==target){
                return mid;
            }
            else if(nums[mid]<target){
                left=mid+1;
            }
            else
                right= mid-1;
        }
        System.out.println(steps);
        return -1;

    }

    }
