package org.example;

public class queueRunner {
    public static void main(String args[]){
        Queue queue= new Queue();
        queue.enqueue(6);
        queue.enqueue(68);
        queue.enqueue(60);
        queue.enqueue(16);
        queue.enqueue(76);
        queue.enqueue(77);
        queue.show();
    }
}
