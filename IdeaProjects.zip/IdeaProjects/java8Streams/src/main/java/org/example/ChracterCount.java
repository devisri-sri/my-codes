package org.example;

import java.util.Comparator;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ChracterCount {
    public static void main(String args[]){
        String str="abcdfghjugtg";
        //max charcter count
        Map.Entry<Character,Long>map=str.chars().mapToObj(c->(char)c)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                .entrySet().stream().max(Map.Entry.comparingByValue()).orElseThrow(null);

        System.out.println(map.getKey());
//finding the characters count///
        Map<Character,Long>ma=str.chars().mapToObj(c->(char)c)
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        ma.entrySet().stream().forEach(System.out::println);

    }
}
