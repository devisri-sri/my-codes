package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Prime {
    public static void main(String args[]){
        List<Integer> list= Arrays.asList(1,5,7,2,4,19);
        list.stream().filter(Prime::getPrime).collect(Collectors.toList()).
                forEach(System.out::println);

    }

    private static boolean getPrime(Integer num) {
        int count=0;
        for(int i=1;i<=num;i++){
            if(num%i==0){
               count++;
            }
        }
        if(count==2){
            return true;
        }
        else{
            return false;
        }

    }
}
