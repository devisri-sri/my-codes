package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class listPerson {
    public static void main(String[] args) {
        List<Person> person = new ArrayList<>();
        person.add(new Person("23","devisri","hyd","2000000"));
        person.add(new Person("28","satya","kovu","1000000"));

        person.add(new Person("34","veera","Sah","3000000"));

        person.add(new Person("46","datta","RJY","1000000"));

   Set<String> list=     person.stream().map(Person::getName).collect(Collectors.toSet());
System.out.println(list);
Map<String,String>map=person.stream().collect(Collectors.toMap(p->p.getName(),p->p.getAddress()));
        System.out.println(map)   ;
        person.stream().filter(a ->a.getAge().equals("28")).map(p->p.getName()).forEach(System.out::println);
        person.stream().map(Person::getName).collect(Collectors.toList()).forEach(System.out::println);
//        Optional<Person>=person.stream().max(Comparator.comparing(Person::getName).);
        person.stream().filter(p->p.getName().equals("devisri")).findAny().orElseThrow(()->new RuntimeException("name not in list"));

//        list.stream().sorted(Comparator.comparing()->f1.getfirstname>f2.getfirstname).collect(Collectors.tolist)
        List<String>ap=  person.stream().sorted(Comparator.comparing(Person::getName)).map(Person::getName).collect(Collectors.toList());
    System.out.println("sorting we got "+ap);
        List<Person>pp=person.stream().filter(i->i.getAge().equals("23") && i.getName().equals("devisri")).collect(Collectors.toList());
        System.out.println("sorting we got "+pp);

    }

}