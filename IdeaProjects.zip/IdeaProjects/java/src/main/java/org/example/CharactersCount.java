package org.example;

import java.util.HashMap;
import java.util.Map;

public class CharactersCount {
    public static void main(String args[]){
       String str="TYGHGGUGGGT";
       char[]c= str.toCharArray();
       Map<Character,Integer> map= new HashMap<>();
       for(char a:c){
           if(map.containsKey(a)){
               map.put(a,map.get(a)+1);}
           else
               map.put(a,1);
           }
       for(Map.Entry<Character,Integer>m:map.entrySet()){
         if(m.getValue()>1)  {
             System.out.println(m.getKey() +"->" +m.getValue());
         }
       }

    }
}
