package org.example;

public class Main {
    public static void main(String[] args) {

int a[]=   {2,3,7,10,8,9};
int b[]= {7,4,2,1};
boolean flag= false;
for(int i=0;i<b.length-1;i++){


if(b [i]<b[i+1]){
    flag=true;
}else {
    flag = false;

    break;
}
}
if(flag){
    System.out.println("in sorted order");
}
    }
}