package org.example;


import java.util.Scanner;

public class Arm {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc= new Scanner(System.in);
        int n= sc.nextInt();
        int temp=n,sum=0;
        while(n!=0) {
            int r=n%10;
            sum=(r*r*r)+sum;
            n=n/10;

        }
        if(sum==temp) {
            System.out.println("armstrong");
        }
    }

}
