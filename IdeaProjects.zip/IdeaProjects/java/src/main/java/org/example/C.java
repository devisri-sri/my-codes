package org.example;

public class C implements A, B{
     public void eat() {
        System.out.println("eating from C");
    }
    public static void main(String args[]){
//super().
    C c=  new C();
    c.eat();


}}
