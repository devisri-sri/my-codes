package org.example;

import javafx.scene.shape.Path;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CSVTOJSON {
    public static void main(String args[]) throws IOException {
        String path="C:\\Users\\DBOLLAM\\Downloads\\csvtojson.txt";
//        Files files= Files

      if(Files.exists(Paths.get(path))){
          Files.lines(Paths.get(path)).skip(0).map(filedata ->{
              String [] csvdata=filedata.split(",");
              return new Person(csvdata[0],csvdata[1],csvdata[2],csvdata[3]);
          }).forEach(System.out::println);
      }

//        Person person = new Person();
//        person.setAge("23");
//        person.setName("sri");
//        person.setAddress("kakinada");
//        person.setSalary("1500000");

        // Convert Person object to JSON
//        ObjectMapper mapper = new ObjectMapper();
//        try {
//            String json = mapper.writeValueAsString(person);
//            System.out.println(json);
//        } catch (JsonProcessingException e) {
//            e.printStackTrace();
//        }



    }
}
