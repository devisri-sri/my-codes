package org.example;

public interface B {
    default void eat() {
        System.out.println("eating from B");
    }
}
