package org.example;

public interface A {
    default void eat(){
        System.out.println("eating from A");
    }
}
