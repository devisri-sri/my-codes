/* var, let & const
function print() {
    var x = 9;
    if (x > 0) {
        // let a = "positive"
        var a = "positive"
    }
    console.log(a)
    const PI = 3.14;
    console.log(PI)
    // PI = 2.14
    const PERSON = Object.freeze({ firstname: 'nagaraju' })
    console.log(PERSON) //
    PERSON.lastname = 'setti'
    console.log(PERSON) //
}

print();
*/

/* default parameter
// set default values to parameter
function print(a = 0, b = 0) {
    console.log("A: " + a)
    console.log("B: " + b)
}

print();
print(3, 9);
print(undefined, undefined);
*/

/* rest parameter
// rest parameter must be last formal parameter
function print(b, ...a) {
    console.log(a)
}

print(5, 6, 7, 8);
*/

/* spread operator
// can only be used with iterables

var n1 = [1, 2, 3]
var n2 = [7, 8, 9]

let nums = [...n1, 4, 5, 6, ...n2]
console.log(nums)

let str = "hello"
let s = [...str]
console.log(s)

let person = { firstname: 'nagarjau' }
let p = [...person]
*/

/* destructuring

// array destructuring
let nums = [9, 6, 8, 7]
let [a, ...b] = nums;
console.log(a, b)

function getValues() {
    return [4, 5, 6, 7]
}

let [x, ...y] = getValues();
console.log(x, y)

//object destructuring
let person = { firstname: 'nagaraju', lastname: 'setti' }
// console.log(person.firstname, person.lastname)
let { firstname, lastname } = person;
console.log(firstname, lastname)
*/

/* template literals
// backticks [``]
// allow to write multi line strings
// allow to interpolate varaiables and expression within string

let template = `<b>hello, good evening</b>
    <h3> Very Good Evening</h3> `;
document.write(template)

let fullname = 'nagaraju setti'

console.log(`Fullname: ${fullname} `)

let sql = "insert into products(id, name) values(" + id + ", '" + name + "')"

sql = `insert into products(id, name) values(${id}, '${name}')`
*/

/* arrow functions
// 1. if arrow function has one parameter then we can omit parenthesis
// 2. if arrow function body has single statement then we can omit curly brackets
// 3. arrow function has implicit return

function sayHello(x) {
    return x
}

console.log(sayHello('hello X'))

let sayHai = x => x

console.log(sayHai('hai X'))
*/

/* class, constructor, extends, setter/getter
class Person {
    constructor(name) {
        this.fullname = name;
    }
    set setFullname(name) {
        this.fullname = name;
    }

    get getFullname() {
        return this.fullname;
    }
}

// let p = new Person("nagaraju");
// console.log(p.fullname)
// p.setFullname = "nagaraju setti" // setters are mutators
// console.log(p.getFullname) // getters are accessors

class Employee extends Person {
    constructor(name, salary) {
        super(name)
        this.salary = salary;
    }
}

let e = new Employee('nagaraju', 10000)
console.log(e.fullname, e.salary)

*/

/* class expression
// let Person = class {
//     constructor(name) {
//         this.fullname = name;
//     }
// }

// let p = new Person('nagaraju')
// console.log(p.fullname)
// let p2 = new Person('setti')
// console.log(p2.fullname)

let Person = new class {
    constructor(name) {
        this.fullname = name;
    }
    display() {
        console.log('hello')
    }
}('nagaraju')

console.log(Person.fullname)
Person.display()
*/

/* promises */
// pending, fulfil, reject

var flag = false;

let myPromise = new Promise((resolve, reject) => {
    if (flag) {
        resolve('I did something...')
    } else {
        reject("Something went wrong...")
    }
})

myPromise.then((x) => console.log(x))
    .catch((e) => console.error(e))


















































































































