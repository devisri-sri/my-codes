package com.cg.abstractDemo;

public class abstractDemoJava {

	public static void main(String[] args) {
		Bank hdfc= new HDFC();
		hdfc.Withdraw();
		hdfc.calculateInterest();
		Bank icic= new ICIC();
		icic.Withdraw();
		icic.calculateInterest();
	}

}

abstract class Bank{
	public void Withdraw() {
		System.out.println("common withdraw");
	}
	abstract int calculateInterest() ;
		}

class HDFC extends  Bank{

	@Override
	int calculateInterest() {
		System.out.println("HDFC calculate Interest");
		return 0;
	}}
class ICIC extends  Bank{

	@Override
	int calculateInterest() {
		System.out.println("ICIC calculate Interest");
		return 0;
	}}