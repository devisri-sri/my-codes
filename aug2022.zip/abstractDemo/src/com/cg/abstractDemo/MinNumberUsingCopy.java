package com.cg.abstractDemo;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.*;

public class MinNumberUsingCopy {
	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	int n=sc.nextInt();
	int a[]= new int [n];
	for(int i=0;i<n;i++) {
		 a[i]=sc.nextInt();
	}
	int [] copy= Arrays.copyOf(a, n);
	Arrays.sort(copy);
	for(int i=0;i<3;i++) {
	System.out.println(copy[i]);
	
	}
	//using streams
	System.out.println("using streams");
	IntStream.of(a).distinct().sorted().limit(3).forEach(System.out::println);
	//forEach(i->System.out.println(i) same as forEach(System.out::println)
	}

}
