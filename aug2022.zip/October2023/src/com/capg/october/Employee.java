package com.capg.october;

public class Employee {
private int  no;
private String name;
private double salary;
private  int days;
  public  Employee() {
	  
  }
  public Employee(int no,String name,double salary,int days) {
	  super();
	  this.no=no;
	   this.name=name;
	   this.salary=salary;
	   this.days= days;
  }
  public int getNo() {
	  return no;
  }
  public String getName() {
	  return name;
  }
  public double getSalary() {
	  return salary;
  }
  public int getDays() {
	  return days;
  }
  public void setNo(int no) {
	  this.no=no;
  }
  public void setName(String name) {
	  this.name=name;
  }
  public void setSalary(double salry) {
	  this.salary=salary;
  }
  public void setDays(int days) {
	  this.days=days;
  }
//public int getNo() {
//	return no;
//}
//public void setNo(int no) {
//	this.no = no;
//}
//public String getName() {
//	return name;
//}
//public void setName(String name) {
//	this.name = name;
//}
//public double getSalary() {
//	return salary;
//}
//public void setSalary(double salary) {
//	this.salary = salary;
//}
//public int getDays() {
//	return days;
//}
//public void setDays(int days) {
//	this.days = days;
//}
//public Employee(int no, String name, double salary, int days) {
//	super();
//	this.no = no;
//	this.name = name;
//	this.salary = salary;
//	this.days = days;
//}
@Override
public String toString() {
	return "Employee [no=" + no + ", name=" + name + ", salary=" + salary + ", days=" + days + "]";
}
  
}
