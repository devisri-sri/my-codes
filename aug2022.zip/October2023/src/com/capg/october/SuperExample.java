package com.capg.october;


class Thing {
	String color="RED";
}
 class Stick extends Thing{
	 Stick(){
		 String color="Blue";
		 System.out.println("the color of stick is" +super.color);
		 System.out.println("the color of stick is" +color);
	 }
 }

 class SuperExample extends Stick{
	 SuperExample(){
		 super();
		 System.out.println("the top of stick is black clor");
		 
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
new SuperExample();
	}

}
