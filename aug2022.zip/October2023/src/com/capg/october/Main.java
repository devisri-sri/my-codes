package com.capg.october;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Employee> emp= new ArrayList<>();
emp.add(new Employee(1,"sai",2345678,123));
emp.add(new Employee(2,"sri",1000000,456));
emp.add(new Employee(3,"hanvi",123456789,789));
emp.add(new Employee(4,"venky",2000000,945));
	
	emp.stream().filter(a->a.getName().startsWith("s")).filter(s->s.getNo()%2==0).collect(Collectors.toList()).forEach(System.out::println);

}
}
