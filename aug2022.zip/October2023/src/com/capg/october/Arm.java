package com.capg.october;

import java.util.Scanner;

public class Arm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
int num= sc.nextInt();
int temp=num;
int sum=0;
while(num!=0) {
	int r= num %10;
	sum= (r*r*r)+sum;
	num=num/10;
}
if(temp==sum) {
System.out.println("is armstrong number");
}

}
}
