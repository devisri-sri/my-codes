package com.capg.october;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		int num=sc.nextInt();
		 int digits=0;
		 
		while(num>0) {
			int r= num%10;
			digits=digits+r;
			num=num/10;
			
			
		}
		System.out.println(digits);

	}

}
