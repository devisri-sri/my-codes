package com.capg.october;

class Animal{  
    // data member of Animal class  
    String color = "white";    
      
}  
// create child class of Animal  
class Cat extends Animal{  
    //default constructor  
    Cat()  
    {  
        // data members of the Cat class  
        String color = "Brown";    
        System.out.println("The cat is of color "+super.color); // calling parent class data member  
        System.out.println("The cat is of color "+color);  
    }  
}  
// create child class for Car  
class SuperDemo extends Cat  
{  
    // default constructor  
    SuperDemo()  
    {  
        // calling base class constructor  
        super();  
        System.out.println("The eyes of the cat is blue.");  
    }  
    // main() method start  
    public static void main(String[] args)  
    {  
        // call default constructor of the SuperExample1  
        new SuperDemo();  
        System.out.println("Inside Main");  
    }  
}  




//public class SuperDemo {
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	
//
//}
//}