package com.capg.october;
import org.json.JSONObject;

public class XmlToJson {

	public static void main(String[] args) {
String xmlString ="<Users><user><name>sri</name><age>24</age></user><user><name>datta</name><age>25</age></user></Users>";
	JSONObject object= XML.
	
	}

}
