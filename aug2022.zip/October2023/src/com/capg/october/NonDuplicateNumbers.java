//package com.capg.october;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Map;
//import java.util.function.Function;
//import java.util.stream.Collectors;
//
//public class NonDuplicateNumbers {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//List<Integer>numbers= Arrays.asList(1,3,5,6,7,1,2,5);
//List<Integer>nonDuplicateNums=findNonDuplicates(numbers);
//System.out.println(nonDuplicateNums);}
//public static  List<Integer> findNonDuplicates(List<Integer>list) {
////list.stream().distinct().collect(Collectors.toList()).forEach(System.out::println);
//Map<Integer,Long>countMap=list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
// return list.stream().filter(e ->countMap.get(e)==1);
//
//	}
//}
