package com.october;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OctoberApplication {

	public static void main(String[] args) {
		SpringApplication.run(OctoberApplication.class, args);
	}

}
