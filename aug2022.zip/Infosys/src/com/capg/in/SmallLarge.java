package com.capg.in;

public class SmallLarge {

	public static void main(String[] args) {
String str="Hardships often prepare ordinary people for an extraordinary destiny "
		+ "a"+
"a";

String [] words= str.split("\\s+");
String small=words[0];
String large=words[0];
for(String word:words) {
	if(word.length()>large.length()) {
		large=word;
		
	}
	if(word.length()<small.length()) {
		small=word;
		
	}
}
System.out.println("small word is "+small);
System.out.println("large word is "+large);

	}

}
