package com.capg.in;

public class ArrayReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {2,4,5,6,7};
//reverse order
for(int i=a.length-1;i>=0;i--) {
	System.out.print("reverse order"+a[i]);
	
}
//print even poistion
for(int i=1;i<a.length;i=i+2) {
	System.out.print("even poistion"+a[i]);

}
//odd poistion
//print even poistion
for(int i=0;i<a.length;i=i+2) {
	System.out.print("odd poistion" +a[i]);

}
	}

}
