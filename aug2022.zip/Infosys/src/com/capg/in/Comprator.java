package com.capg.in;

import java.util.Comparator;

public class Comprator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Comparator<Integer>comprator= new Comparator<Integer>() {

	@Override
	public int compare(Integer o1, Integer o2) {
		// TODO Auto-generated method stub
		return o1.compareTo(o2);
	}
	
	};
	System.out.println(comprator.compare(3,2));
//using lamda
	Comparator<Integer>compratorlamd= (a,b)->{return a.compareTo(b);};
	System.out.println(compratorlamd.compare(3,2));

	Comparator<Integer>comparatorlamba2= (a,b)->a.compareTo(b);
	System.out.println(comparatorlamba2.compare(3,2));
	}
}
