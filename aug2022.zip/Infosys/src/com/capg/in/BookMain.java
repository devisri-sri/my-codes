package com.capg.in;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class BookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Book>books= new ArrayList<>();
books.add(new Book("Devisri","Jobs planning",2024,100.00));
books.add(new Book("Datta","Carrer growth",2023,1000000.00));
books.add(new Book("venky","IAS",2022,1200000.00));
books.add(new Book("sai","House Wife",200,500.00));
books.add(new Book("veeraveni","House Wife",230000,500.00));
books.add(new Book("hanvi","kids school",2025,10000.00));

//print titles of the book published after 2000
books.stream().filter(i->i.getYear()>2000).map(Book::getTitle).forEach(System.out::println);
List<String>titles= new ArrayList<>();
for(Book book: books) {
	if(book.getYear()>2000) {
		titles.add(book.getTitle());
	}
	
}
System.out.println(titles);
	
//total price of all books
List<String> price=	books.stream().map(Book::getAuthor).collect(Collectors.toList());
System.out.println(price);


// find the book with highest price
Book highprice=books.stream().max((book1,book2)->
Double.compare(book1.getPrice(), book2.getPrice())).orElse(null);
System.out.println(highprice);
Book highPrice = books.stream()
.max(Comparator.comparingDouble(Book::getPrice))
.orElse(null);

System.out.println(highPrice);
//or

Optional<Book> priceshigh=books.stream().max(Comparator.comparing(Book::getPrice));
System.out.println(priceshigh);

List<Book>lists= books.stream().filter(i->i.getPrice()<10000).collect(Collectors.toList());
System.out.println(lists);


//sort with names
List<Book> names=books.stream().sorted(Comparator.comparing(Book::getAuthor)).collect((Collectors.toList()));

System.out.println("sorted i got "+names);


//grouping by titles

Map<String, List<Book>>map=books.stream().collect(Collectors.groupingBy(Book::getTitle));
System.out.println("using grouping" +map);

//grouping by count

Map<String,Long>count=books.stream().collect(Collectors.groupingBy(Book::getTitle,Collectors.counting()));
System.out.println(count);

}
	
}
