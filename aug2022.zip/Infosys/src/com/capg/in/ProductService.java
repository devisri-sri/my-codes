package com.capg.in;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ProductService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<ProductNew>list= new ArrayList<>();
list.add(new ProductNew("sri",123,"electronics"));
list.add(new ProductNew("sai",456,"motor"));
list.add(new ProductNew("venky",135,"thing"));
list.add(new ProductNew("datta",143,"motor"));
  List<ProductNew>lists= list.stream().filter(i ->i.getType().equals("motor"))
		 .collect(Collectors.toList());
System.out.println(lists);
	}

}
