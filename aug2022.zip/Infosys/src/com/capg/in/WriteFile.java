package com.capg.in;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFile {
    public static void main(String[] args) {
        String filePath = "C:\\Users\\DBOLLAM\\Downloads\\iwantjob.txt"; // Replace with your desired file path

        try {
            FileWriter fileWriter = new FileWriter(filePath);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            // Data to be written into the file
            String data = "Hello, this is some text that will be written into the file.\n";
            data += "Writing into files using Java is fun!";

            // Writing data to the file
            bufferedWriter.write(data);

            // Remember to close the writer to flush and release resources
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
