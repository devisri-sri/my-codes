package com.capg.in;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ImpVsDecl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer>integerList=Arrays.asList(1,2,4,5,1,2,3,4,5 );
			List<Integer>uniquelist=new ArrayList<>();
			for(Integer integer:integerList) {

				if(!uniquelist.contains(integer)) {
					uniquelist.add(integer);
				}
		}
			List<Integer>uniquelist1=integerList.stream().distinct().collect(Collectors.toList());
			System.out.println(uniquelist);
			System.out.println(uniquelist1);
	}
	
}
