package com.capg.in;

import java.util.Scanner;

public class palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//	Scanner sc= new Scanner(System.in);
//	int n= sc.nextInt();
//	int temp=n;int sum = 0;
//	while(n!=0) {
//		int r= n%10;
//		 sum=(sum*10)+r;
//		n=n/10;
//	}
//	if(temp==sum) {
//		System.out.println("given number is palindrome" +temp+"mentioned");
//		
//	}
	
		for(int n=1;n<=153;n++) {
int temp=n;int sum = 0;

 while(n!=0) {
	 int r= n%10;
	 sum=(r*r*r)+sum;
	 n=n/10;
 }
	if(temp==sum) {
	System.out.println("given number is armstrong" +temp+"mentioned");
	
}

	}
	}
}
