package com.capg.in;

import java.util.Random;

public class RandomEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random t = new Random();   
		// Generates random integers 0 to 49 
		int x= t.nextInt(100);
System.out.println(x);
	}

}
