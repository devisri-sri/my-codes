package com.capg.in;

public class StringReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String rev="hello Sri";
char[] c= rev.toCharArray();
char[] revArray=new char[rev.length()];
for(int i=0;i<rev.length();i++) {
	revArray[i]=c[rev.length()-i-1];
}
//System.out.println(revArray);
	
	
	String revone= new StringBuilder(rev).reverse().toString();
	System.out.println(revone);

}
}
