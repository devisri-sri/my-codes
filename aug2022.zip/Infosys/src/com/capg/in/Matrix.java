package com.capg.in;

public class Matrix {

	public static void main(String[] args) {
int a[][]= {{2, 3, 4},{5,6,7},{8,9,4}};
int b[][]= {{6, 8, 4},{2,1,2},{3,5,2}};
 int cols=a[0].length;
int add[][]=new int[a.length][cols];
for(int i=0;i<a.length;i++) {
	for(int j=0;j<cols;j++) {
		add[i][j]=a[i][j]+b[i][j];
	}
}
for(int i=0;i<a.length;i++) {
	for(int j=0;j<cols;j++) {
		System.out.print(add[i][j] + " ");
	}
	System.out.println();


}
	}
}
