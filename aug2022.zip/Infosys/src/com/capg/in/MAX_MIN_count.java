package com.capg.in;

import java.util.HashMap;
import java.util.Map;

public class MAX_MIN_count {

	public static void main(String[] args) {
String str="Hello Datta";
char[] c= str.toCharArray();
Map<Character,Integer>map= new HashMap<>();
for(char a:c) {
//	if(map.containsKey(a)) {
//		map.put(a, map.getOrDefault(a, 1)+1);
//	}
	
    if (Character.isLetter(a)) { // Consider only letters, ignoring spaces and punctuation
        map.put(a, map.getOrDefault(a, 0) + 1);
    }
//	else {
//		map.put(a, 1);

//	}

	
}
for(Map.Entry m:map.entrySet()) {
	System.out.println(m.getKey() + " ->" + m.getValue() );
	}

}
}
