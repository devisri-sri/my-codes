package com.capg.in;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer>num= Arrays.asList(2,5,8,9,12,15,14);
Map<Boolean,List<Integer>>map=num.stream().collect(Collectors.partitioningBy(n->n%2==0));
List<Integer>even=map.get(true);
List<Integer>odd=map.get(false);
System.out.println(even);
System.out.println(odd);
/////using different method
List<Integer> evenNum=num.stream().filter(n->n%2==0).collect(Collectors.toList());
System.out.println(evenNum);
	}

}
