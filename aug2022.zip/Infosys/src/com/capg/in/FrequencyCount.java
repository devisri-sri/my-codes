package com.capg.in;

import java.util.HashMap;
import java.util.Map;

public class FrequencyCount {

public static void main(String[] args) {
	String val= "ghhelloworld";
	char[] c= val.toCharArray();
//int a[]= {2,3,2,4,5,6,3,7,8};
Map<Character,Integer>map= new HashMap<>();
for(char num :c) {
if(map.containsKey(num)) {
	map.put(num, map.get(num)+1);
}
else {
	map.put(num, 1);}
	}
for(Map.Entry m:map.entrySet()) {
	System.out.println(m.getKey()+ " "+ m.getValue());
}
}
}
