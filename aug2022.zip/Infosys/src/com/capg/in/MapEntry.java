package com.capg.in;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
public class MapEntry {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String>map= new HashMap<>();
		map.put(1, "devisri");
		map.put(2, "sai");
		map.put(3, "venky");
		map.put(4, "datta");
		map.put(5, "hanvi");
		System.out.println(map);
		System.out.println(map.keySet());
		System.out.println(map.values());
		System.out.println(map.entrySet());
for(Map.Entry m:map.entrySet()) {
	  System.out.println(m.getKey()+"  "+m.getValue());  }
//compare by value ascending order		
map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
//by key
map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);

//compare by value descending order		
map.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).forEach(System.out::println);

	}
	

}
