package com.capg.in;

public class JAXBExample {

}
