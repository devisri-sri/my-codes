package com.capg.in;

import java.util.HashMap;
import java.util.Map;

public class DuplicateCharacters {

	public static void main(String[] args) {
String str= "Hello Devi and Datta";
char c[]= str.toCharArray();
Map<Character,Integer>map= new HashMap<>();

for(char a:c) {
	if(Character.isLetter(a)) {
		map.put(a, map.getOrDefault(a, 0)+1);
	}
	
}
for(Map.Entry<Character,Integer> m:map.entrySet()) {
	if(m.getValue() >1) {
		System.out.println(m.getKey()+ "" +m.getValue());
	}
}
	}

}
