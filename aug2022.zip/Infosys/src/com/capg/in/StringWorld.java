package com.capg.in;

import java.util.HashMap;
import java.util.Map;

public class StringWorld {

	public static void main(String[] args) {
String input = "Hello world world Java hello Java world akka"
		+ "yyuioooo iopuuu world";
String lower=input.toLowerCase();
        
        String[] words = lower.split(" ");
        Map<String,Integer>map= new HashMap<>();
        for(String word :words) {
        	map.put(word, map.getOrDefault(word,0)+1);
        	
        }
        for(Map.Entry<String, Integer>m:map.entrySet()) {
        	if(m.getValue()>1) {
        		System.out.println(m.getKey()+"" +m.getValue());
        	}
        }
	}

}
