package com.capg.in;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class PredicateEx {

	static Predicate<Integer>p= (i)->i%2==0;
	static Predicate<Integer>p1= (i)->i%5==0;
	static Function<String,String>f=(name)->name.toUpperCase();
public static void predicateand() {
	System.out.println("using and we got ans is "+ p.and(p1).test(10));
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(p.test(10));
Consumer<String>c=(s)->System.out.println(s.toUpperCase());
c.accept("java8");
System.out.println(f.apply("java8dsp"));
predicateand();
	}

}
