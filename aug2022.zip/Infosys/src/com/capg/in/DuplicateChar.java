package com.capg.in;

import java.util.HashSet;
import java.util.Scanner;

public class DuplicateChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		String str=sc.next();
		HashSet<Character>charSet=new HashSet<>();
		for(char c:str.toCharArray()) {
			if(charSet.contains(c)) {
				System.out.print(c + " ");
//				System.out.print(1+2+3+"welcome"+6);
			}
			else {
				charSet.add(c);
			}
		}
	}

}
