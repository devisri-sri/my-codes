package com.capg.in;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String filePath = "C:\\Users\\DBOLLAM\\Downloads\\iwantjob.txt";

        try {
            FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line); // Print each line to the console
                // You can process or manipulate the text here as needed
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
		

	}

}
