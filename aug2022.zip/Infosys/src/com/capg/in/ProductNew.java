package com.capg.in;

public class ProductNew {
	private String name;
	private int number;
	private String type;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public ProductNew() {
		
	}
	public ProductNew(String name, int number, String type) {
		super();
		this.name = name;
		this.number = number;
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "ProductNew [name=" + name + ", number=" + number + ", type=" + type + "]";
	}
	
	
}
