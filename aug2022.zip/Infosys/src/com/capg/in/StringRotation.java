package com.capg.in;

public class StringRotation {

	public static void main(String[] args) {
String str1="abcde", str2="deabcde";
if(!(str1.length()==str2.length()) ){
	System.out.println("not string rotated one");
}
else {
	str2=str2.concat(str2);
	if(str2.indexOf(str1)!=-1) {
		System.out.println(" string rotated one");

		
	}
	else {
		System.out.println("not string rotated one");

	}
	
}
	}

}
