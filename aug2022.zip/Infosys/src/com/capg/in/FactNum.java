package com.capg.in;

public class FactNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,fact=1;
		for( i=1;i<=5;i++) {
			fact=fact*i;
		}
System.out.println(fact);
	}

}
