package com.capg.in;

import java.util.List;

public class StringExamples {

	public static void main(String[] args) {
String str= "The best of both worlds";
System.out.println(str.length());
char[]characters= str.toCharArray();
int lists= characters.length;
System.out.println(lists);
int vcount=0,ccount=0;
str.toLowerCase();
for(int i=0;i<str.length();i++) {
	if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u') {
		vcount++;
	}
	else if(str.charAt(i)>='a' && str.charAt(i)<='z') {
		ccount++;
	}
}
System.out.println("vowel " +vcount + " constant"+ccount);

	}}
	


 