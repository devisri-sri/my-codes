package com.capg.in;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
public static void main(String args[]) {
	List<Product> products=new ArrayList<>();
	products.add(new Product(1,"sri","household"));
	products.add(new Product(2,"sai","office"));
	
	products.add(new Product(3,"amma","household"));
	products.add(new Product(4,"nanna","office"));

//List<Integer>ids= new ArrayList<>();
//for(Product p:products) {
	//using java 8 streams //
	products.stream().filter(n ->n.getId()%2==0).filter(n ->n.getCategory().equalsIgnoreCase("office")).collect(Collectors.toList()).forEach(System.out::println);
//}
	
	List<Integer>ids= new ArrayList<>();
	for(Product p:products) {
		if(p.getName().equalsIgnoreCase("sri")){
			ids.add(p.getId());
		}}
		System.out.println(ids);
}

}