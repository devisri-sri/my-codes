package com.capg.in;

import java.util.HashMap;
import java.util.Map;

public class FrequencyCountNew {


public static void main(String[] args) {
Map<Integer,Integer>map= new HashMap<>();
int a[]= {1,2,3,4,5,6,1,2,3,2};
for(int i:a) {
	if(map.containsKey(i)) {
		map.put(i, map.get(i)+1);
	}
	else {
		map.put(i, 1);
	}
}
for(Map.Entry m:map.entrySet()) {
	System.out.println(m.getKey() + " ->" + m.getValue() );

}


	}

}
