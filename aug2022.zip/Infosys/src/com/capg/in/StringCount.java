package com.capg.in;

import java.util.Arrays;
import java.util.List;

public class StringCount {
	public static void main(String args[]) {
		String str="Hello am devisri , How are you";
		String  lower= str.toLowerCase();
		List<Character>vowels = Arrays.asList('a','e','i','o','u');
	long count=	lower.chars().mapToObj(c-> (char) c).filter(vowels::contains)
			.count();
	System.out.println(count);

	}
}
