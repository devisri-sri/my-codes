package com.capg.in;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num= sc.nextInt();
		int total=1;
		for(int i=1;i<=num;i++) {
			 total=total*i;
			
		}
		System.out.println("factorial of given num is" +total);

	}

}
