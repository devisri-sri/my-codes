package com.capg.in;


interface draw{
//    public String say(String name);  
    int add(int a, int b);
}
public class Lambda {
  public static void main(String args[]){ 
//	  draw d=(a,b) -> {retun a+b;};
      draw d=(int a,int b)->(a+b);  

//	  draw s1=(name)->{  
//           return "Hello, "+name;  
//       };
     
//       System.out.println(s1.say("Sonoo"));  
       System.out.println(d.add(4,5));  

       }
}