package com.capg.in;

import java.util.Map;
import java.util.TreeMap;

public class BookMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    Map<Integer,Book> map=new TreeMap<Integer,Book>();    
	    Book b1=(new Book("Devisri","Jobs planning",2024,100.00));
	    Book b2=(new Book("Datta","Carrer growth",2023,1000000.00));
	    Book b3=(new Book("venky","IAS",2022,1200000.00));
	    map.put(1,b1);
	    map.put(2,b2);
	    map.put(3,b3);
System.out.println(map.entrySet());
	    

	}

}
