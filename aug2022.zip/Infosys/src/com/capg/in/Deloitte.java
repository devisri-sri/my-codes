package com.capg.in;

public class Deloitte {

	public static void wordCount(String word) {
		int sum=0,j=0;
		String s1="";
		String s2="";
		int num=0;
		word=word.replaceAll("\\s", ",");
		for (int i=0;i<word.length();i++) {
			if(Character.isDigit(word.charAt(i))) {
				s1=s1+word.charAt(i);
				if(!Character.isDigit(word.charAt(i+1))) {
					num=num+Integer.parseInt(s1);
					s1="";
				}
			}
			else {
				s2=s2+word.charAt(i);
			}
		}
		System.out.println(num);
		System.out.println(s2);

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 String string= "2018 India 18 is my country";
 wordCount(string);
	}

}
