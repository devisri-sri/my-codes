package com.capg.in;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc= new Scanner(System.in);
//		int num= sc.nextInt();
		 for (int i = 1; i <= 100; i++)         
	       { 		  	  
	          int count=0; 	  
	          for(int num =1; num<=i;num++)
		  {
	             if(i%num==0)
		     {
	 		count++;
		     }
		  }
		if(count==2) {
			System.out.print(" "+i);
		}
//		else
//			System.out.println("given is not prime number "+num);


	}
	}

}
