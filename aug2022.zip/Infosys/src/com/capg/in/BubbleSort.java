package com.capg.in;

import java.util.Scanner;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
int a[]= new int[5];
int swap;
for(int i=0;i<a.length;i++) {
	a[i]=sc.nextInt();
}
for(int i=0;i<a.length;i++) {
	for(int j=i;j<a.length;j++) {
		if(a[i]>a[j]) {
		swap=a[i];
		a[i]=a[j];
		a[j]=swap;
	}}
}
for(int i=0;i<a.length;i++) {
	System.out.println(a[i]);
}
	}

}
