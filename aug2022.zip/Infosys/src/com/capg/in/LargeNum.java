package com.capg.in;

public class LargeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[] = { 23,45,67,21,14};
int max =a[0];
for(int i=0;i<a.length;i++) {
	if(a[i]<max) {
		max=a[i];
	}
	
}
//for(int i=0;i<a.length;i++) {
	System.out.println(max);
int b[]= {1,4,5,6}, sum=0;
for(int i=0;i<b.length;i++) {
	sum=sum+b[i];
}
System.out.println(sum);

	}

}
