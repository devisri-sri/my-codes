package com.october;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkademoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkademoApplication.class, args);
	}

}

//useful url
//Github link : https://github.com/codedecode25/Kafka
//
//Link to download Kafka : https://kafka.apache.org/downloads.html
//
//Commands to start Zookeeper and Kafka :
// .\bin\windows\zookeeper-server-start.bat .\config\zookeeper.properties
//.\bin\windows\kafka-server-start.bat .\config\server.properties 
