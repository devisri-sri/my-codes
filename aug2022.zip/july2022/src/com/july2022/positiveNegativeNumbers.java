package com.july2022;

public class positiveNegativeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[]= {10,30,70,90,-67,-5,9,-7};
		int poistiveArray[]= new int [10];
		int negtiveArray[]= new int [10];
		int poistiveCount=0;int negativeCount=0;
		for(int i=0;i<array.length;i++) {
			if(array[i]<0) {
				negtiveArray[negativeCount]=array[i];
				negativeCount++;
			}
			else {
				poistiveArray[poistiveCount]=array[i];
				poistiveCount++;
			}
			
		}
		System.out.println(poistiveCount);
		printElements(poistiveArray,poistiveCount);
		
		System.out.println(negativeCount);


	}
	public static void printElements(int array[],int size) {
		for(int i=0;i<size;i++) {
			System.out.println(array[i]);

		}
			
	}

}
