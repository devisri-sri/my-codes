package com.july2022;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student>studentList= new ArrayList<>();
		studentList.add(new Student("Datta",59,630388634));
		studentList.add(new Student("venky",19,56789043));
		studentList.add(new Student("Sri",3,67890543));
		studentList.add(new Student("Sai",4,678943689));
		studentList.add(new Student("anu",16,918269346));
//	public static 	List<Student> String getAllStudents() {
//			System.out.println(studentList);
//			return studentList;
//			
//		}

List<String> names= new ArrayList<>();

/*using collections*/
for(Student stu:studentList) {
	if(stu.getId()%2!=0) {
		names.add(stu.getName());
		
	}
}
System.out.println(names);
/*using streams*/


List<Student> studentNames= studentList.stream().filter(n->n.getId()%2!=0).collect(Collectors.toList());


System.out.println(studentNames);

}

	
		
	}
