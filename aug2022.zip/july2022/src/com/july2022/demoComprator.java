package com.july2022;

import java.util.stream.Collectors;
import java.util.*;

public class demoComprator {

	public static void main(String [] args) {
		List<Laptop>laps= new ArrayList<>();
		laps.add(new Laptop("apple",1000,8));
		laps.add(new Laptop("hp",700,13));
		laps.add(new Laptop("lenovo",5000,4));
		
		//Comprator--uses compare method
//		Comparator <Laptop> com= new Comparator<Laptop>() {
//
//
//			public int compare(Laptop o1, Laptop o2) {
//
//         if(o1.getPrice()<o2.getPrice())
//				return 1;
//             else 
//                return 0;
//			}};
//			Collections.sort(laps,com);
			for(Laptop l:laps) {
				System.out.println(l);
			}
			
			
//		List<Laptop>laplist=new ArrayList<>();
//		List<Laptop>laplist=laps.stream().filter(c->c.getBrand().equals("hp")).collect(Collectors.toList());
//		System.out.println(laplist);
		
	
}
}
