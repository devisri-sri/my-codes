package com.july2022;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1;i<=5;i++) {
			if(i==3) {
				continue;
			}
//			System.out.println("\n");
		System.out.println(i);

		//}
	}

}}
