package com.july2022;

public class max {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  System.out.println(largestNumber(132));
	}
 

private static int largestNumber(int data) {
	int num=data;
	int[]a= new int[10];
	while(num!=0) {
		if(num==0) {
			break;
		}
		int val=num%10;
		a[val]++;
		System.out.println(a[val]);
		num/=10;
	}
	String larg="";
	for(int i=9;i>=0;i--) {
		for(int j=0;j<a[i];j++) {
			larg+=i;
		}
	}
	return Integer.parseInt(larg);
	
}
}