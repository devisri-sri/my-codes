package com.july2022;
import java.util.*;

public class stringConcat {
	public static void main(String args[]) {
		Scanner sc= new Scanner(System.in);
		String s= sc.next();
		StringBuilder res= new StringBuilder();
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)>='a' && s.charAt(i)<='z')
			{
				 if (s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')	{
					 res.append("#");
				 }
				 else
				 {
					 res.append(s.charAt(i));
				 }
					
			}
		}
		
		res.append(res);
		System.out.println(res);
	}

}

