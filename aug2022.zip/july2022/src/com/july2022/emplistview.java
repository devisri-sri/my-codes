package com.july2022;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class emplistview {
  
	public static void main(String [] args) {
		List<Employee>emp=new ArrayList<>();
		emp.add(new Employee(1,"sri",6789));
		emp.add(new Employee(2,"sai",5789));
		emp.add(new Employee(3,"saniv",6799));
		
		emp.stream().filter(e->e.getSalary()>5000 && e.getName().equals("sri")).forEach(System.out::println);    
		
				
//		System.out.print(names);
	}
}
