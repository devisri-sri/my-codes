package com.july2022;

import java.util.Arrays;

public class evenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[]= {2,9,7,11,18,16,19,23,26};
		int index=0;
		int a[]= new int[array.length];
		for(int i=0;i<array.length;i++) {
			if(array[i]%2==0) {
				a[index]=array[i];
				index++;
			}}
		Arrays.sort(a);

		for(int i=0;i<array.length;i++) {
			if(array[i]%2!=0) {
				a[index]=array[i];
				index++;
		}
	
	}
		for(int i=0;i<a.length;i++) {
		System.out.println(a[i]+ ",");
		}

}
}
