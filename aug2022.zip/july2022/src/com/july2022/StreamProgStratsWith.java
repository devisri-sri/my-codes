package com.july2022;
import java.util.*;

public class StreamProgStratsWith {
 public static void main(String  args[]) {
	 List<Integer> numbers= Arrays.asList(10,12,18,19,20,24);
	 numbers.stream().map(s->s +" ").filter(s->s.startsWith("1")).forEach(System.out::println);
	 
 }
}
