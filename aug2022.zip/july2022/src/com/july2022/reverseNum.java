package com.july2022;

import java.util.Scanner;

public class reverseNum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num =sc. nextInt();
		int sum=0;
		
		while(num!=0) {
			int rem= num%10;
			 //sum= (rem*rem*rem)+sum;//armstrong num
			 sum=sum*10+rem;//reverse of a number
			 num= num/10;
		}
		System.out.println(sum);
			
	}

}
