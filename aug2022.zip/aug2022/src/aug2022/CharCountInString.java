package aug2022;

public class CharCountInString {
	public static void main(String args[]) {
	String a="elephantee";
	long count=a.chars().filter(c->c=='e').count();
	System.out.println(count);

}
}