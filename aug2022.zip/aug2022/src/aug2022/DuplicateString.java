package aug2022;

import java.util.LinkedHashSet;
import java.util.Set;


public class DuplicateString {
	public static void main(String args[]) {
		String name="abcdeabcdladf";
		Set<Character>duplicate= new LinkedHashSet<>();
		for(int i=0;i<name.length();i++) {
			for(int j=i;j<name.length();j++) {
				if(name.charAt(i)== name.charAt(j)){
					duplicate.add(name.charAt(i));
					
				}
				
			}
		}
		System.out.println(duplicate);
	}

}
