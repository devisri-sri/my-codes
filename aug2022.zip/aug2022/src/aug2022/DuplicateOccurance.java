package aug2022;

import java.util.HashMap;

public class DuplicateOccurance {
	public static void main(String args[]) {
		String str="java is JAva AgaiN is it";
		
		duplicateStrings(str);
	}
	static void duplicateStrings(String input) {
		String[] words= input.split(" ");
		HashMap<String,Integer>map= new HashMap<String,Integer>();
		for (String s:words) {
			if(map.containsKey(s.toLowerCase())) {
				map.put(s.toLowerCase(),map.get(s.toLowerCase())+1 );
			}
			else {
				map.put(s.toLowerCase(),1 );

			}}
		
		System.out.println("word is"+map+"and occurance is "+map.keySet());
		
	
}}
