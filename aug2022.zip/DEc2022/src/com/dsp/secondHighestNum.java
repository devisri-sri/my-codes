package com.dsp;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class secondHighestNum {
public static void main(String [] args) {
	Scanner sc= new Scanner(System.in);
	List<Integer>arr=Arrays.asList(1,7,9,11,34,44,21,87);
	int n=sc.nextInt();
	 int a[]= new int[n];
	 for(int i=0;i<n;i++) {
		 a[i]=sc.nextInt();
		 
	 }
	 for(int i=0;i<n;i++) {
		 System.out.println(a[i]);
	 }
List<Integer> ar=	arr.stream().sorted(Comparator.reverseOrder()).filter(i->i%2!=0).limit(2).skip(1).collect(Collectors.toList());
System.out.println(ar);
}
}
