package com.dsp;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

 

public class StreamsDemoFilter {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        ArrayList<Integer> al = new ArrayList<Integer>();
         for(int i=13;i<25;i++)
         {
             al.add(i);

         }

        List<Integer>as = al.stream().filter(i->i%2==0).collect(Collectors.toList());
       // List<Integer> asd = al.stream().filter(i->i%2==0).collect(Collectors.toList());
        System.out.println(as);
        System.out.println(al);
    }

 

}