package com.dsp;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer>x1 = (i)->i>10;
        boolean b = x1.test(34);
        System.out.println("the number is greater than 10 "+b);
	}

}
