package com.dsp;

@FunctionalInterface
interface InterDemo
{
    public int square(int a);
    
}



/*class Myclass implements InterDemo
{



   @Override
    public void show() {
        // TODO Auto-generated method stub
        System.out.println("hello from interfaces");
    }
    
}*/



public class InterfaceDemo {



   public static void main(String[] args) {
        // TODO Auto-generated method stub
       //Myclass m = new Myclass();
       //m.show();
        InterDemo itnr = (a)->{
        return a*a;
        };
        
        int value=itnr.square(45);
        System.out.println("the square of the number  " + value);
        
    }



}