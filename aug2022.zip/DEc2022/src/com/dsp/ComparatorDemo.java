package com.dsp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;



class Students
{
    int rollNo;
    String nmae;
    double marks;
    public Students(int rollNo, String nmae, double marks) {
        super();
        this.rollNo = rollNo;
        this.nmae = nmae;
        this.marks = marks;
        
    }
    @Override
    public String toString() {
        return "Student [rollNo=" + rollNo + ", nmae=" + nmae + ", marks=" + marks + "]";
    }
}
class RollnoComparator implements Comparator<Students>
{



   @Override
    public int compare(Students o1, Students o2) {
        // TODO Auto-generated method stub
        
        if(o1.rollNo>o2.rollNo)
        {
        return 1;
        }
        else if(o1.rollNo<o2.rollNo)
        {
            return -1;
        }
        else
            return 0;
    }



   
    }
    
class NameComparator implements Comparator<Students>
{



   @Override
    public int compare(Students o1, Students o2) {
        // TODO Auto-generated method stub
        return o1.nmae.compareTo(o2.nmae);
    }



   
    
}
public class ComparatorDemo {



   
    public static void main(String[] args) {
        
    Students    s1 = new Students(111,"Sumit",90.0);
    Students    s2 = new Students(34,"Rohit",45.0);
    Students    s3 = new Students(456,"Pavan",56.5);
    Students    s4 = new Students(12,"Shreya",23.0);
    
    ArrayList<Students>as = new ArrayList<Students>();
    as.add(s1);
    as.add(s2);
    as.add(s3);
    as.add(s4);
    System.out.println("printing student details using for loop");
    for(Students s:as) {
        
        System.out.println(s.rollNo);
        System.out.println(s.nmae);
        System.out.println(s.marks);
    }
    System.out.println("The student list is " +as);
    Collections.sort(as,new RollnoComparator());
    System.out.println("After sorting the student list is " + as);
    Collections.sort(as,new NameComparator());
    System.out.println("After sorting the student list according to alphabetical order  is " + as);
    
    }



}