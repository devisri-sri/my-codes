package com.dsp;

import java.util.HashSet;
import java.util.Set;

public class SetMonday {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer>hs = new HashSet<Integer>();
		hs.add(78);
		hs.add(78);
		boolean s = hs.add(78);
		hs.add(45);
		hs.add(59);
		hs.add(32);
		hs.add(null);
		System.out.println(hs);
	}

}
