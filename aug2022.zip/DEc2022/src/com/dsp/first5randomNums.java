package com.dsp;

import java.util.Random;
import java.util.Scanner;

public class first5randomNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
int n=sc.nextInt();
Random random= new Random();
random.ints(1,100).limit(n).forEach(System.out::println);
	}

}

