package com.dsp;

import java.util.function.Predicate;

public class PredicatePreDefined {
	public static void main(String[] args) {
        // TODO Auto-generated method stub
         Predicate<Integer>p3 = (i)->i>10;
         System.out.println("The number is greater than 10"+p3.test(45));
         Predicate<Integer>p4 = (i)->i%2==0;
         System.out.println("the Number is Even"+p4.test(45));

         String[] arr = {"Priyanka","Ankita","Sushmita","Divya","Akash","Ankit","Arnab"};
         Predicate<String>ps = (s)->s.charAt(0)=='A';
         for(String ss:arr)
         {
             if(ps.test(ss))
             {
                 System.out.println(ss);
             }
         }
    }

 

}

