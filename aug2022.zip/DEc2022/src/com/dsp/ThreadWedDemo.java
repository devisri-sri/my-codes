package com.dsp;

class MyThread implements Runnable
{
    
    @Override
    public void run() {
        // TODO Auto-generated method stub
        System.out.println(Thread.currentThread().getName());
    }
    
}



public class ThreadWedDemo {



   public static void main(String[] args) {
        // TODO Auto-generated method stub
        MyThread m1 = new MyThread();
        Thread t = new Thread(m1,"Mayas");
        t.start();
        System.out.println(Thread.currentThread().getName());



   }



}
