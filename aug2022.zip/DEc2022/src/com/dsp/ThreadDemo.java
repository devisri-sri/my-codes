package com.dsp;

/*class Mythread implements Runnable
{



   @Override
    public void run() {
        // TODO Auto-generated method stub
        for(int i=0;i<5 ;i++)
        {
            System.out.println(Thread.currentThread().getName()+i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    
}
*/



public class ThreadDemo {



   public static void main(String[] args) throws InterruptedException {
        // TODO Auto-generated method stub
       Runnable r = ()->
       {
           for(int i=0;i<2 ;i++)
           {
               System.out.println(Thread.currentThread().getName()+i);
               try {
                   Thread.sleep(500);
               } catch (InterruptedException e) {
                   // TODO Auto-generated catch block
                   e.printStackTrace();
               }
           }   
           
       };
        Thread t = new Thread(r,"LamdaChild");
        t.start();
         for(int i=0;i<=4;i++)
         {
             System.out.println(Thread.currentThread().getName()+i);
             Thread.sleep(1000);
         }
    }



}