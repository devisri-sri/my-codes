package com.dsp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WordsCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> list= Arrays.asList("aa","cc","adc","dd","aa","dd");
Map<String,Long> words= list.stream().filter(w->Collections.frequency(list, w)>1).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	System.out.println(words);
	}

}
