package com.dsp;

import java.util.function.Consumer;
import java.util.function.Function;

public class FunctionPreDefined {
	public static void main(String[] args) {
        // TODO Auto-generated method stub
   Function<Integer,Integer>fi = i->i*2;
  System.out.println ("The double of the number"+fi.apply(89));

  Function<Integer,Integer>f2 = i->i*i*i;
  System.out.println("The cube of the number is " +f2.apply(6));
  
  Function<String,Integer>f5 = s->s.length();
    System.out.println("the length of the String = "+f5.apply("Maya"));
    
Consumer<String>cs = (s)->System.out.println(s);
cs.accept("Lambda expressions help us to write concise code");
    }
}

