package com.dsp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {



	   



	   public static void main(String[] args) {
	        // TODO Auto-generated method stub
	    HashMap hs = new HashMap();
	    hs.put(101,"Amit");
	    hs.put(102, "Meenu");
	    hs.put(105, "Rakesh");
	    hs.put(107, "Pinky");
	    System.out.println(hs);
	    Set set = hs.entrySet();
	    System.out.println(set);
	    Iterator iterator = set.iterator();
	    while(iterator.hasNext())
	    
	    {
	        Map.Entry entry=(Map.Entry)iterator.next();
	        System.out.print(entry.getKey()+" ");
	        System.out.print(entry.getValue());
	        System.out.println();
	    }
	    }



	}