package com.dsp;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
public class HashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Map<String,Integer> hashmap=new HashMap<>();
hashmap.put("one", 1);
hashmap.put("two", 2);
hashmap.put("three", 3);
hashmap.put("one", 8);
System.out.println(hashmap);
	}

}
