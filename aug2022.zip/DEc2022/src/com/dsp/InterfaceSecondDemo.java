package com.dsp;


interface interone
{
    public void one();
    public void two();
    default void three()
    {
        System.out.println("hello from default");
    }

}
class A implements interone
{

 

    @Override
    public void one() {
        // TODO Auto-generated method stub
    System.out.println("hello from one");    
    }

 
//if we don't want to override all methods in interface, 
// if we want partial implementation then go with abstract class
    @Override
    public void two() {
        // TODO Auto-generated method stub
        System.out.println("hello from two");
    }

}
class B implements interone
{

 

    @Override
    public void one() {
        // TODO Auto-generated method stub
        System.out.println("hello from one in B");    
    }

 

    @Override
    public void two() {
        // TODO Auto-generated method stub
        System.out.println("hello from two in B");    
    }
    public void three()
    {
        System.out.println("b's overridden version");

    }

}
public class InterfaceSecondDemo {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
       interone io = new A();
       io.three();
       interone io2 = new B();
       io2.three();
    }

 

}