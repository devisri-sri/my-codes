package com.dsp;



import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;



class Student implements Comparable<Student>
{
    int rollNo;
    String name;
    double marks;
    Student(int rollNo,String name,double marks)
    {
        this.rollNo = rollNo;
        this.name = name;
        this.marks = marks;
    }
    @Override
    public String toString() {
        return "Student [rollNo=" + rollNo + ", name=" + name + ", marks=" + marks + "]";
    }
    @Override
    public int compareTo(Student o) {
        // TODO Auto-generated method stub
        
        if(rollNo == o.rollNo)
        {
            return 0;
        }
        else if(rollNo>o.rollNo)
        {
            return 1;
        }
        else
        {
        return -1;
        }
        
    }
    
}



public class StudentDemoList {
public static void main(String[] args) {
        // TODO Auto-generated method stub
     ArrayList<Student>stud_list = new ArrayList<Student>();
     
     Scanner sc= new Scanner(System.in);
     
     while(true)
     {
         System.out.println("Enter the student details");
         System.out.println("enter the rollNo");
         int rno = sc.nextInt();
         System.out.println("Enter the name");
         String name = sc.next();
         System.out.println("enter the marks");
         double marks = sc.nextDouble();
     
     stud_list.add(new Student(rno,name,marks));
     System.out.println("Do you want to add one more object type Yes or NO");
     
     String option= sc.next();
     if(option.equalsIgnoreCase("No"))
     {
         break;
         
     }
     
    }
     Collections.sort(stud_list);
     System.out.println("The student details are " +stud_list);
   }


}