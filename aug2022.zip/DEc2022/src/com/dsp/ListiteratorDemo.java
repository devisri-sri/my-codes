package com.dsp;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListiteratorDemo {

public static void main(String[] args) {
	        // TODO Auto-generated method stub
	    ArrayList<String>al = new ArrayList<String>();
	    al.add("one");
	    al.add("two");
	    al.add("three");
	    al.add("four");
	    ListIterator litr = al.listIterator();
	    System.out.println("travelling in the forward direction");
	    while(litr.hasNext())
	    {
	        System.out.println(litr.next());
	    }
	    System.out.println("traversing backwards");
	    while(litr.hasPrevious())
	    {
	        System.out.println(litr.previous());
	    }



	   }



	}