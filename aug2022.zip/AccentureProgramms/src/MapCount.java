import java.util.HashMap;
import java.util.Map;

public class MapCount {

	public static void main(String[] args) {
String str= "hello world hello akka";
String[] words= str.split("\\s+");
Map<String,Integer>map= new HashMap<>();
for(String word:words) { 
	word=word.replaceAll("[^a-zA-Z]", "");

		map.put(word, map.getOrDefault(word, 0)+1);
	}
	for(Map.Entry<String, Integer> entry : map.entrySet()) {
		System.out.println(entry.getKey() + ": "  + entry.getValue());
	}
	
}
}

	

