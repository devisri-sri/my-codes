import logo from './logo.svg';
import './App.css';
import Header from "./component/Header";
import Main from "./component/Main";
import Footer from "./component/Footer"
import SearchDemo from './component/SearchDemo';
import React, {useContext,useState} from "react";
import ComponentC from "./component/ComponentC"
export  const userContext=React.createContext();
export const  compContext=React.createContext();
function App() {
  let [fullName,setFullName]=useState({"fn":"Vais","ln":"Sri"})
  return (
    // <div className="App">
    /*<Header compName="capgemini" location="Pune"/>
    <hr color="grey" size="5"/>
    <Main year="2022"/>
    <hr color="blue" size="5"/>
  <Footer></Footer>*/
  /* <SearchDemo></SearchDemo> */
  <div className="AppClass">
    <SearchDemo></SearchDemo> 
       <Header compName="Capgemini" location="Pune"/>
        <userContext.Provider value={fullName}>
            <compContext.Provider value={"Capgemini"}>
            <ComponentC/>
              </compContext.Provider>
        </userContext.Provider>  
     
          
    </div>
    
  );
}

export default App;
