const redux=require("redux");
const reduxLogger=require("redux-logger");
const createStore=redux.createStore;
const combineReducer= redux.combineReducers;
const applyMiddlewayre=redux.applyMiddleware;
const logger=reduxLogger.createLogger();
//----define action name
const BUY_CAKE="BUY_CAKE";
const BUY_ICECREAM="BUY_ICECREAM";
//-----Define intital state---
const initialCakeState={
    noOfCake:40
}
const initialIcecreamState={
    noOfIcecream:10
}
function buyCake()
{
    return{type:BUY_CAKE,payload:"This is my cake action"}
}
function buyIcecream()
{
    return{type:BUY_ICECREAM,payload:"This is icecream action"}
}
///----------------cake reducer-----------------
function cakeReducer(state=initialCakeState,action)
{
    switch(action.type)
    {
        case BUY_CAKE:
            return {...state,noOfCake:state.noOfCake-1};
        default:
            return state;
    }
}
//---------------ice cream reducer-------------
function icecreamReducer(state=initialIcecreamState,action)
{
    switch(action.type)
    {
        case BUY_ICECREAM:
            return {...state,noOfIcecream:state.noOfIcecream-1};
            default:
                return state;
    }
}
//-------------combine both the reducer------------
const rootReducer=combineReducer
({cake:cakeReducer,ice:icecreamReducer})
//----------------create store----------------
const store=createStore(rootReducer,applyMiddlewayre(logger));
//----------------------print initial state-------------
console.log("...Intial state "+store.getState());
//-----------------dispatch 3 action for buying cake
//--------------2 actions for buying ice cream------
store.dispatch(buyCake());
store.dispatch(buyCake());
store.dispatch(buyCake());
store.dispatch(buyIcecream());
store.dispatch(buyIcecream());