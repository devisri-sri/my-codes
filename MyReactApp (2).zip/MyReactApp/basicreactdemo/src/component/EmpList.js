import React from "react";
class EmpList extends React.Component{
    constructor(props)
    {
        super();
        this.state={
            nums:[70,20,100,40,300],
            emps:[
                {"empId":222,"empName":"sri","empSal":300.0},
                {"empId":111,"empName":"sai","empSal":100.0},
                {"empId":333,"empName":"venky","empSal":700.0},
                {"empId":100,"empName":"datta","empSal":1000.0}
                
            ]
        }
    }
    render()
    {
        var intList=this.state.nums.map((num,index)=>
        {return(<h2 key={index}>INDEX: {index}-VALUE: {num}</h2>)});
        var empList=this.state.emps.map((emp,index)=>
        {return(<h2 key={index}>EMPID: {emp.empId}- NAME: {emp.empName}- SALARY: {emp.empSal}</h2>)});
        
        return (<div>{intList}{ empList}</div>);
    }
}
export default EmpList;
