import React from "react";
class Footer extends React.Component{
    constructor(props)
    {
        super();
    }
    render()
    {
        return(<p>@CopyRight of capgemini </p>);
    }
    }
    export default Footer;