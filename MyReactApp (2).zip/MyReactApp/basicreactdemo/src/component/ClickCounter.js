import React ,{Component} from "react";
import Counter from "./Counter"
class ClickCounter extends Component
{    
    render()
    {
        const {count,incrementCount}=this.props;
        return (<div><h3 onClick={incrementCount}>
         Button  Click  {count} Time</h3></div>)

    }   
}
export default  Counter(ClickCounter);