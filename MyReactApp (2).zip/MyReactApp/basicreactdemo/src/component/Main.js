import React from "react";
import EmpList from "./EmpList";
import Login from "./Login";
class Main extends React.Component{
    /*constructor(props){
        super();
        this.state={ msg:"Happy New Year",
    firstName:"devisri"
}
    }
    render(){
        return(<div>{this.state.msg} : {this.props.year} : {
            this.state.firstName}
            <br/>
            <EmpList/><br/>
            <Login/>
            </div>);
          
    }
}
export default Main;*/
constructor(props)
{
    super();
    this.state={
         msg:"Happy New Year",
         firstName:"Lakshman" ,
         count:0 ,
         fullName:{fn:"Vaishali",ln:"Srivastava"}       
        } 
}
//--------------------
incCount=()=>{
       this.setState((prevState)=>{
            return {count:prevState.count+1}
       })
}
//----------------------
decCount=()=>{
   this.setState({count:this.state.count-1})
}
//-------------------------
render()
{
    return (<div> {this.state.msg} : {this.props.year} : 
    {this.state.firstName}
    <br/>
    <button onClick={this.incCount}>IncreseCounter</button>
    {this.state.count}
    <button onClick={this.decCount}>DEcreseCounter</button>
    <br/>
     FirstName: 
     {/*<input type="text" value={this.state.fullName.fn} name="fn"
      onChange={(event)=>{ this.setState({fullName:{fn:event.target.value}} )}}/><br/>
     LastName:<input type="text" value={this.state.fullName.ln} name="ln"
     onChange={(event)=>{ this.setState({fullName:{ln:event.target.value}} )}}/><br/>
    */}
    <input type="text" value={this.state.fullName.fn} name="fn"
      onChange={(event)=>{this.setState(
          prevState=>({
              fullName:{...prevState.fullName,fn:event.target.value}
          })
       )}}/><br/>   
         <input type="text" value={this.state.fullName.ln} name="ln"
      onChange={(event)=>{this.setState(
          prevState=>({
              fullName:{...prevState.fullName,ln:event.target.value}
          })
       )}}/><br/>         

      First name {this.state.fullName.fn } - LastName : {this.state.fullName.ln}
    <EmpList/>
    <Login/>
    </div>);
}  
}
export default Main;