import ComponentE from "./ComponentE";

function ComponentC(props)
{
    return (<ComponentE/>)
}
export default ComponentC;