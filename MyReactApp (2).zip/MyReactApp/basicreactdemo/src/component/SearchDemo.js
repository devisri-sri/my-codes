import  React,{useState,useEffect} from "react";

var SearchDemo=(props)=>{

    let [count,setCount]=useState(1);
    let [location,setLocation]= useState("Pune");
    let [name,setName]=useState({fn:"",ln:""})
    let [items,setItems]=useState([]);

    //-----------------------------
    var numList=   items.map((ent)=>{
        return <li key={ent.id}> Value:{ent.value}</li>
    })
    //--------------------------------
    console.log(" Inside SeachDemo..........");
    //---------------------------------------
    useEffect(()=>{
        console.log(" Inside UseEffect .....");
    },[count]);
    //-------------------------------
    function decCount()
    {
        console.log("decCount Called..");
        setCount(--count);
    }
    //--------------------------------
    function changeLN(event)
    {
        console.log(" changeLN  called............");
        setName({...name,ln:event.target.value});
    }
    function addItem()
    {
        console.log(" addItem  called............");
        setItems([...items,{
            id:items.length,
            value:Math.floor(Math.random()*10)+1
         } ])
    }
    //---   -------------------------------------
    return(<div><h3>This is Srach Demo  Func Comp</h3>
        <button onClick={()=>{setCount(++count)}}>Inc</button>
            Count :{count}
        <button onClick={decCount}>Dec</button>  
        <hr/>
        FirstName:<input type="text"
        value={name.fn} onChange=
        {(event)=>{setName({...name,fn:event.target.value})}}
        />  
        LastName:<input type="text" name="ln"
        value={name.ln} onChange={(event)=>{changeLN(event)}}
        />  
        <br/>
        <button onClick={addItem} > Generate Number and Add In Array</button>
         Number Gerated :{numList  }
        </div>
    );
}


export default SearchDemo;
