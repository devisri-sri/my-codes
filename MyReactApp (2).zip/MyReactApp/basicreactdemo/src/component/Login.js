import React from "react";
class Login extends React.Component{
    constructor(props)
    {
        super();
        this.state={
            isLoggedIn:false
        }
    }
    handleClick=()=>
    {
        this.setState({isLoggedIn:!this.state.isLoggedIn})
    }
        render()

        {
    
            let buttonText=
    
            this.state.isLoggedIn?"LOGIN":"LOGOUT";
    
            let worldDisp;
    
            if(this.state.isLoggedIn==true)
    
            {
    
                worldDisp="IN"
    
            }
    
            else
    
            {
    worldDisp="OUT"
    
            }
    
          return(<div>
    
              <h2>Now You Are Log :{worldDisp} </h2>
    
              <button onClick={this.handleClick}>{buttonText}</button>
    
             </div>);
    
        }
    
    }
    
    export default Login;

