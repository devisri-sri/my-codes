import React from "react";
function Header(props){
return(
    <div><h2>Welcome To: {props.compName}
    :At location {props.location}</h2></div>
)
}
export  default Header;