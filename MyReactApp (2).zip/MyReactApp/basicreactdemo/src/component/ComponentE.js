import React,{Component,useContext} from "react";
 import {userContext,compContext} from "../App"
function ComponentE()
{   
    let usr=useContext(userContext);
    let cnm=useContext(compContext)
    return (<div>This Is Component E
<br/>
 Welcome :{usr.fn}  -   {usr.ln} - In : {cnm}

    </div>);

}
export default ComponentE