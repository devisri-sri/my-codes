const redux=require("redux");
const reduxLogger=require("redux-logger");
const thunkMiddleware=require("redux-thunk").default;
const axios=require("axios");

const createStore=redux.createStore;
const combineReducer=redux.combineReducers;
const applyMiddlewayre=redux.applyMiddleware;
const logger=reduxLogger.createLogger();
//-------------------------
const empUrl="  http://localhost:3000/emps";

//----------define action name---------
const FETCH_EMP_REQUEST="FETCH_EMP_REQUEST";
const FETCH_EMP_SUCCESS="FETCH_EMP_SUCCESS";
const FETCH_EMP_FAILURE="FETCH_EMP_FAILURE";
const DELETE_EMP_REQUEST=" DELETE_EMP_REQUEST";

//-------------Define initial state-------------------
const initialEmpState={
    loading:false,
    emps:[],
    error:""
}
//----------1 action creator-----------------
function fetchEmpRequest()
{
   return {type:FETCH_EMP_REQUEST,payload:" Loading..........."}
}
//------------------2 action creator
function fetchEmpSuccess(emps)
{
    return {type:FETCH_EMP_SUCCESS ,payload:emps}
}
//-------------------------3
function fetchEmpFailure(error)
{
    return {type:FETCH_EMP_FAILURE,payload:error}
}
//-------------------4----
function deleteEmpRequest(emps)
{
    return {type:DELETE_EMP_REQUEST,payload:emps}
}
//--------------------reducer-------------------
const empReducer=function(state=initialEmpState,action)
{
    switch(action.type)
    {
        case FETCH_EMP_REQUEST:
            return {...state,loading:true}
        case FETCH_EMP_SUCCESS: 
                 return {...state,emps:action.payload}
        case FETCH_EMP_FAILURE: 
                 return {...state,error:action.payload}
        case  DELETE_EMP_REQUEST:
             return {...state,emps:action.payload}
        default : return state;
    }
}
//------------------------------------
function fetchEmp()
{
    return function(dispatch)
    {
          dispatch(fetchEmpRequest());
            axios.get(empUrl).
            then((empRes)=>{dispatch(fetchEmpSuccess(empRes.data))})
            .catch((empErr)=>{dispatch(fetchEmpFailure(empErr.message))})
    }
}

//----------create store--------------------
const store=createStore(empReducer,applyMiddlewayre(logger,thunkMiddleware));
//-----------dispatch action-------
store.dispatch(fetchEmp());
