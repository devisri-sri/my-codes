package com.cg.cb.userapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientLbUserAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
