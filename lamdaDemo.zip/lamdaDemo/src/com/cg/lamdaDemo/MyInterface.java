package com.cg.lamdaDemo;

public interface MyInterface {
	int add(int a,int b);

}
