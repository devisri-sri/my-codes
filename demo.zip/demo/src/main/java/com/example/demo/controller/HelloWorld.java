package com.example.demo.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController


public class HelloWorld {
	@Autowired
	private MessageSource messagesource;
//	@GetMapping("/")
//public String hello() {
//	return "<h1>hello sri</h1>" ;
//}
 
	//creating bean class
	@GetMapping("/hello-world")
	public Helloworldbean helloworldbean() {
	return new Helloworldbean("hello world");
	}
	// using path variable 
	@GetMapping("/hello-world/{name}")
		public Helloworldbean hellopath(@PathVariable String name) {
		return new Helloworldbean(String.format("Hello world %s", name));
			
		}
	@GetMapping("/hello-world-interationalistion")
	public String inter(@RequestHeader(name="Accept-Language",required=false)
	Locale locale) {
		return messagesource.getMessage("good.morning.message",null, "default message",
				LocaleContextHolder.getLocale());
	}
	
		
	}

