package com.example.demo.controller;

public class Helloworldbean {
	private String message;

	public Helloworldbean(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Helloworldbean [message=" + message + "]";
	}
	

}
