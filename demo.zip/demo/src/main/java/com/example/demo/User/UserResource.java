package com.example.demo.User;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


@RestController
public class UserResource {
	@Autowired
	private DaoService service;
	
	@GetMapping("/users")
	public List<Users> findall(){
		return service.findAll();
		
	}
	/*@GetMapping("/users/{id}")
	public Users getUserById(@PathVariable int id) {
		
		Users user= service.findById(id);
		if(user==null)
			throw new UserNotFoundException("user not present with given id "+id);
		return user;
	}*/
	@GetMapping("/users/{id}")
	public EntityModel<Users>retriveUser(@PathVariable int id) {
		
		Users user= service.findById(id);
		if(user==null)
			throw new UserNotFoundException("user not present with given id "+id);
		EntityModel<Users> model= EntityModel.of(user);
		WebMvcLinkBuilder linkToUsers=linkTo(methodOn(this.getClass()).findall());
		model.add(linkToUsers.withRel("all-users"));
		return model;
	}
	//getting status code as ok 200
	@PostMapping("/users")
	public void addUser( @RequestBody Users user) {
		Users saveuser=service.save(user);
		
	}
	// getting status code as created 201
	@PostMapping("/create-users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody Users user) {
		Users saveuser=service.save(user);
	URI location=	ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
		.buildAndExpand(saveuser.getId()).toUri();
		return ResponseEntity.created(location).build();
		
	}
	@DeleteMapping("/users/{id}")
	public void delete(@PathVariable int id) {
		Users deleteUser=service.deleteById(id);
		if(deleteUser==null)
			throw new UserNotFoundException("id"+id);
		
		
	}

}
