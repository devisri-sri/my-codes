import React,{Component} from "react";
import axios from "axios";
class ShowAddEmpPage extends Component{
    constructor(props)
    {
        super(props);
        this.state={
            empId:"", empName:"", empSal:0.0,isMarried:false,
            empObj:{"id":0, "empId": "","empName":"","empSal":0.0,
        "isMarried":false}
        }
    }
    handleSubmit=(event)=>{
        let tempEmpObj={
            "empId":this.state.empId,
            "empName":this.state.empName,
            "empSal":this.state.empSal,
            "isMarried":this.state.isMarried
        }
        this.setState({empObj:tempEmpObj});
        axios.post("http://localhost:3000/emps",tempEmpObj).
        then((empRes)=>{console.log("Data Inserted");
        window.alert("Data inserted");}).
        catch((empErr)=>{console.log("error in insert");
        alert("error in insert");
    });
    }
    handleChange=(event)=>{
        const {name,value,type,checked}=event.target;
        if(type==="checkbox"){
            this.setState({[name]:event.target.checked});
        }
        else{
            this.setState({[name]:event.target.value});
        }
    }
    render()
    {
        return(<div>
            Add Emp Details here.....
            <form name="empForm" onSubmit={this.handleSubmit} >
                EMPID:<input type="text" name="empId" required
                onChange={this.handleChange} />
                <div>Show error mesage here</div><br/>
                EMPNAME:<input type="text" name="empName" required
                onChange={this.handleChange} /><br/>
                 EMPSALARY:<input type="text" name="empSal" required
                onChange={this.handleChange} /><br/>
                IsMarried? <input type="checkbox" name="isMarried"
                checked={this.state.isMarried} onChange={this.handleChange} />
                <button type="submit"> ADD EMP</button>
            </form>  <hr/>
            <p> u entered : EMPID:{this.state.empId}- Name :{this.state.empName} 
            - SALARY :{this.state.empSal}</p>
        </div>);
    }
}
export default ShowAddEmpPage;