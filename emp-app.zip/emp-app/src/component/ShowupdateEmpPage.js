import React,{Component} from "react";
import axios from "axios";
class ShowupdateEmpPage extends Component
{
    constructor(props){
        super(props);
    }
    render()
    {
        return (<div>this is my update page</div>)
    }
}
export default ShowupdateEmpPage;