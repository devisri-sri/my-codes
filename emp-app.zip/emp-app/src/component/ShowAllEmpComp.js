import React,{Component} from "react";
import axios from "axios";

class ShowAllEmpComp extends Component
{
    constructor(props)
    {   
        super (props); 
        this.state={AllEmpData:[],errMsg:"" }       
    }
    //--------------------
    componentDidMount()
    {
        console.log("ShowAllEmpComp  componentDidMount  exceiuted ");
        axios.get("http://localhost:3000/emps")
        .then((empRes)=>{console.log("..."+empRes.data[3].empId);
                this.setState({AllEmpData:empRes.data});
    })
        .catch((empErrorRes)=>{console.log(" Error in reading Emp data "+
        empErrorRes);});
    }
    //----------------
    updateEmp=(id)=>{
        // window.alert("id :" +id);
        this.props.history.push("/ShowupdateEmpPage/:id"+id);
    }
    render()
    {
        let empList=this.state.AllEmpData.
        map((emp,index)=>{
            let status=emp.isMarried?"Married":"Not Married"
                return(<tr key={emp.id}>
                    <td>{emp.id}</td>
                    <td>{emp.empId}</td>
                    <td>{emp.empName}</td>
                <td>{emp.empSal}</td>
                    <td>{status}</td>
                    <td><button>DELETE</button></td>
                    <td><button onClick={()=>{this.updateEmp(emp.id)}}>UPDATE</button></td>
                </tr>                
                )

        });

        return (<div><h2> All Emp Info</h2>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>EMPID</th>
                    <th>EMPNAME</th>
                    <th>EMPSAL</th>
                    <th>Ismarried?</th>
                    <th>Delete?</th>
                    <th>Update?</th>
                </tr>
                    {empList}
            </table>       
        
        </div>);
    }
}
export default ShowAllEmpComp 