import logo from './logo.svg';
import './App.css';
import React from 'react';
import {BrowserRouter as Router,Route,Link,NavLink,Routes} from "react-router-dom"
import ShowAllEmpComp from "./component/ShowAllEmpComp"
import ShowAddEmpPage from './component/ShowAddEmpPage';
import ShowupdateEmpPage from './component/ShowupdateEmpPage';
function App() {
  return (
    <Router>
          <div className="App">
           <li> <Link to="/">HOME</Link></li> 
           <li>  <Link to="/ShowAllEmpPage">SHOW ALL EMP</Link></li>
           <li>  <Link to="/ShowAddEmpPage">ADD EMP</Link></li>
           <li>  <Link to="/ShowDeleteEmpPage">DELETE EMP</Link></li>
           <li> <Link to="/ShowupdateEmpPage/:id">UPDATE EMP</Link></li>
          </div>  
          <hr size ="3" color="green"/>  
         <Routes> 
          <Route path="/ShowAllEmpPage" element={<ShowAllEmpComp/>}></Route > 
          <Route path="/ShowAddEmpPage" element={<ShowAddEmpPage/>}></Route >   
          <Route path="/ShowupdateEmpPage/:id" element={<ShowupdateEmpPage/>}></Route >   
          <Route></Route >   
          <Route></Route > 
        </Routes>    
    </Router>
  );
}
export default App;
