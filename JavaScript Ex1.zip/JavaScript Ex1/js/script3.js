

function loadSelectedCourse()
{
    
}