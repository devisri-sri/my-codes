
function click1()
{
    alert("You Clicked Button 1");
}

function click2()
{
    console.log("You Clicked Button 2");
}

function click3()
{
    document.write("You Clicked Button 3");
}