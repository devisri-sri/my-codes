

function countCharacters()
{
    //step1: read first-name from input-box
    var fnm = document.getElementById("txt-firstname").value;

    //step2: count characters
    var total = fnm.length;
    console.log("Total Characters =" + total);

    //step3: present your answer
    var ref = document.getElementById("tchars");
    document.getElementById("tchars").innerHTML = "Total Characters = " + total;
    document.getElementById("tupper").innerHTML = fnm.toUpperCase();
}