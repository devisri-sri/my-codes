package com.example.demo.User;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


@RestController
public class UserResource {
	@Autowired
	private DaoService service;
	@Autowired
	private UserRepository repository;
	@Autowired
	private PostRepository postrepository;
	//using embeded server values stored in server will get printed
	@GetMapping("/jpa/users")
	public List<Users> getall(){
		return repository.findAll();
		
	}
	@GetMapping("/jpa/users/{id}")
	public Optional<Users> getUserById(@PathVariable int id) {
		
		Optional<Users> user= repository.findById(id);
		if(!user.isPresent())
			throw new UserNotFoundException("user not present with given id "+id);
		return user;
	}
	//using hateoas genterating link
	@GetMapping("users/{id}")
	public EntityModel<Users>retriveUser(@PathVariable int id) {
		
		Users user= service.findById(id);
		if(user==null)
			throw new UserNotFoundException("user not present with given id "+id);
		EntityModel<Users> model= EntityModel.of(user);
		WebMvcLinkBuilder linkToUsers=linkTo(methodOn(this.getClass()).getall());
		model.add(linkToUsers.withRel("all-users"));
		return model;
	}
	
	//getting status code as ok 200
	@PostMapping("/users")
	public void addUser( @RequestBody Users user) {
		Users saveuser=service.save(user);
		
	}
	// getting status code as created 201
	@PostMapping("/jpa/users")
	public ResponseEntity<Object> createUser(@Valid @RequestBody Users user) {
		Users saveuser=repository.save(user);
	URI location=	ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
		.buildAndExpand(saveuser.getId()).toUri();
		return ResponseEntity.created(location).build();
		
	}
	@DeleteMapping("/jpa/users/{id}")
	public void delete(@PathVariable int id) {
		repository.deleteById(id);
//		if(deleteUser==null)
//			throw new UserNotFoundException("id"+id);
		
		
	}
	//retriving all posts of a user
	@GetMapping("/jpa/users/{id}/posts")
	public List<Post> getuserbyposts(@PathVariable int id) {
		
		Optional<Users> user= repository.findById(id);
		if(!user.isPresent())
			throw new UserNotFoundException("user not present with given id "+id);
		return user.get().getPosts();
	}
	@PostMapping("/jpa/users/{id}/posts")
	public ResponseEntity<Object> createPost(@PathVariable int id,@RequestBody Post post) {
		Optional<Users> useroptional= repository.findById(id);
		if(!useroptional.isPresent()) {
			throw new UserNotFoundException("user not present with given id "+id);}
	Users user=useroptional.get();
	post.setUser(user);
	postrepository.save(post);
	URI location=	ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
		.buildAndExpand(post.getId()).toUri();
		return ResponseEntity.created(location).build();
		
	}
	

}
