package com.example.demo.versioning;

public class Personv1 {
	 private String name;

	public Personv1(String name) {
		super();
		this.name = name;
	}

	public Personv1() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	 

}
