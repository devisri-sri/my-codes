import java.util.LinkedList;

public class QueeDemo {

	LinkedList quee;
	public boolean Isempty() {
		return quee.isEmpty();
	}
	public int size(){
		return quee.size();
	}
	public void enquee(int n) {
		quee.addLast(n);
	}
	public int dequee() {
		return (int)quee.remove(0); 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
