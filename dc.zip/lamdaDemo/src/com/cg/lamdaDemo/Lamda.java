package com.cg.lamdaDemo;

public class Lamda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInterface myInterfac=(int x,int y)->x+y;
		int result=myInterfac.add(10, 20);
				System.out.println(result);

	}

}
 