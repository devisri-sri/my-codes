package com.cg.opn.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.pojos.Employee;
import com.cg.opn.pojos.Plant;
import com.cg.opn.services.IEmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	 IEmployeeService service;
	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee employee) {
		return service.saveEmployee(employee);
		
	}
	 @GetMapping("/getEmployee/{id}")
	 public ResponseEntity<Employee>getById(@PathVariable int id){
		 Employee employee= service.getById(id);
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
		 
		 
	 }
	 
	
}
