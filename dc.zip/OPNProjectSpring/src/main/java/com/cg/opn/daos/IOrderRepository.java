package com.cg.opn.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.opn.pojos.Order;


@Repository
public interface IOrderRepository extends JpaRepository<Order, Integer>{



	
}