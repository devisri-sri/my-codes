package com.cg.opn.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "customers_table")
public class Customer {

	@Id
	@GeneratedValue
	@Column(name="id")
	private Integer id;

	@NotEmpty(message = "name should not empty")
	@Size(min = 4, message = "min 4 chars required")
	private String name;

	@NotEmpty(message = "email should not empty")
	@Size(min = 4, message = "min 4 chars required")
	private String email;
	
	
	@Pattern(regexp = "^[A-Za-z]{1}\\w{4,9}", message = "username Invalid")
	private String username;

	@Pattern(regexp = "^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])"
			+ "(?=\\S+$).{8,20}$", message = "password invalid")
	private String password;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	@Valid
	private Address address;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="id")
	@Valid
	private List<Order> orders;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(Integer id, String name, String email, String username, String password,
			Address address,List<Order> orders) {
		super();
		this.id = id;
		this.name =name;
		this.email = email;
		this.username = username;
		this.password = password;
		this.address = address;
		this.orders=orders;
	}

	public Customer(String name, String email, String username, String password, Address address,List<Order> orders) {
		super();
		this.name = name;
		this.email = email;
		this.username = username;
		this.password = password;
		this.address = address;
		this.orders=orders;
	}
	public Customer(String name, String email,String username,String password, Address address2) {
		super();
		this.name = name;
		this.email = email;
		this.username = username;
		this.password = password;
		this.address=address2;
	}
	public Customer( int id, String name, String email,String username,String password, Address address2) {
		super();
		this.id=id;
		this.name = name;
		this.email = email;
		this.username = username;
		this.password = password;
		this.address=address2;
	}
	

	
	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

		public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", username=" + username + ", password="
				+ password + ", address=" + address + ", orders=" + orders + "]";
	}

}
