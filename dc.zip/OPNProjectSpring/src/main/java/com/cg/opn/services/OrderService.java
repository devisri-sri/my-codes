package com.cg.opn.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.opn.daos.IOrderRepository;
import com.cg.opn.exceptions.OrderNotFoundException;
import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;
import com.cg.opn.pojos.Plant;
import com.cg.opn.pojos.Planter;
import com.cg.opn.pojos.Seed;

@Service
@Transactional
public class OrderService implements IOrderService {

	@Autowired
	IOrderRepository repository;

	@Override
	public Order addOrder(Order order) {
		return repository.save(order);
	}

	@Override
	public Order updateOrder(Order order) {
		int id = order.getId();
		if (!repository.existsById(id))
			throw new OrderNotFoundException("Order for update is not present with the id");
		return repository.save(order);
	}

	@Override
	public Order deleteOrder(Order order) {
		int id = order.getId();
		if (!repository.existsById(id))
			throw new OrderNotFoundException("Order for delete is not present with the given id");
		repository.deleteById(order.getId());
		return order;
	}


	@Override
	public Order getOrder(int id) {
		Optional<Order> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new OrderNotFoundException("Order details not found for id");
		return optional.get();
	}


	@Override
	public List<Order> getAllOrders() {
		List<Order> order1 = repository.findAll();

		if (order1.isEmpty()) {
			throw new OrderNotFoundException("No orders are present in the table");
		}
		return order1;
	}

	@Override
	public int plantersOrdered(int id) {
		Order order = repository.findById(id).get();
		List<Planter> list = order.getPlanters();
		return list.size();
	}


	@Override
	public int plantsOrdered(int id) {
		Order order = repository.findById(id).get();
		List<Plant> list = order.getPlants();
		return list.size();
	}

	@Override
	public int seedsOrdered(int id) {
		Order order = repository.findById(id).get();
		List<Seed> list = order.getSeeds();

		return list.size();
	}

	
	@Override
	public Customer getCustomerBasedOnOrder(int id) {
		Order order = repository.findById(id).get();
		return order.getCustomer();

	}


	@Override
	public List<String> AllOrdersPlaced(int id) {
		Order order = repository.findById(id).get();
		List<String> list = new ArrayList<>();
		List<Planter> list1 = order.getPlanters();
		List<Plant> list2 = order.getPlants();
		List<Seed> list3 = order.getSeeds();
		list.add("planters ordered:" + list1.size());
		list.add("Plants ordered:" + list2.size());
		list.add("Seeds ordered" + list3.size());
		return list;
	}

}
