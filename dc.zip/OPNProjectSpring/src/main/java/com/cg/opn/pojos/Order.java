package com.cg.opn.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name = "Order_Master")
public class Order {

	@Id
	@GeneratedValue
	@Column(name = "order_id")
	private Integer id;

	@NotNull(message = "Cost should not be null")
	private Double totalCost;

	private String orderDate;

	@NotEmpty(message = "Transaction mode should not empty")
	@Size(min = 2, message = "min 2 chars required")
	private String transactionMode;
	private int quantity;

	@JsonIgnore
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name="id")
	private Customer customer;

	@Valid
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "order_id")
	@Fetch(value=FetchMode.SELECT)
	private List<Planter> planters;
	@Valid
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "order_id")
	@Fetch(value=FetchMode.SELECT)
	private List<Plant> plants;
	@Valid
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "order_id")
	@Fetch(value=FetchMode.SELECT)
	private List<Seed> seeds;
	public Order() {
		super();
		
	}


	public Order(Integer id,Double totalCost, String orderDate, String transactionMode, int quantity,
			List<Planter> planters, List<Plant> plants, List<Seed> seeds) {
		super();
		this.id=id;
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
		this.plants = plants;
		this.seeds = seeds;
		
	}
	public Order(Integer id,  Double totalCost, String orderDate,String transactionMode,
			int quantity) {
		super();
		this.id = id;
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
	}


	public Order(Double totalCost, String orderDate, String transactionMode, int quantity,
			  List<Planter> planters,List<Plant> plants, List<Seed> seeds,Customer customer) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.customer=customer;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
		this.plants = plants;
		this.seeds = seeds;
		

	}


	public Order(Integer id,Double totalCost, String orderDate, String transactionMode, int quantity,
			List<Planter> planters) {
		super();
		this.id=id;
		
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
	}
	
	public Order( Double totalCost, String orderDate, String transactionMode,
			int quantity, List<Planter> planters) {
		super();
		
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
	}


	public Order(Integer id,Double totalCost, String orderDate, int quantity, 
			List<Seed> seeds,String transactionMode) {
		super();
		this.id=id;
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.seeds = seeds;
	}
	public Order(Integer id,Double totalCost, String orderDate, String transactionMode,
			List<Plant> plants,int quantity) {
		super();
		this.id=id;
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.plants = plants;
	}

	public Order( String orderDate, String transactionMode, int quantity,
			List<Plant> plants,Double totalCost) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.plants = plants;
	}


	public Order(Double totalCost,  String transactionMode, int quantity,
			List<Seed> seeds,String orderDate) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.seeds = seeds;
	}
	
	public Order( Double totalCost, String orderDate,String transactionMode,
			int quantity, List<Plant> plants, List<Seed> seeds) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.plants = plants;
		this.seeds = seeds;
	}
	public Order( Double totalCost, String orderDate,int quantity, List<Planter> planters,
			List<Seed> seeds,String transactionMode) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
		this.seeds = seeds;
	}

	public Order(Double totalCost,  String transactionMode,
			int quantity,String orderDate, List<Planter> planters, List<Plant> plants) {
		super();
		this.totalCost = totalCost;
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.planters = planters;
		this.plants = plants;
	}


	public Order(String orderDate, String transactionMode,Integer quantity,Double totalCost) {
		super();
		this.orderDate = orderDate;
		this.transactionMode = transactionMode;
		this.quantity = quantity;
		this.totalCost = totalCost;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Double getTotalCost() {
		return totalCost;
	}


	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}


	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public String getTransactionMode() {
		return transactionMode;
	}


	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public List<Planter> getPlanters() {
		return planters;
	}


	public void setPlanters(List<Planter> planters) {
		this.planters = planters;
	}


	public List<Plant> getPlants() {
		return plants;
	}


	public void setPlants(List<Plant> plants) {
		this.plants = plants;
	}


	public List<Seed> getSeeds() {
		return seeds;
	}


	public void setSeeds(List<Seed> seeds) {
		this.seeds = seeds;
	}
	


	public Customer getCustomer() {
		return customer;
	}



	@Override
	public String toString() {

		return "Order [id=" + id + ", totalCost=" + totalCost + ", orderDate=" + orderDate + ", transactionMode="
				+ transactionMode + ", quantity=" + quantity + ", planters="
				+planters+",plants=" +plants+", seeds=" + seeds + "]";

	}


}