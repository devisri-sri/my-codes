package com.cg.opn.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cg.opn.pojos.Order;
import com.cg.opn.pojos.Plant;
import com.cg.opn.services.IPlantService;


@RestController
public class PlantController {

	@Autowired
	IPlantService service;

	@PostMapping("/addPlant")
	public ResponseEntity<String>addPlant(@Valid @RequestBody Plant plant){
		plant=service.addPlant(plant);
		return new ResponseEntity<String>("plant been added sucessfully "+plant.getId(),HttpStatus.OK);
	}

	@PutMapping("/updatePlant")
	public ResponseEntity<Plant> updatePlant(@Valid  @RequestBody Plant plant) {
		Plant palntInfo = service.updatePlant(plant);
		return new ResponseEntity<Plant>(palntInfo, HttpStatus.OK);
	}
	@DeleteMapping("/deletePlant{id}")
	public ResponseEntity<String> deletePlant(@PathVariable("id") int id) {
	Plant deletedplant=service.deletePlant(id);
	return new ResponseEntity<String>("Plant deleted with given id" +deletedplant.getId(),HttpStatus.OK);
	}

	@GetMapping("/getPlants/{commonName}")
	public ResponseEntity<List<Plant>> getPlant(@PathVariable String commonName) {
		List<Plant> plants = service.getPlants(commonName);
		return new ResponseEntity<List<Plant>>(plants, HttpStatus.OK);
	}

	@GetMapping("/getPlant/{id}")
	public ResponseEntity<Plant> getPlant(@PathVariable("id") int id) {
		Plant plant = service.getPlantDetails(id);
		return new ResponseEntity<Plant>(plant, HttpStatus.OK);
	}

	@GetMapping("/getAllPlants")
	public ResponseEntity<List<Plant>> getPlants() {
		List<Plant> plants = service.getAllPlants();
		return new ResponseEntity<List<Plant>>(plants, HttpStatus.OK);
	}

	@GetMapping("/getAllPlants/{typeOfPlant}")
	public ResponseEntity<List<Plant>> getAllPlants(@PathVariable String typeOfPlant) {
		List<Plant> plants = service.getAllPlants(typeOfPlant);
		return new ResponseEntity<List<Plant>>(plants, HttpStatus.OK);
	}

	@GetMapping("/getOrderNoPlantId/{id}")
	public ResponseEntity<Order>  getOrderNoBasedOnPlant(@PathVariable("id") int id)
	{
		Order output=service.getOrderNoBasedOnPlant(id);
		return new ResponseEntity<Order>(output, HttpStatus.OK);
	}

}
