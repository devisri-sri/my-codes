package com.cg.opn.controllers;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;
import com.cg.opn.services.ICustomerService;
import com.cg.opn.services.IOrderService;

@RestController
public class CustomerController {
	
	@Autowired
	ICustomerService service;
  @Autowired
  IOrderService service2;
  
	
	@GetMapping("/getCustomer/{id}")
	public ResponseEntity<Customer> getCustomer(@PathVariable("id") int id) throws ResourceNotFoundException {
		Customer customer = service.getCustomer(id);
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

	@PostMapping("/addCustomer")
	public ResponseEntity<String> addCustomer(@Valid @RequestBody Customer customer) {
		Customer customerdetails = service.addCustomer(customer);
		return new ResponseEntity<String>("Customer added successfully"+customerdetails.getId(), HttpStatus.OK);
	}

	
	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		List<Customer> list= service.getAllCustomers();
		return new ResponseEntity<List<Customer>>(list, HttpStatus.OK);
	}
	
	@PutMapping("/updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@Valid @RequestBody Customer customer) throws ResourceNotFoundException {
		Customer Customerdetails = service.updateCustomer(customer);
		return new ResponseEntity<Customer>(Customerdetails, HttpStatus.OK); 	
	}
	
	@DeleteMapping("/deleteCustomer/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable("id") int id) {
		int result = service.deleteCustomer(id);
		return new ResponseEntity<String>("Deleted succesfully:"+result, HttpStatus.OK);
	}
	@GetMapping("/customeroperations/{type}")
	public ResponseEntity<String> customeroperations(@PathVariable("type") String type) {
		List<Order> result=new ArrayList<>();
		if(type.equals("order")) 
			result=service2.getAllOrders();
		return new ResponseEntity<String>("Order details" +result, HttpStatus.OK);
	}
	@GetMapping("/ordersplaced/{id}")
public  ResponseEntity<String>customerorders(@PathVariable("id") int id){
		int count= service.ordersplaced(id);  
	return new ResponseEntity<String>("order'splaced is" +count,HttpStatus.OK);

	}
}



