package com.cg.opn.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opn.daos.EmployeeRepository;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Employee;
import com.cg.opn.pojos.Plant;
@Service
public class EmployeeSErvice implements IEmployeeService {
@Autowired
	private EmployeeRepository repo;
	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repo.save(employee);
	}
	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		Optional<Employee> optional = repo.findById(id);
		if (!optional.isPresent())
			throw new ResourceNotFoundException("Plant details are not found for id " + id);
		return optional.get();
	}
	
	

}
