package com.cg.opn;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.cg.opn.pojos.Person;

public class XmlJson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person= new Person();
		person.setAge(26);
		person.setName("Sri");
        try {
			JAXBContext context = JAXBContext.newInstance(Person.class);
			
			//marshallws
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            StringWriter sw= new StringWriter();
            marshaller.marshal(person, sw);
            String xmlString= sw.toString();
            System.out.println(xmlString);
            
            //unmarshalling
            StringReader sr= new StringReader(xmlString);
            Unmarshaller unmarsh= context.createUnmarshaller();
        Person un=    (Person) unmarsh.unmarshal(sr);
        System.out.println(un.getName());
        System.out.println(un.getAge());


		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
