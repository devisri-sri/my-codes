package com.cg.opn.controllers;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.pojos.Seed;
import com.cg.opn.services.ISeedService;

	
	@RestController
	public class SeedController {

		@Autowired
		ISeedService service;

		@PostMapping("/addSeed")
		public ResponseEntity<String> addSeed(@Valid@RequestBody Seed seed) {
			seed = service.addSeed(seed);
			return new ResponseEntity<String>("Seed Details added Successfully " + seed.getId(), HttpStatus.OK);
		}


		@PutMapping("/updateSeed")
		public ResponseEntity<Seed> updateSeed(@Valid@RequestBody Seed seed) {
			Seed seed1 = service.updateSeed(seed);
			return new ResponseEntity<Seed>(seed1, HttpStatus.OK);
		}
	
		
		@DeleteMapping("/deleteSeed")
		public ResponseEntity<String>deleteSeed(@Valid@RequestBody Seed seed) {
			Seed seed3= service.deleteSeed(seed);
			return new ResponseEntity<String>("Seed Details deleted with id "+seed3.getId(), HttpStatus.OK);
		}

	
		@GetMapping("/getSeed/{seedId}")
		public ResponseEntity<Seed> getSeed(@PathVariable("seedId") int seedId) {

			Seed seed = service.getSeed(seedId);
			return new ResponseEntity<Seed>(seed, HttpStatus.OK);
		}

	
		@GetMapping("/getSeeds/{commonName}")
		public ResponseEntity<List<Seed>> getSeed(@PathVariable String commonName) {
			List<Seed> seeds = service.getSeed(commonName);
			return new ResponseEntity<List<Seed>>(seeds, HttpStatus.OK);
		}
		

		@GetMapping("/getAllSeeds")
		public ResponseEntity<List<Seed>> getSeeds() {
			List<Seed> seed = service.getAllSeeds();
			return new ResponseEntity<List<Seed>>(seed, HttpStatus.OK);
		}

		@GetMapping("/getSeedByType/{typeOfSeeds}")
		public ResponseEntity<List<Seed>> getSeedByType(@PathVariable String typeOfSeeds) {
			List<Seed> seeds2 = service. getAllSeeds(typeOfSeeds);
			return new ResponseEntity<List<Seed>>(seeds2, HttpStatus.OK);
		}
		
	}