package com.cg.opn.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;
import com.cg.opn.services.IOrderService;



@RestController

public class OrderController {

	@Autowired
	
	IOrderService service;

	@PostMapping("/addOrder")
	public ResponseEntity<String> addOrder(@Valid @RequestBody Order order)
	 {
		order = service.addOrder(order);
		return new ResponseEntity<String>("Order has been added successfully" + order.getId(), HttpStatus.OK);
	
	}

	@PutMapping("/updateOrder")
	public ResponseEntity<Order> updateOrder(@Valid @RequestBody Order order) {
		Order orderdetails = service.updateOrder(order);
		return new ResponseEntity<Order>(orderdetails, HttpStatus.OK);
	}

	@DeleteMapping("/deleteOrder")
	public ResponseEntity<String> deleteOrder(@RequestBody Order order) {
		Order orders = service.deleteOrder(order);
		return new ResponseEntity<String>("Order deleted with the id" + orders.getId(), HttpStatus.OK);
	}

	@GetMapping("/getOrder/{id}")
	public ResponseEntity<Order> getOrder(@PathVariable("id") int id) {
		Order order = service.getOrder(id);
		return new ResponseEntity<Order>(order, HttpStatus.OK);
	}

	@GetMapping("/getAllOrders")
	public ResponseEntity<List<Order>> getAllOrders() {
		List<Order> orders = service.getAllOrders();
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}
	@GetMapping("/PlantersOrdered{id}")
	public ResponseEntity<String> OrderPlanters(@PathVariable("id")int id){
		int count=service.plantersOrdered(id);
		return new ResponseEntity<String>(" planters ordered "+count,HttpStatus.OK);	
	}
	@GetMapping("/PlantsOrdered{id}")
	public ResponseEntity<String> OrderPlants(@PathVariable("id")int id){
		int count=service.plantsOrdered(id);
		return new ResponseEntity<String>(" plants ordered "+count,HttpStatus.OK);	
	}
	@GetMapping("/SeedsOrdered{id}")
	public ResponseEntity<String> OrderSeeds(@PathVariable("id")int id){
		int count=service.seedsOrdered(id);
		return new ResponseEntity<String>(" seeds ordered "+count,HttpStatus.OK);	
	}
	@GetMapping("/AllOrdersPlaced/{id}")
	public ResponseEntity<String> AllOrdersPlaced(@PathVariable("id")int id){
		List<String> list=service.AllOrdersPlaced(id);
		return new ResponseEntity<String>(" All orders: "+list,HttpStatus.OK);	
	}
	
	@GetMapping("/getCustomerforOrderid/{id}")
	public ResponseEntity<Customer>  getCustomerBasedOnOrder(@PathVariable("id") int id)
	{
		Customer output=service.getCustomerBasedOnOrder(id);
		return new ResponseEntity<Customer>(output, HttpStatus.OK);
	}

}
