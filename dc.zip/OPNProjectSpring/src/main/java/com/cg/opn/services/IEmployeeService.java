package com.cg.opn.services;

import java.util.Optional;

import com.cg.opn.pojos.Employee;

public interface IEmployeeService {
	Employee saveEmployee(Employee employee);
	Employee getById(int id);

}
