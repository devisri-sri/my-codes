package com.cg.opn.services;

import com.cg.opn.pojos.Admin;

public interface IAdminService {
	//public int getAdmin(int id);
	public String checkadmin(int id,String userName,String password);

	public String checkcustomer(int id, String username, String password);

}
