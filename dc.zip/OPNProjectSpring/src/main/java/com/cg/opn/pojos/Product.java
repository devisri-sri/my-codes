package com.cg.opn.pojos;

public class Product {
	private String name;
	private String address;
	private String productType;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	@Override
	public String toString() {
		return "Product [name=" + name + ", address=" + address + ", productType=" + productType + "]";
	}
	public Product(String name, String address, String productType) {
		super();
		this.name = name;
		this.address = address;
		this.productType = productType;
	}
	
	public Product() {
		
	}

}
