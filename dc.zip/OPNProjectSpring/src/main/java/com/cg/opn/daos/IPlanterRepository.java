package com.cg.opn.daos;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.opn.pojos.Planter;

@Repository
public interface IPlanterRepository extends JpaRepository<Planter, Integer>{
	
	public List<Planter> findAllByShape(String shape);
	public List<Planter> findAllByCostBetween(int minCost, int maxCost);
}
