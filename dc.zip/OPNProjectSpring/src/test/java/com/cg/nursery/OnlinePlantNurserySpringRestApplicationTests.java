package com.cg.nursery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinePlantNurserySpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
