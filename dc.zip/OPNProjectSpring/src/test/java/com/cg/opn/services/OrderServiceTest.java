package com.cg.opn.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.opn.exceptions.OrderNotFoundException;
import com.cg.opn.pojos.Order;


@SpringBootTest
class OrderServiceTest {
	@Autowired
	IOrderService service;

	@Test
	public void testaddOrder() throws OrderNotFoundException {
		Order order = new Order("5/2/2020", "offline", 67, 90.0);
		Order order1 = service.addOrder(order);
		assertNotNull(order1);
	}

	@Test
	public void testGetIdNotExists() {
		int id = 200;
		Exception exception = assertThrows(OrderNotFoundException.class, () -> service.getOrder(id));
		String message = "Order details not found for id";
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testGetIdExists() {
		int id = 268;
		Order order = service.getOrder(id);
		assertEquals(id, order.getId());
	}



	@Test
	public void deleteOrderByIdNotExists() {
		int id = 456;
		Exception exception = assertThrows(OrderNotFoundException.class, () -> service.getOrder(id));
		String message = "Order details not found for id";
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testgetAllOrders() {
		List<Order> list = service.getAllOrders();
		assertNotNull(list);
	}
}
