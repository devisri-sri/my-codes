package com.cg.opn.services;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.List;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Seed;


@SpringBootTest
class SeedServiceTest {
@Autowired
	ISeedService service;
	
	@AfterAll
	static void tearDownAfterClass() throws Exception{
	
	}
	@AfterEach
	void tearDown() throws ResourceNotFoundException{
		System.out.println("Clean up complete");
	}
	@Test
	public void testAddSeed() throws ResourceNotFoundException{
		Seed seed = new Seed("tomato", "winter", "morning", "high", "30C", "fruits", "lowgrowth", 22, 79,
				5600);
		Seed seeds = service.addSeed(seed);
		System.out.println(seeds + "added successfully");
		assertNotNull(seed);
	}
	
	@Test
	public void testgetId() {
		int id=253;
		Seed seed =service.getSeed(id);
		assertEquals(id,seed.getId());
	}
	

	@Test
	public void testIdNotFound() {
		int id=800;
		String message="Seed Details not found for id "+ id;
		Exception exception=assertThrows(ResourceNotFoundException.class,()->service.getSeed(id));
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testgetSeedByCommonName() {
		String commonName="bacopa";
		List<Seed> seed=service.getSeed(commonName);
		assertFalse(seed.isEmpty());
	}
	
	@Test
	public void testgetSeedByCommonNameNotExists() {
		String commonName="kiw";
		String message="No seeds are there with commonName:" + commonName;
		Exception exception=assertThrows(ResourceNotFoundException.class,()->service.getSeed(commonName));
		assertEquals(message, exception.getMessage());	
	}
	
	@Test
	public void testgetSeedByTypeOfSeeds() {
		String typeOfSeeds="bud";
		List<Seed> seed=service.getAllSeeds(typeOfSeeds);
		assertFalse(seed.isEmpty());
	}
	@Test
	public void testgetSeedByTypeOfSeedsNotExists() {
		String typeOfSeeds="kiw";
		String message="No seeds are there with typeofseeds:" + typeOfSeeds;
		Exception exception=assertThrows(ResourceNotFoundException.class,()->service.getAllSeeds(typeOfSeeds));
		assertEquals(message, exception.getMessage());	
	}
	@Test
	public void testUpdateSeedIfNotExists() {
		Seed seed = new Seed(100, null, null, null, null, null, null, null, 0, 0, null);
		int id=seed.getId();
		String message = ("Seed you are trying to update is not present with id:" + id);
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.updateSeed(seed));
		assertEquals(message, exception.getMessage());	
	}
	
	@Test
	public void testDeleteSeedIfNotExists() {
		Seed seed = new Seed(10, null, null, null, null, null, null, null, 0, 0, null);
		int id=seed.getId();
		String message = ("Seed you are trying to delete is not present with given id:"+ id);
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.deleteSeed(seed));
		assertEquals(message, exception.getMessage());	
	}
	
	@Test
	public void testIfSeedEmpty() {
		List<Seed> seed = service.getAllSeeds();
		assertFalse(seed.isEmpty());
		System.out.println("Seed is not empty");
	}
	
	@Test
	public void testgetAllSeeds() {
			List<Seed> seedList = service.getAllSeeds();
			assertFalse(seedList.isEmpty());
			System.out.println("seed Item Present Can Print Details");
		}
	}