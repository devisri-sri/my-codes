package com.cg;

public abstract class Fish {
	private void swim() {
		System.out.println("fish is swimming");
	}
	public static void main(String[] args) {
		Fish fish= new Duck();
		fish.swim();
		
	}

}
class Duck extends Fish{
	protected  void swim() {
		System.out.println("duck is swimming");
	}
	
}
