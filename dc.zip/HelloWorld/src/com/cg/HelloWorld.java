package com.cg;

import java.util.Scanner;

public class HelloWorld {
	public static  Boolean SumDivisibleByItsNo(int num) {
	
		int p=num;
		int sum=0;
		while(num>0) {
			int r= num%10;
			sum=sum+r;
			num=num/10;
		}
		if(p%sum==0) {
			return  true;
			
		}
		
		return false;}

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		HelloWorld.SumDivisibleByItsNo(n);
		Boolean flag= false;
		if(flag==true) {
			System.out.println("its a harshad number");
		}
		
		else {
			System.out.println("it is not  a harshad number");
		}

	}

}
