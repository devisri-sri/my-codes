package com.cg.demo;

import java.util.Scanner;

public class SubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String s= sc.nextLine();
		int start=sc.nextInt();
		int end=sc.nextInt();
		
		String sub=s.substring(start,end);
		System.out.println(sub);
		

	}

}
