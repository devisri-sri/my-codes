package com.cg.demo;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String s= sc.nextLine();
	boolean flag= false;
	int l=s.length();
	for(int i=0;i<l/2;i++) {
		if(s.charAt(i)==s.charAt(l-i-1)) {
			flag= true;
			break;
			
		}
	}
	if(flag) {
		System.out.println("true :palindrome");
		
	}
	else {
		System.out.println("false : Not palindrome");
	}

	}

}
