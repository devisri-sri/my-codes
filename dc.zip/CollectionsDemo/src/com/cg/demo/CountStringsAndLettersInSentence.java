package com.cg.demo;

import java.util.Scanner;

public class CountStringsAndLettersInSentence {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String sen=sc.nextLine();
		sc.close();
		int ii=0, ss=0,dd=0; boolean sflag=true,iflag=true;
		String[] sen2= sen.split(sen);
		 for(int i=0;i<sen2.length;i++) {
			 try {
				 Integer d= Integer.parseInt(sen2[i]);
			 }catch(NumberFormatException Ex){
				 iflag=false;
				 
			 }
			 if(iflag==false) {
				 try {
					 Double g= Double.parseDouble(sen2[i]);
				 }catch(NumberFormatException Ex1) {
					 sflag=false;
				 }
			 }
			 if(iflag) 
				 ii=ii+1;
			
			 if(sflag==true && iflag==false) 
				 dd=dd+1;
			 if(sflag==false)
				 ss=ss+1;
			 iflag=true;
			 sflag=true;
			 
		 }
		 System.out.println("String "+ss);
		 System.out.println("INteger "+ii);
		 System.out.println("double "+dd);

	}

}
