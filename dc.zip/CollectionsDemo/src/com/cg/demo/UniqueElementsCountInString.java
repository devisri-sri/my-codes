package com.cg.demo;

import java.util.Scanner;

public class UniqueElementsCountInString {

	public static void main(String[] args) {
Scanner sc= new Scanner(System.in);
String s= sc.nextLine();
char[] charArray=s.toCharArray();
int count=0;
for(int i=0;i<charArray.length;i++) {
	for(int j=i+1;j<charArray.length;j++) {
	if(charArray[i]==charArray[j]) {
		count++;
	}
	
}
}
System.out.println(count);
	}

}
