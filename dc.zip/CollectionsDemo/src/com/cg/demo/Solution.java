package com.cg.demo;

import java.util.Scanner;

class person{
	protected String firstName;
	protected String lastName;
	protected int id;
	 public person(String firstName,String lastName,int id) {
		 this .firstName=firstName;
		 this.lastName=lastName;
		 this.id=id;	
	}
		public void printPerson(){
			 System.out.println(
					"Name: " + lastName + ", " + firstName 
				+ 	"\nID: " + id); 
		}
		 
}
class Student1 extends person{
	private int [] testScores;

	Student1(String firstName, String lastName, int id, int [] testScores) {
		super(firstName, lastName, id);
		// TODO Auto-generated constructor stub
		this.testScores=testScores;
	}
	public char calculate(){
        int average = 0;
        for(int i = 0; i < testScores.length; i++){
            average += testScores[i];
        }
        average = average / testScores.length;
        
        if(average >= 90){
            return 'O'; // Outstanding
        }
        else if(average >= 80){
            return 'E'; // Exceeds Expectations
        }
        else if(average >= 70){
            return 'A'; // Acceptable
        }
        else if(average >= 55){
            return 'P'; // Dreadful
        }
        else if(average >= 40){
            return 'D'; // Dreadful
        }
        else{
            return 'T'; // Troll
        }
    }
//	public void printPerson(){
//		 System.out.println("name of  "+firstName);
//		 // prints only  firstName;
//	}

    
}
    
  class Solution {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String firstName = scan.next();
		String lastName = scan.next();
		int id = scan.nextInt();
		int numScores = scan.nextInt();
		int[] testScores = new int[numScores];
		for(int i = 0; i < numScores; i++){
			testScores[i] = scan.nextInt();
		}
		scan.close();
		
		Student1 s = new Student1(firstName, lastName, id, testScores);
		s.printPerson();
		System.out.println("Grade: " + s.calculate() );
	}
}
	

