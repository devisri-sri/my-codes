package com.cg.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class StringToInteger {

	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(System.in)); 
 String s= bufferedReader.readLine();
 try {
	
	 int output=Integer.parseInt(s);
	 System.out.println(output);
 }catch(NumberFormatException ex) {
	 System.out.println("Bad String");
 }
	 
 }

}
