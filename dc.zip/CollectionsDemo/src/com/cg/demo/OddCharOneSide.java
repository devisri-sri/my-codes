package com.cg.demo;

import java.util.Scanner;

public class OddCharOneSide {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		sc.nextLine();
		for(int i=0;i<n;i++) {
			String s= sc.nextLine();
			char[] charArray=s.toCharArray();
			for(int j=0;j<charArray.length;j++) {
				if(j%2==0) {
					System.out.print(charArray[j]);
				}
			}
			
			System.out.print(" ");	
			for(int j=0;j<charArray.length;j++) {
				if(j%2!=0) {
					System.out.print(charArray[j]);
				}
			}
			System.out.println(" ");	
		}
		

	}

}
