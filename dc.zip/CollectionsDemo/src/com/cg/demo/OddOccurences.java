package com.cg.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class OddOccurences {
   static int getOddOccurrence(int a[], int n)
   {
	   Map<Integer,Integer> mp = new HashMap<>();
	    for (int i = 0; i <n ; i++)
	        mp.put(a[i],mp.get(a[i])==null?1:mp.get(a[i])+1);
	    int sum = 0;
	   for (Map.Entry<Integer,Integer> entry : mp.entrySet())
	    { 
	        if (entry.getValue() % 2 != 0)
	           sum += (entry.getKey()) * (entry.getValue());
	    }
	    return sum;}
   public static void main(String[] args)
   { Scanner sc = new Scanner(System.in);
	   int n= sc.nextInt();
	   int a[]= new int[n];
       for(int i=0;i<n;i++) {
    	   a[i]=sc.nextInt();   
       }
     
       System.out.println(getOddOccurrence(a, n));
   }
}
