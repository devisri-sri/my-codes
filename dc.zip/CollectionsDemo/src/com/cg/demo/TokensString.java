package com.cg.demo;
import java.util.*;

public class TokensString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String s= sc.nextLine();
//		s.trim();
//		 s = s.trim();
	        if (s.length() == 0) {
	            System.out.println(0);
	        } else {
	            String[] strings = s.split("['!?,._@ ]+");
	            System.out.println(strings.length);
	            for (String str : strings)
	                System.out.println(str);
	        }
		

	}

}
