package com.cg.demo;

import java.util.Scanner;

public class StartingCapital {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		String A= sc.next();
		String B= sc.next();
		System.out.println(A.length()+B.length());
		if(A.compareTo(B)>0) {
			System.out.println("yes");
		}
			else
				System.out.println("no");
		
		//(0,1) means first letter only capital 
		//if we keep(0,4) starting to next 4 letters will be capital
		A=A.substring(0,1).toUpperCase()+A.substring(1);
		B=B.substring(0,1).toUpperCase()+B.substring(1);
		System.out.println(A+ " "+B);
		}
	

}
