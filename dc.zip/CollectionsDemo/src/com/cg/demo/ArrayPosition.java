package com.cg.demo;

import java.util.Scanner;

public class ArrayPosition {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		 int n= sc.nextInt();
		int a[]=new int[n];
		
		for (int i=0;i<a.length;i++) {
			 a[i]=  sc.nextInt();	
		}

			int f= sc.nextInt();
		 int result=position(a,f);
				 System.out.println(result);
	}
	public static int position(int a[],int f) {
		int c=0;
		int l= a.length;
		for(int i=0;i<l;i++) {
			if(a[i]==f) {
c=i+1;
break;// here break is important or els eloop will continues and print -1
				}
			else
				c= -1;

	}
		return c ;

}
}
