package com.cg.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Hacker8DictioneriesMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
int n= sc.nextInt();
Map<String,Integer>myMap= new HashMap<String,Integer>();
for(int i=0;i<n;i++) {
	String name= sc.next();
	int phone= sc.nextInt();
	myMap.put(name, phone);
}
while(sc.hasNext()){
	String name1=sc.next();
	if(myMap.containsKey(name1)){
		int phone=myMap.get(name1);
		System.out.println(name1+" = "+ phone);
		
	}else {
		System.out.println("Not Found");
	}
	
}


	}

}
