package com.cg.demo;

import java.util.Scanner;

public class Fibanoicciseries {
public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	int a= sc.nextInt();
	int b= sc.nextInt();
	int r= sc.nextInt();
	int []values= new int[r];
	values[0]=a;
	values[1]=b;
	for(int i=2;i<r;i++) {
		values[i]=values[i-2]+values[i-1];
		
	}
	
	
	System.out.println(values[r-1]);

}
}

