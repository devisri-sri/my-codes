package com.cg.demo;
import java.util.*;

public class SubstringHighestAndLowestSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String s= sc.nextLine();
		int k= sc.nextInt();
	String	smallest=" ";
	String	largest=" ";
smallest =largest= s.substring(0,k);
//System.out.println(smallest);

for (int i=1; i<s.length()-k+1; i++) {
    String substr = s.substring(i, i+k);
//    System.out.println(substr);
    if (smallest.compareTo(substr) > 0)
        smallest = substr;
    if (largest.compareTo(substr) < 0)
        largest = substr;
}
System.out.println("small "+smallest+"\n"+"large "+ largest);
	}

}
