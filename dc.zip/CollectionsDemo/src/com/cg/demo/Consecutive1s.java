package com.cg.demo;

import java.util.Scanner;

public class Consecutive1s {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		String [] groupings= Integer.toBinaryString(n).split("0");
		int max=0;
		for(String s:groupings) {
			
			if(max<s.length()) {
				max=s.length();
				
			}
		}
		System.out.println(max);
	

	}

}
