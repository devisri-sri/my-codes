package com.cg.demo;

public class StringReverseUsingBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String k= "love u datta in";
//		StringBuilder sb= new StringBuilder(k);
//		sb.reverse();
	/*using stringBuilder can reverse as string is immutable and 
		stringbuilders  & stringbuffer are immutable*/
//		System.out.println(sb);
		
		//using split for reverseing  the each word in string
		String [] sb= k.split("\\s");
		String reverseword="";
	
		for(String word:sb) {
			StringBuilder ss= new StringBuilder(word);
		ss.reverse();
			reverseword+=ss.toString()+" ";
		}
		System.out.print(reverseword);

	}

}
