package com.cg.demo;

import java.util.Scanner;

public class replace{  
		public static void main(String args[]){  
//		String s1="of word my word love word";  
			Scanner sc= new Scanner(System.in);
			 String s1= sc.nextLine();
			
			
		String replaceString=s1.replaceAll("word","work");
		System.out.println(replaceString);  
		}}  
