//package com.cg.demo;
//
//import java.util.Scanner;
//
//public class SumAndlastDigits {
//
//	    public static void main(String [] args){
//	        Scanner sc= new Scanner(System.in);
//	       /* int A[]= {4,5,6,-1,2,3};
//	        int c=A[0];
//	        for(int i=0;i<A.length;i++){
//	            if(A[i]<c){
//	                c=A[i];
//	            }
//	        }
//	        System.out.println(c);*/
//	         String a= sc.next();
//	         String b= sc.next();
//	         int c=0;
//	         if(a.length()==b.length()) {
//	        	 c= -1;
//	         }
//	         else {
//	        	char [] a1=a.toCharArray();
//	        	char [] b1=b.toCharArray();
//	        	
//	        	 for(int i=0;i<a1.length();i++) {
//	        		 if(a1.charAt
//	        			 
//	        			int result = a.charAt(i) | a.charAt(i+1);
//	        			
//	        			a.charAt(i) = result |a.charAt(i);
//	        			a.charAt(i+1) = result | a.charAt(i+1);
//	        			
//	        		 }
//	        		 
//	        	 }
//	         }
//	    }
//	}