package com.cg.dc;

class Parent {
	
	protected int print()
	{
		System.out.println("in parent");
		return 0;
	}
}
class Sub extends Parent
{
	public int print()
	{
		System.out.println("in child");
		return 1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent obj= new Parent();
		Sub sub= new Sub();
		System.out.println(obj.print()+",");

	}

}
