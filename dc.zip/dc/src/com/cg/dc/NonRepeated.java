package com.cg.dc;

public class NonRepeated {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
