package com.cg.dc;

import java.util.Arrays;
import java.util.Scanner;

public class Leftshift {
	
	public static void main(String[] args) {  
        //Initialize array  
		Scanner sc= new Scanner(System.in);
		int k= sc.nextInt();
        int [] arr = new int [k] ;
        int n= sc.nextInt();
         
        for (int i = 0; i < arr.length; i++) {  
           int input= sc.nextInt();
           arr[i]=input;
           
        }  
        System.out.println("Original array: "); 
        for(int i=0;i<arr.length;i++) {
        	System.out.println(arr[i]);
        }
        for(int i = 0; i < n; i++){  
            int j, first;  
            //Stores the first element of the array  
            first = arr[0];  
            for(j = 0; j < arr.length-1; j++){  
                //Shift element of array by one  
                arr[j] = arr[j+1];  
            }  
            //First element of array will be added to the end  
            arr[j] = first;  
        }  
       
        //Displays resulting array after rotation  
        System.out.println("Array after left rotation: ");  
        for(int i = 0; i< arr.length; i++){  
            System.out.print(arr[i] + " ");  
        }  
    }  
}  
