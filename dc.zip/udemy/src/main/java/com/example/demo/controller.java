package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController

public class controller {

	@GetMapping("/hello-world")
	public HelloWorld helloworldbean() {
	return new HelloWorld("hello world");
	}

}
