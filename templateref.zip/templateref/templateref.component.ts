import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templateref',
  templateUrl: './templateref.component.html',
  styleUrls: ['./templateref.component.css']
})
export class TemplaterefComponent implements OnInit {

  public gender:string = "";

  constructor() { }

  ngOnInit() {
  }

  showCity(event):void{
    console.log(event.value);
  }

  check(event){
    this.gender = event.target.value;
  }

  showGender():void{
    console.log("Selected Gender :" + this.gender);
  }
}
