package com.cg.opn.services;

import java.util.List;

import com.cg.opn.pojos.Seed;

public interface ISeedService {
	Seed addSeed(Seed seed);

	Seed updateSeed(Seed seed);

	Seed deleteSeed(Seed seed);

	Seed getSeed(int seedId);

	List<Seed> getSeed(String commonName);

	List<Seed> getAllSeeds();

	List<Seed> getAllSeeds(String typeOfSeeds);



}