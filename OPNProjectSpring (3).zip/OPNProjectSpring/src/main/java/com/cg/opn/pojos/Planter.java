package com.cg.opn.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "planter_master")
public class Planter {

	@Id
	@GeneratedValue
	@Column(name = "planter_id")
	private Integer id;
	private float height;
	private int capacity;
	private int drinageHoles;
	@NotNull
	@Range(min = 1, max = 10, message = "Color should not be 0 and must be between 1 to 10")
	private int color;

	@NotEmpty(message = "shape should not be null")
	private String shape;

	private int stock;

	@NotNull
	@Range(min = 50, max = 1000, message = "Cost should not be 0 and must be between 50 to 1000")
	private int cost;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "order_id")
	@JsonIgnore
	private Order order;
	

	public Planter() {

	}
	public Planter(int id) {
		super();
		this.id=id;

	}
	public Planter(Integer id, float height, int capacity, int drinageHoles, int color, String shape, int stock,
			int cost) {
		super();
		this.id = id;
		this.height = height;
		this.capacity = capacity;
		this.drinageHoles = drinageHoles;
		this.color = color;
		this.shape = shape;
		this.stock = stock;
		this.cost = cost;
		
	}
	public Planter(float height, int capacity, int drinageHoles, int color, String shape, int stock, int cost
		) {
		super();
		this.height = height;
		this.capacity = capacity;
		this.drinageHoles = drinageHoles;
		this.color = color;
		this.shape = shape;
		this.stock = stock;
		this.cost = cost;
		
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getDrinageHoles() {
		return drinageHoles;
	}
	public void setDrinageHoles(int drinageHoles) {
		this.drinageHoles = drinageHoles;
	}
	public int getColor() {
		return color;
	}
	public void setColor(int color) {
		this.color = color;
	}
	public String getShape() {
		return shape;
	}
	public void setShape(String shape) {
		this.shape = shape;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Planter [id=" + id + ", height=" + height + ", capacity=" + capacity + ", drinageHoles=" + drinageHoles
				+ ", color=" + color + ", shape=" + shape + ", stock=" + stock + ", cost=" + cost + 
				"]";
	}
}

	