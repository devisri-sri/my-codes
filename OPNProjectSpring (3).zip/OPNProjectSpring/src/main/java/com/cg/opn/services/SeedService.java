package com.cg.opn.services;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opn.daos.ISeedRepository;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Seed;


@Service
@Transactional
public class SeedService implements ISeedService {

	@Autowired
	ISeedRepository repository;
 
	@Override
	public Seed addSeed(Seed seed) {
		return repository.save(seed);
	}


	@Override
	public Seed updateSeed(Seed seed){
		int id= seed.getId();
		if (!repository.existsById(id)) 
			throw new ResourceNotFoundException("Seed you are trying to update is not present with id:" + id);
			return repository.save(seed);
	}
	
	@Override
	public Seed deleteSeed(Seed seed){
		int id=seed.getId();
		if(!repository.existsById(id))
			throw new ResourceNotFoundException("Seed you are trying to delete is not present with given id:"+ id);
		repository.deleteById(id);
		return seed;
	}
	
	@Override
	public Seed getSeed(int Id)  {

		Optional<Seed> optional=repository.findById(Id); 
		if(!optional.isPresent()) 
			throw new ResourceNotFoundException("Seed Details not found for id "+ Id);	
		return optional.get();
	}

	@Override
	public List<Seed> getSeed(String commonName){
		List <Seed> seed = repository.findAllByCommonName(commonName);
		if (seed.isEmpty()) {
			throw new ResourceNotFoundException("No seeds are there with commonName:" + commonName);
		}
		return seed;
	}

	@Override
	public List<Seed> getAllSeeds() {
		List <Seed> seed1 = repository.findAll();
		if (seed1.isEmpty()) {
			throw new ResourceNotFoundException("No seeds are present in the table");
		}
		return seed1;
	}

	@Override
	public List<Seed> getAllSeeds(String typeOfSeeds) {
		List <Seed> seeds = repository.findAllByTypeOfSeeds(typeOfSeeds);
		if (seeds.isEmpty()) {
			throw new ResourceNotFoundException("No seeds are there with typeofseeds:" + typeOfSeeds);
		}
		return seeds;
	}
	
}