package com.cg.opn.services;

import java.util.List;

import com.cg.opn.pojos.Planter;


public interface IPlanterService {

	Planter addPlanter(Planter planter);

	Planter updatePlanter(Planter planter);

	Planter deletePlanter(Planter planter);

	Planter getPlanter(int planterId);

	List<Planter> getPlanter(String planterShape);

	List<Planter> getAllPlanters();

	List<Planter> getAllPlanters(double minCost, double maxCost);

}
