package com.cg.opn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePlantNurserySpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePlantNurserySpringRestApplication.class, args);
	}

}
