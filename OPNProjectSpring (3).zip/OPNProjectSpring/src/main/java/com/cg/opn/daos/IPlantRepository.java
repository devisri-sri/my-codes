package com.cg.opn.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.opn.pojos.Plant;



@Repository

	public interface IPlantRepository extends JpaRepository<Plant, Integer> {

		public List<Plant> findAllByCommonName(String commonName);
		public List<Plant> findAllByTypeOfPlant(String typeOfPlant);
	}




