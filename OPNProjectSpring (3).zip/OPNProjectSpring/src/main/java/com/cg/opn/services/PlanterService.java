package com.cg.opn.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opn.daos.IPlanterRepository;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Planter;

@Service
@Transactional
public class PlanterService implements IPlanterService {
	@Autowired
	IPlanterRepository repository;

//Adding the planter details
	@Override
	public Planter addPlanter(Planter planter) {
		return repository.save(planter);
	}

//Updating the planter details
	@Override
	public Planter updatePlanter(Planter planter) {
		int id = planter.getId();
		if (!repository.existsById(id))
			throw new ResourceNotFoundException("Planter you are trying to update is not present with the id " + id);
		return repository.save(planter);
	}

//Deleting the planter
	@Override
	public Planter deletePlanter(Planter planter) {
		int id = planter.getId();
		if (!repository.existsById(id))
			throw new ResourceNotFoundException(
					"Planter you are trying to delete is not present with the given id " + id);
		repository.deleteById(planter.getId());
		return planter;
	}

//Getting the planter details based on the planter Id
	@Override
	public Planter getPlanter(int id) {
		Optional<Planter> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new ResourceNotFoundException("Planter Details not found for id " + id);
		return optional.get();
	}

//Getting the planter details based on the planter shape
	@Override
	public List<Planter> getPlanter(String shape) {
		List<Planter> plantersByShape = repository.findAllByShape(shape);
		if (plantersByShape.size() == 0) {
			throw new ResourceNotFoundException("There is no planter with the given shape " + shape);
		}
		return plantersByShape;
	}

//Getting the details of all the planters
	@Override
	public List<Planter> getAllPlanters() {
		List<Planter> planters = repository.findAll();
		if (planters.size() == 0) {
			throw new ResourceNotFoundException("There are no planters in the list");
		}
		return planters;
	}

//Getting all the planter details between minimum and maximum costs
	@Override
	public List<Planter> getAllPlanters(double minCost, double maxCost) {
		int minimumCost = (int) minCost;
		int maximumCost = (int) maxCost;
		List<Planter> planters = repository.findAllByCostBetween(minimumCost, maximumCost);
		if (planters.size() == 0) {
			throw new ResourceNotFoundException("There are no planters in the list between given costs");
		}
		return planters;
	}

}