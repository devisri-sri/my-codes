package com.cg.opn.services;

import java.util.List;

import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;

public interface IOrderService {

	Order addOrder(Order order);

	Order updateOrder(Order order);

	Order deleteOrder(Order order);

	Order getOrder(int id);
	Customer getCustomerBasedOnOrder(int id);

	List<Order> getAllOrders();

	public int plantersOrdered(int id);

	public int plantsOrdered(int id);

	public int seedsOrdered(int id);
	public List<String> AllOrdersPlaced(int id);

}
