package com.cg.opn.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.opn.pojos.Seed;



@Repository
public interface ISeedRepository extends JpaRepository<Seed,Integer>{
	public List<Seed> findAllByCommonName(String commonName);
	public List<Seed> findAllByTypeOfSeeds(String typeOfSeeds);
	
}