package com.cg.opn.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.lang.String;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "address_master")
public class Address {
	@Id
	@GeneratedValue
	@Column(name = "addressid")
	private Integer id;

	
	@Column(name = "house_no")
	private String houseNo;
 
	@NotEmpty(message = "colony should not empty")
	@Size(min = 4, message = "min 4 chars required")
	@Column(name = "colony")
	private String colony;

	@NotEmpty(message = "city should not empty")
	@Size(min = 3, message = "min 3 chars required")
	private String city;

	@NotEmpty(message = "state should not empty")
	@Size(min = 2, message = "min 2 chars required")
	private String state;
	
	@NotNull(message="pincode should not be empty")
	private Integer pincode;

	public Address() {
		
	}

	public Address(Integer id, String houseNo, String colony, String city, String state, Integer  pincode) {
		super();
		this.id = id;
		this.houseNo = houseNo;
		this.colony = colony;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Address(String houseNo, String colony, String city, String state,Integer  pincode) {
		super();
		this.houseNo = houseNo;
		this.colony = colony;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer  getPincode() {
		return pincode;
	}

	public void setPincode(Integer  pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", houseNo=" + houseNo + ", colony=" + colony + ", city=" + city + ", state="
				+ state + ", pincode=" + pincode + "]";
	}


}
