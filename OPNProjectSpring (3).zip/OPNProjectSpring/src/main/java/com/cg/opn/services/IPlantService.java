package com.cg.opn.services;

import java.util.List;

import com.cg.opn.pojos.Order;
import com.cg.opn.pojos.Plant;

public interface IPlantService {

	Plant addPlant(Plant plant);

	Plant updatePlant(Plant plant);

	Plant deletePlant(int id);

	Plant getPlantDetails(int id);

	List<Plant> getAllPlants();

	List<Plant> getPlants(String commonName);

	List<Plant> getAllPlants(String typeOfPlant);

	Order getOrderNoBasedOnPlant(int id);

}
