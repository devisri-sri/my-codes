package com.cg.opn.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "plant_master")
public class Plant {

	@Id
	@GeneratedValue
	@Column(name = "plant_id")
	private Integer id;
	
	@NotNull(message = "Cost should not be null")
	@Digits(integer = 2, fraction = 2, message = " cost shouldn't exceed 100")
	private Double cost;
	
	private String bloomtime;
	
	@NotEmpty(message = "CommonName should not empty")
	@Size(min = 4, message = "min 4 chars required")
	private String commonName;
	
	private String typeOfPlant;
	
	private Integer height;
	
	private String spread;
	
	private String medicinalOrCulinaryUse;
	
	private String difficultyLevel;
	
	private String temparature;
	
	private String description;
	
	private Integer stock;
	 
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "order_id")
	@JsonIgnore
	private Order order;

	public Plant() {
		super();
	}

	public Plant(Integer id, Double cost, Integer height, Integer stock) {
		super();
		this.id = id;
		this.cost = cost;
		this.height = height;
		this.stock = stock;
	}

	public Plant(Integer id, Double cost, String bloomtime, String commonName, String typeOfPlant, Integer height,
			String spread, String medicinalOrCulinaryUse, String difficultyLevel, String temparature,
			String description, Integer stock) {
		super();
		this.id = id;
		this.cost = cost;
		this.bloomtime = bloomtime;
		this.commonName = commonName;
		this.typeOfPlant = typeOfPlant;
		this.height = height;
		this.spread = spread;
		this.medicinalOrCulinaryUse = medicinalOrCulinaryUse;
		this.difficultyLevel = difficultyLevel;
		this.temparature = temparature;
		this.description = description;
		this.stock = stock;

	}

	public Plant(Double cost, String bloomtime, String commonName, String typeOfPlant, Integer height, String spread,
			String medicinalOrCulinaryUse, String difficultyLevel, String temparature, String description,
			Integer stock) {
		super();
		this.cost = cost;
		this.bloomtime = bloomtime;
		this.commonName = commonName;
		this.typeOfPlant = typeOfPlant;
		this.height = height;
		this.spread = spread;
		this.medicinalOrCulinaryUse = medicinalOrCulinaryUse;
		this.difficultyLevel = difficultyLevel;
		this.temparature = temparature;
		this.description = description;
		this.stock = stock;

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public String getBloomtime() {
		return bloomtime;
	}

	public void setBloomtime(String bloomtime) {
		this.bloomtime = bloomtime;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getTypeOfPlant() {
		return typeOfPlant;
	}

	public void setTypeOfPlant(String typeOfPlant) {
		this.typeOfPlant = typeOfPlant;
	}

	public Integer getHeight() {
		return height;
	}

	public void setHeight(Integer height) {
		this.height = height;
	}

	public String getSpread() {
		return spread;
	}

	public void setSpread(String spread) {
		this.spread = spread;
	}

	public String getMedicinalOrCulinaryUse() {
		return medicinalOrCulinaryUse;
	}

	public void setMedicinalOrCulinaryUse(String medicinalOrCulinaryUse) {
		this.medicinalOrCulinaryUse = medicinalOrCulinaryUse;
	}

	public String getDifficultyLevel() {
		return difficultyLevel;
	}

	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}

	public String getTemparature() {
		return temparature;
	}

	public void setTemparature(String temparature) {
		this.temparature = temparature;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStock() {
		
		return stock;
	}

	public Order getOrder() {
		
		return   order;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "Plant [id=" + id + ", cost=" + cost + ", bloomtime=" + bloomtime + ", commonName=" + commonName
				+ ", typeOfPlant=" + typeOfPlant + ", height=" + height + ", spread=" + spread
				+ ", medicinalOrCulinaryUse=" + medicinalOrCulinaryUse + ", difficultyLevel=" + difficultyLevel
				+ ", temparature=" + temparature + ", description=" + description + ", stock=" + stock + "]";
	}

	
}