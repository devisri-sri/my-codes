package com.cg.opn.services;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opn.daos.IAdminRepository;
import com.cg.opn.pojos.Admin;
import com.cg.opn.pojos.Customer;

@Service
@Transactional
public class AdminService implements IAdminService {
   @Autowired
   IAdminRepository repository;
   @Autowired
   CustomerService service;
   @Autowired
   OrderService service1;
   @Autowired
   PlanterService service2;
   @Autowired
   PlantService service3;
   @Autowired
   SeedService service4;
   
 
	@Override
	public String checkadmin(int id,String username, String password) {
		Optional<Admin> optional= repository.findById(id);
			if(optional.isPresent()) {
				String username1 = optional.get().getUsername();
				String password2 = optional.get().getPassword();
				if (username.equals(username1) && password.equals(password2)) {
					return "LOGIN Succes";
				} else
					return "Invalid credentials";
			}
			else
			{
			return "No data present with username";
			}
		}
	@Override
	public String checkcustomer(int id,String username, String password) {
		 Customer customer=service.getCustomer(id);
				String username1 = customer.getUsername();
				String password2 = customer.getPassword();
				if (username.equals(username1) && password.equals(password2)) {
					
					return "Customer logged in successfully with id placed orders are:"+service.ordersplaced(id);
					
				} else
					return "Invalid credentials";
			}
	} 


