package com.cg.opn.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.services.IAdminService;

import io.swagger.annotations.ApiOperation;

@RestController
public class AdminController {
	@Autowired
	IAdminService service;
	@ApiOperation(value="Admin login")
	@PostMapping("/login/{type}/{id}/{username}/{password}")
	public ResponseEntity<String> loginvalid(@PathVariable("type") String type,@PathVariable("id") int id,@PathVariable("username") String username,@PathVariable("password") String password) {
		String result="";
		if(type.equals("admin")) {
			result=service.checkadmin(id,username,password);
		}
		if(type.equals("customer")) {
			result=service.checkcustomer(id,username,password);
		}
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

}
