package com.cg.opn.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.opn.pojos.Planter;
import com.cg.opn.services.IPlanterService;


@RestController
public class PlanterController {

	@Autowired
	IPlanterService service;

	@PostMapping("/addPlanter")
	public ResponseEntity<String> addPlanter(@Valid @RequestBody Planter planter) {
		planter = service.addPlanter(planter);
		return new ResponseEntity<String>("Planter has been added successfully " + planter.getId()+", "+planter, HttpStatus.OK);
	}

	@PutMapping("/updatePlanter")
	public ResponseEntity<String> updatePlanter(@Valid @RequestBody Planter planter) {
		Planter updatedPlanter = service.updatePlanter(planter);
		return new ResponseEntity<String>("Planter has been updated successfully ,"+updatedPlanter, HttpStatus.OK);
	}

	@DeleteMapping("/deletePlanter")
	public ResponseEntity<String> deletePlanter(@RequestBody Planter planter) {
		Planter deletedPlanter = service.deletePlanter(planter);
		return new ResponseEntity<String>("Planter deleted with the id " + deletedPlanter.getId(), HttpStatus.OK);
	}

	@GetMapping("/getPlanter/{id}")
	public ResponseEntity<Planter> getPlanter(@PathVariable int id) {
		Planter planterById = service.getPlanter(id);
		return new ResponseEntity<Planter>(planterById, HttpStatus.OK);
	}

	@GetMapping("/getPlanters/{shape}")
	public ResponseEntity<List<Planter>> getPlanter(@PathVariable String shape) {
		List<Planter> plantersByShape = service.getPlanter(shape);
		return new ResponseEntity<List<Planter>>(plantersByShape, HttpStatus.OK);
	}

	@GetMapping("/getAllPlanters")
	public ResponseEntity<List<Planter>> getAllPlanters() {
		List<Planter> planters = service.getAllPlanters();
		return new ResponseEntity<List<Planter>>(planters, HttpStatus.OK);
	}

	@GetMapping("/getAllPlantersBasedOnMinCostAndMaxCost/{minCost}/{maxCost}")
	public ResponseEntity<List<Planter>> getAllPlanters(@PathVariable double minCost, @PathVariable double maxCost) {
		List<Planter> planters = service.getAllPlanters(minCost, maxCost);
		return new ResponseEntity<List<Planter>>(planters, HttpStatus.OK);
	}
}