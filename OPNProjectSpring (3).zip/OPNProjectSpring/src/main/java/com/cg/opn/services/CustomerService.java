package com.cg.opn.services;

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.opn.daos.ICustomerRepository;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;

@Service
@Transactional
public class CustomerService implements ICustomerService {

	@Autowired
	ICustomerRepository repository;
	@Override
	public Customer getCustomer(int id) {
		Optional<Customer> optional = repository.findById(id);
		if (!optional.isPresent()) {
			throw new ResourceNotFoundException("No Customer found with this id" + id);
		}
		return optional.get();
	}

	@Override
	public Customer addCustomer(Customer customer) {
		if (customer.getAddress() == null) {
			throw new NullPointerException("Null address fields are not allowed");
		}
		return repository.save(customer);
	}


	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> list = repository.findAll();
		if (list.isEmpty()) {
			throw new ResourceNotFoundException("list is empty");
		}

		return list;
	}


	@Override
	public Customer updateCustomer(Customer customer) {
		Optional<Customer> optional = repository.findById(customer.getId());
		if (!optional.isPresent()) {
			throw new ResourceNotFoundException("No customer found with this id to update:" + customer.getId());
		}
		return repository.save(customer);

	}

	@Override
	public int deleteCustomer(int id) {
		Optional<Customer> optional = repository.findById(id);
		if (!optional.isPresent()) {
			throw new ResourceNotFoundException("No customer found with this id to delete:" + id);
		}
		repository.delete(optional.get());
		return id;
	}

	@Override
	public int ordersplaced(int id) {
		Customer customer = repository.findById(id).get();
		List<Order> list = customer.getOrders();
		return list.size();
	}

}