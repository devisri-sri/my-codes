package com.cg.opn.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.opn.daos.IPlantRepository;
import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Order;
import com.cg.opn.pojos.Plant;

@Service
@Transactional
public class PlantService implements IPlantService {

	@Autowired
	IPlantRepository repository;

	// This method will returns added plant details
	@Override
	public Plant addPlant(Plant plant) {
		return repository.save(plant);
	}

	// This method will returns plantDetails based on id or else throws an exception
	@Override
	public Plant getPlantDetails(int id) {
		Optional<Plant> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new ResourceNotFoundException("Plant details are not found for id " + id);
		return optional.get();
	}

	// This method will returns All plantDetails as a list if not empty throws
	// exception

	@Override
	public List<Plant> getAllPlants() {
		List<Plant> plants = repository.findAll();
		if (plants.size() == 0) {
			throw new ResourceNotFoundException("There are no plants in given list ");
		}
		return plants;
	}

	// This method will returns List of plantDetails based on commonName or else
	// throws an exception

	@Override
	public List<Plant> getPlants(String commonName) {
		List<Plant> commonname = repository.findAllByCommonName(commonName);
		if (commonname.size() == 0) {
			throw new ResourceNotFoundException("there is no plant present with given type " + commonName);
		}
		return commonname;
		// This method will returns updated plant details based on id or else throws
		// exception
	}

	@Override
	public Plant updatePlant(Plant plant) {
		Optional<Plant> optional = repository.findById(plant.getId());
		if (!optional.isPresent())
			throw new ResourceNotFoundException("No plant present with given id to update :" + plant.getId());
		return repository.save(plant);
	}

	// This method will returns deleted plant id based on id or else throws an
	// exception
	@Override
	public Plant deletePlant(int id) {
		Optional<Plant> optional = repository.findById(id);
		if (!optional.isPresent())
			throw new ResourceNotFoundException("plant not present with given id to delete " + id);
		repository.deleteById(id);
		return optional.get();
	}
	// This method will returns List of plantDetails based on typeofPlant or else
	// throws an exception

	@Override
	public List<Plant> getAllPlants(String typeOfPlant) {
		List<Plant> typeofplant = repository.findAllByTypeOfPlant(typeOfPlant);
		if (typeofplant.size() == 0) {
			throw new ResourceNotFoundException("there is no plant present with given type " + typeOfPlant);
		}
		return typeofplant;
	}

	@Override
	public Order getOrderNoBasedOnPlant(int id) {
		Plant plant = repository.findById(id).get();
		return plant.getOrder();

	}
}
