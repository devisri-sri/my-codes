package com.cg.opn.services;
import java.util.List;


import com.cg.opn.pojos.Customer;


public interface ICustomerService {
	Customer getCustomer(int id);

	Customer addCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer updateCustomer(Customer customer);

     int deleteCustomer(int id);
     public  int ordersplaced(int id);

}