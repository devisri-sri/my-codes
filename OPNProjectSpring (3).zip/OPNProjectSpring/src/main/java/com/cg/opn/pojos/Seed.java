package com.cg.opn.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "seed_master")
public class Seed {
	
	@Id
	@GeneratedValue
	@Column(name = "seed_Id")
	private Integer id;
	@NotEmpty(message = "Common name should not empty")
	@Size(min = 4, message = "min 4 chars required")
	private String commonName;

	private String bloomTime;

	private String watering;

	private String difficultyLevel;

	private String temparature;

	private String typeOfSeeds;

	private String description;

	private Integer stock;
	@NotNull(message = "Cost should not empty ")
	@Digits(integer = 2, fraction = 2, message = " cost should not exceed 100")
	private double cost;
	private Integer seedsPerPacket;
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "order_id")
	@JsonIgnore
	private Order order;

	public Seed() {
		super();
	}

	public Seed(Integer id,String commonName,String bloomTime, String watering, String difficultyLevel, String temparature, String typeOfSeeds,
			String description, Integer stock, double cost, Integer seedsPerPacket) {
		super();
		this.id = id;
		this.commonName = commonName;
		this.bloomTime = bloomTime;
		this.watering = watering;
		this.difficultyLevel = difficultyLevel;
		this.temparature = temparature;
		this.typeOfSeeds = typeOfSeeds;
		this.description = description;
		this.stock = stock;
		this.cost = cost;
		this.seedsPerPacket = seedsPerPacket;
		
	}

	public Seed(
		 String commonName,String bloomTime, String watering, String difficultyLevel, String temparature, String typeOfSeeds,
			String description, Integer stock, double cost, Integer seedsPerPacket) {
		super();
		this.commonName = commonName;
		this.bloomTime = bloomTime;
		this.watering = watering;
		this.difficultyLevel = difficultyLevel;
		this.temparature = temparature;
		this.typeOfSeeds = typeOfSeeds;
		this.description = description;
		this.stock = stock;
		this.cost = cost;
		this.seedsPerPacket = seedsPerPacket;
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getBloomTime() {
		return bloomTime;
	}

	public void setBloomTime(String bloomTime) {
		this.bloomTime = bloomTime;
	}

	public String getWatering() {
		return watering;
	}

	public void setWatering(String watering) {
		this.watering = watering;
	}

	public String getDifficultyLevel() {
		return difficultyLevel;
	}

	public void setDifficultyLevel(String difficultyLevel) {
		this.difficultyLevel = difficultyLevel;
	}

	public String getTemparature() {
		return temparature;
	}

	public void setTemparature(String temparature) {
		this.temparature = temparature;
	}

	public String getTypeOfSeeds() {
		return typeOfSeeds;
	}

	public void setTypeOfSeeds(String typeOfSeeds) {
		this.typeOfSeeds = typeOfSeeds;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public Integer getSeedsPerPacket() {
		return seedsPerPacket;
	}

	public void setSeedsPerPacket(Integer seedsPerPacket) {
		this.seedsPerPacket = seedsPerPacket;
	}



	@Override
	public String toString() {
		return "Seed [id=" + id + ", commonName=" + commonName + ", bloomTime=" + bloomTime + ", watering=" + watering
				+ ", difficultyLevel=" + difficultyLevel + ", temparature=" + temparature + ", typeOfSeeds="
				+ typeOfSeeds + ", description=" + description + ", stock=" + stock + ", cost=" + cost
				+ ", seedsPerPacket=" + seedsPerPacket + "]";
	}
}

	