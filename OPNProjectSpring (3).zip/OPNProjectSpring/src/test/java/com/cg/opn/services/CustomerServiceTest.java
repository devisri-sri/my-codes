package com.cg.opn.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Address;
import com.cg.opn.pojos.Customer;
import com.cg.opn.pojos.Order;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
class CustomerServiceTest {
	@Autowired
	ICustomerService service;

	@Test
	public void testgetIdExists() {
		int id = 249;
		Customer customer = service.getCustomer(id);
		assertEquals(id, customer.getId());
	}

	@Test
	public void testGetIdNotExists() {
		int id = 101;
		Exception exp = assertThrows(ResourceNotFoundException.class, () -> service.getCustomer(id));
		String message = "No Customer found with this id" + id;
		assertEquals(message, exp.getMessage());

	}

	@Test
	public void testGetAllCustomers() {
		List<Customer> list = service.getAllCustomers();
		assertNotNull(list, "List is not empty");
	}

	@Test
	public void testDeleteByIdNotExists() {
		int result = 101;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.deleteCustomer(result));
		String message = "No customer found with this id to delete:" + result;
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testUpdateCustomerByIdExists() {
		List<Order> list = new ArrayList<>();
		Order order = new Order("5/2/2020", "offline", 67, 90.0);
		list.add(order);
		Address address = new Address("srinagaram", "rajamundry", "andhra", "nagaram", 4557);
		Customer customer = new Customer(255, "bhavani", "bhava@gmail.com", "bhavani", "Bhavani@1611", address, list);
		Customer resultant = service.updateCustomer(customer);
		assertEquals(customer.getId(), resultant.getId());
		assertEquals(customer.getEmail(), resultant.getEmail());
		assertEquals(customer.getName(), resultant.getName());
		assertEquals(customer.getUsername(), resultant.getUsername());
		assertEquals(customer.getPassword(), resultant.getPassword());
	}

	@Test
	public void testUpdateCustomerByIdNotExists() {
		Address address = new Address("srinagaram", "rjy", "ap", "nagaram", 4557);
		Customer customer = new Customer(101, "bhavani", "bhava@gmail.com", "bhavani", "Bhavani@1611", address);
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.updateCustomer(customer));
		String message = "No customer found with this id to update:" + customer.getId();
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testAddCustomer() {
		List<Order> list = new ArrayList<>();
		Order order = new Order("5/2/2020", "online", 67, 90.0);
		list.add(order);
		Address address = new Address("srinagaram", "bhimavaram", "andhra", "seethampet", 533101);
		Customer customer = new Customer("sushma", "sush@gmail.com", "sushma", "Sushma@1611", address, list);
		Customer resultant = service.addCustomer(customer);
		assertEquals(customer.getId(), resultant.getId());
		assertEquals(customer.getEmail(), resultant.getEmail());
		assertEquals(customer.getName(), resultant.getName());
		assertEquals(customer.getUsername(), resultant.getUsername());
		assertEquals(customer.getPassword(), resultant.getPassword());
	}

	@Test
	public void testAddressNull() {
		Address address = null;
		Customer customer = new Customer("devisri", "devi@gmail.com", "devisri", "devisrI@12", address);
		Exception exception = assertThrows(NullPointerException.class, () -> service.addCustomer(customer));
		String message = "Null address fields are not allowed";
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void checkValidation() {
		String username = "Bhavani";
		String password = "Bhavani@1611";
		assertTrue(username.matches("^[A-Za-z]{1}\\w{4,9}"));
		assertTrue(
				password.matches("^(?=.*[0-9])" + "(?=.*[a-z])(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$).{8,20}$"));
	}

	// Failing test case for customer id exists.
	@Test
	public void testGetCustomerByIdFailingCase() {
		int id = 249;
		Customer customer = service.getCustomer(id);
		assertNotEquals("sushma", customer.getName());
	}

	// Failing test case for validation of userName and password.
	@Test
	public void checkValidationByFailingCase() {
		String username = "rama";
		String password = "Bhavani1611";
		assertFalse(username.matches("^[A-Za-z]{1}\\w{4,9}"));
		assertFalse(password.matches("^(?=.[0-9])" + "(?=.[a-z])(?=.[A-Z])" + "(?=.[@#$%^&+=])" + "(?=\\S+$).{8,20}$"));
	}

}
