package com.cg.opn.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Plant;

@SpringBootTest
class PlantServiceTest {
	@Autowired
	IPlantService service;

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@AfterEach
	void tearDown() throws ResourceNotFoundException {
		System.out.println("Clean up complete");
	}

//Test Case for Adding plantDetails
	@Test
	public void testAddPlant() {
		Plant plant = new Plant(78.0, "winter", "ghup", "herbs", 9, "river", "medi", "high", "34c", "healthy", 89);
		Plant savedPlant = service.addPlant(plant);
		System.out.println(savedPlant + "added sucessfully");
		assertEquals(savedPlant, plant);
	}

//Test Case for getting plantDetails IfNotEmpty
	@Test
	public void getAllPlantListIfExist() {
		List<Plant> plantList = service.getAllPlants();
		assertTrue(!plantList.isEmpty());
		System.out.println("Plant Item Present Can Print Details");
	}

	// Test Case for Getting plantDetails based on Id
	@Test
	public void testgetIdValid() {
		int id = 252;
		Plant plant = service.getPlantDetails(id);
		assertEquals(id, plant.getId());
	}

	// Test Case for Throwing exception if id not Present
	@Test
	public void testgetIdNotFound() {
		int id = 800;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getPlantDetails(id));
		String message = "Plant details are not found for id 800";
		assertEquals(exception.getMessage(), message);
	}

	// Test Case for Deleted case throws Exception if Id not present
	@Test
	public void deletePlantNotPresent() throws ResourceNotFoundException {
		int id = 80;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.deletePlant(id));
		String message = "plant not present with given id to delete " + id;
		assertEquals(exception.getMessage(), message);
		System.out.println("Plant details are successfully deleted");
	}

//Test case for update plantDetails If Id Exists
	@Test
	public void testupdatePlantIdExists() {
		Plant plant = new Plant(252, 56.0, "summer", "erca", "bud", 7, "river", "medi", "high", "34c", "healthy", 89);
		Plant updatedPlant = service.updatePlant(plant);
		assertEquals(updatedPlant.getHeight(), plant.getHeight());
		System.out.println(" plant item is updated");
	}

	// Test case for update plantDetails throws Exception if Id Not Present
	@Test
	public void testupdatePlantIdNotFound() {
		Plant plant = new Plant(96, 12.0, 67, 89);
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.updatePlant(plant));
		String message = "No plant present with given id to update :" + 96;
		assertEquals(exception.getMessage(), message);
		System.out.println(" plant item is notpresentent");
	}

//Test case for getting plantDetails if commonName Exists
	@Test
	public void testgetPlantsCommonNameExists() {
		String commonName = "helip";
		List<Plant> plant = service.getPlants(commonName);
		assertTrue(!plant.isEmpty());
	}

	// Test case for throwing Exception if commonName Not Exists
	@Test
	public void testGetPlantCommonNameNotExists() {
		String commonName = "ercay";
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getPlants(commonName));
		String message = "there is no plant present with given type " + commonName;
		assertEquals(exception.getMessage(), message);
	}

	// Test case for getting plantDetails if typeOfPlant Exists
	@Test
	public void testGetPlantsIfTypeOfPlantExist() {
		String typeOfPlant = "bud";
		List<Plant> plant = service.getAllPlants(typeOfPlant);
		assertTrue(!plant.isEmpty());
	}

	// Test case for throwing Exception if typeOfPlant Not Exists
	@Test
	public void testGetPlantsIfTypeOfPlantNotExists() {
		String typeOfPlant = "mushroom";
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getAllPlants(typeOfPlant));
		String message = "there is no plant present with given type " + typeOfPlant;
		assertEquals(exception.getMessage(), message);
	}
}
