package com.cg.opn.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.opn.pojos.Admin;
@SpringBootTest
class AdminServiceTest {
@Autowired	
IAdminService service;
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void checkAdminIfExists() {
		String login1=service.checkadmin(3,"saisri","Desp345@");
		assertEquals("LOGIN Succes",login1);
	}

	@Test
	public void checkAdminIfNotExists() {
		String login1=service.checkadmin(30000,"saisri","Desp345@");
		assertEquals("No data present with username",login1);
	}


}
