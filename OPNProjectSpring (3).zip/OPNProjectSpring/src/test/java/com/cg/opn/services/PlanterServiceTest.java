package com.cg.opn.services;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.opn.exceptions.ResourceNotFoundException;
import com.cg.opn.pojos.Planter;

@SpringBootTest
class PlanterServiceTest {

	@Autowired
	IPlanterService service;

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@AfterEach
	void tearDown() throws ResourceNotFoundException {
	}

	@Test
	public void testAddPlanterIfValiationFails() {
		Planter planter = new Planter(15, 29, 27, 8, "square", 4, 0);
		assertThrows(Exception.class, () -> service.addPlanter(planter));
	}

	@Test
	public void testUpdatePlanterIfNotExists() {
		Planter planter = new Planter(100);
		int id=planter.getId();
		String message = "Planter you are trying to update is not present with the id " + id;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.updatePlanter(planter));
		assertEquals(message, exception.getMessage());
	}
	@Test
	public void testUpdatePlanterIfValiationFails() {
		Planter planter = new Planter(1, 150, 29, 27, 8, "hallow", 43, 0);
		assertThrows(Exception.class, () -> service.updatePlanter(planter));
	}

	@Test
	public void testDeletePlanterIfNotExists() {
		Planter planter = new Planter(100);
		int id=planter.getId();
		String message = "Planter you are trying to delete is not present with the given id " + id;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.deletePlanter(planter));
		assertEquals(message, exception.getMessage());
	}
	
	@Test
	public void testGetPlanterByIdExists() {
		int id = 251;
		Planter planter = service.getPlanter(id);
		assertNotNull(planter);
	}

	@Test
	public void testGetPlanterByIdNotExists() {
		int id = 14;
		String message = "Planter Details not found for id " + id;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getPlanter(id));
		assertEquals(message, exception.getMessage());
	}

	@Test
	public void testGetPlanterShapeExists() {
		String shape = "round";
		List<Planter> planter = service.getPlanter(shape);
		assertTrue(!planter.isEmpty());
	}

	@Test
	public void testGetPlanterShapeNotExists() {
		String shape = "circl";
		String message = "There is no planter with the given shape " + shape;
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getPlanter(shape));
		assertEquals(message, exception.getMessage());
	}

	@Test
	void testGetAllPlantersMinMaxCostNotExist() {
		double min = 1000;
		double max = 2000;
		String message = "There are no planters in the list between given costs";
		Exception exception = assertThrows(ResourceNotFoundException.class, () -> service.getAllPlanters(min, max));
	assertEquals(message, exception.getMessage());
	}

	@Test
	public void testIfPlantersEmptyOrNot() {
		List<Planter> planter = service.getAllPlanters();
		assertTrue(!planter.isEmpty());
	}

}