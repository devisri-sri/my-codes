import React from 'react'

function Hello() {
    return (
        <div>
            <h3>My Hello Component</h3>
        </div>
    )
}

export default Hello