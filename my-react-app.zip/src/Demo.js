import React, { Component } from 'react'

class Demo extends Component {
    render() {
        return (
            <div>
                <h3>My Demo Component</h3>
            </div>
        )
    }
}

export default Demo;