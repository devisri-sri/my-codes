import logo from './logo.svg';
import './App.css';
import Demo from './Demo';
import Hello from './Hello';
import Home from './Home';
import HelloWorld from './HelloWorld';

function App() {
  let fullname = "nagaraju setti"
  let s1 = { color: 'red', backgroundColor: 'silver' }
  return (
    <div >
      <HelloWorld />
      {/* <Home /> */}
      {/* <Demo />
      <Hello /> */}
    </div>
  );
}

export default App;
