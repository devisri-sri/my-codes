import React, { Component } from 'react'

class HelloWorld extends Component {
    constructor() {
        super();
        this.state = {
            fullname: 'nagaraju',
            skills: ['java', 'angular', 'react', 'vue'],
            products: [
                { id: 1, name: 'television', price: 20000 },
                { id: 2, name: 'laptop', price: 30000 },
                { id: 3, name: 'phone', price: 10000 }
            ]
        }
        this.updateFullname = this.updateFullname.bind(this)
        this.ascending = this.ascending.bind(this)
        this.descending = this.descending.bind(this)
        this.sortTableInAscending = this.sortTableInAscending.bind(this)
        this.sortTableInDescending = this.sortTableInDescending.bind(this)
    }
    updateFullname() {
        //this.state.fullname = "nagaraju setti"
        this.setState({ fullname: 'nagaraju setti' })
    }
    ascending() {
        this.setState({ skills: this.state.skills.sort() });
    }
    descending() {
        this.setState({ skills: this.state.skills.sort().reverse() })
    }
    sortTableInAscending() {
        let p = this.state.products;
        p.sort((a, b) => {
            if (a.price > b.price) return 1;
            else if (a.price < b.price) return -1;
            else return 0;
        })
        this.setState({ products: p })
    }
    sortTableInDescending() {
        let p = this.state.products;
        p.sort((a, b) => {
            if (a.price > b.price) return 1;
            else if (a.price < b.price) return -1;
            else return 0;
        }).reverse()
        this.setState({ products: p })
    }

    render() {
        return (
            <div>
                {/* <h3>Fullname: {this.state.fullname}</h3>
                <button onClick={this.updateFullname}>Update</button> */}
                Sort By: <a href="#" onClick={this.ascending}>Low to High</a> | <a href="#" onClick={this.descending}>High to Low</a>
                <ul>
                    {
                        this.state.skills.map((s, i) =>
                            <li key={i}>{s}</li>
                        )
                    }
                </ul>
                <select>
                    {
                        this.state.skills.map((s, i) =>
                            <option key={i}>{s}</option>
                        )
                    }
                </select>
                <hr />
                Sort By: <a href="#" onClick={this.sortTableInAscending}>Low to High</a> | <a href="#" onClick={this.sortTableInDescending}>High to Low</a>
                <table border="1">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.products.map((p) =>
                                <tr key={p.id}>
                                    <td>{p.id}</td>
                                    <td>{p.name}</td>
                                    <td>{p.price}</td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        )
    }
}

export default HelloWorld