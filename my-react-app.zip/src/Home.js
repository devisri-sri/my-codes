import React, { Component } from 'react'

class Home extends Component {

    fullname = "nagaraju"
    city = "hyderabad"

    constructor() {
        super();
        this.sayHello = this.sayHello.bind(this)
        this.sayHai = this.sayHai.bind(this)
    }

    sayHello() {
        this.fullname = "nagaraju setti"
        console.log(this.fullname)
    }

    sayHai(msg) {
        console.log(this.city)
    }

    render() {
        return (
            <div>
                <h3>Fullname: {this.fullname}</h3>
                <button onClick={this.sayHello}>Hello</button>
                <button onClick={() => this.sayHai("Hai, very good afternoon")}>Hai</button>
            </div>
        )
    }
}

export default Home