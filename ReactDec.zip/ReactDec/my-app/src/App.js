import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
   <h2>miss</h2>
      <h1> hello</h1>
</div>
  );
}

export default App;
