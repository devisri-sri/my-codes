import React, { useEffect, useState } from 'react'

function Greeting() {
    let [firstname, setFirstname] = useState('naga')
    let [lastname, setLastname] = useState('s')
    let [width, setWidth] = useState(window.innerWidth)
    function handleFirstname(event) {
        setFirstname(event.target.value)
    }
    function handleLastname(event) {
        setLastname(event.target.value)
    }
    function handleWindowWidth() {
        setWidth(window.innerWidth)
    }
    useEffect(() => {
        document.title = firstname + " " + lastname
        window.addEventListener('resize', handleWindowWidth)
        return () => {
            window.removeEventListener('resize', handleWindowWidth)
        }

    })
    return (
        <>
            <div>Firstname: {firstname}</div>
            <input type="text" onChange={handleFirstname} />
            <div>Lastname: {lastname}</div>
            <input type="text" onChange={handleLastname} />
            <div>Width: {width}</div>
        </>
    )
}

export default Greeting