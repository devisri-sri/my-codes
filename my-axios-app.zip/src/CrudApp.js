import React, { Component } from 'react'
import { addProduct, deleteProduct, getAll, updateProduct } from './product.service';

class CrudApp extends Component {
    constructor() {
        super();
        this.state = {
            products: []
        }
        this.add = this.add.bind(this)
        this.update = this.update.bind(this)
        this.remove = this.remove.bind(this)
    }
    componentDidMount() {
        getAll().then((res) => this.setState({ products: res.data }))
    }
    add() {
        let p = { name: 'Laptop', price: 30000 }
        addProduct(p).then(() => {
            alert('added...')
            window.location.reload()
        })
    }
    update() {
        let p = { id: 4, name: 'Soap', price: 45 }
        updateProduct(p).then(() => {
            alert('updated...')
            window.location.reload()
        })
    }
    remove() {
        deleteProduct(5).then(() => {
            alert('deleted...')
            window.location.reload()
        })
    }
    render() {
        return (
            <>
                <table className="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.products.map((p) =>
                                <tr key={p.id}>
                                    <td>{p.id}</td>
                                    <td>{p.name}</td>
                                    <td>{p.price}</td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
                <button onClick={this.add} className="btn btn-primary">Add</button>
                <button onClick={this.update} className="btn btn-warning">Update</button>
                <button onClick={this.remove} className="btn btn-danger">Delete</button>
            </>
        )
    }
}

export default CrudApp