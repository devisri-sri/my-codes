import React from 'react'

function MyButton() {
    return (
        <div>
            <button style={{ color: 'red', backgroundColor: 'yellow' }}>My Button</button>
        </div>
    )
}

export default MyButton