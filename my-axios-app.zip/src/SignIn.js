import React, { useState } from 'react'

function SignIn() {
    let [uname, setUser] = useState('')
    let [pwd, setPwd] = useState('')
    function handleUser(event) {
        setUser(event.target.value)
    }
    function handlePass(event) {
        setPwd(event.target.value)
    }
    function onFormSubmit() {
        alert(uname + " " + pwd)
    }
    return (
        <>
            <div>Username:</div>
            <input type="text" onChange={handleUser} />
            <div>Password:</div>
            <input type="password" onChange={handlePass} />
            <div>
                <button onClick={onFormSubmit}>SignIn</button>
            </div>
        </>
    )
}

export default SignIn