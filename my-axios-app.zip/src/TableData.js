import React from 'react'
import RowData from './RowData'

function TableData() {
    return (
        <table>
            <tr>
                <RowData />
            </tr>
        </table>
    )
}

export default TableData