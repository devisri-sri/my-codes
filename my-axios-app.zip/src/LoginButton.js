import React from 'react'
import styled from 'styled-components'

// export const Login = styled.button`
// color:red;
// background-color:yellow
// `

// export const Logout = styled(Login)`
// background-color: blue
// `