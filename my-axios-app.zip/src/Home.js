import React, { useState } from 'react'

function Home() {
    let [name, setName] = useState('naga')
    function updateName() {
        setName('nagaraju setti')
    }
    return (
        <>
            <h3>Name: {name}</h3>
            <button onClick={updateName}>Update</button>
        </>
    )
}

export default Home;