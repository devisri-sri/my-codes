import React from 'react'

function RowData() {
    return (
        <>
            <td>Nagaraju</td>
            <td>Setti</td>
        </>
    )
}

export default RowData