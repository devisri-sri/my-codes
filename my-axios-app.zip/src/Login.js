import React, { useState } from 'react'
import { Form, Input, Label } from 'reactstrap'

function Login() {
    let [uname, setUser] = useState('')
    let [pwd, setPwd] = useState('')
    function handleUser(event) {
        setUser(event.target.value)
    }
    function handlePwd(event) {
        setPwd(event.target.value)
    }
    function onFormSubmit() {
        alert(uname + " " + pwd)
    }
    return (
        <>
            <Form>
                <Label>Username:</Label>
                <Input type="text" onChange={handleUser} valid={uname.length >= 4} invalid={uname.length < 4} />
                <label>Password:</label>
                <Input type="password" onChange={handlePwd} valid={pwd.length >= 6} invalid={pwd.length < 6} />
                <button onClick={onFormSubmit} disabled={!(uname.length >= 4 && pwd.length >= 6)}>Login</button>
            </Form>
        </>
    )
}

export default Login