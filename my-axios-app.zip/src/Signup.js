import React from 'react'

function Signup() {
    let mail = React.createRef()
    let uname, pwd;
    function onFormSubmit() {
        let u = uname.value;
        let p = pwd.value;
        let em = mail.current.value
        alert(u + " " + p + " " + em)
    }
    return (
        <>
            <div>Username:</div>
            <input type="text" ref={(e) => uname = e} />
            <div>Password:</div>
            <input type="password" ref={(e) => pwd = e} />
            <div>Email:</div>
            <input type="email" ref={mail} />
            <div>
                <button onClick={onFormSubmit}>Signup</button>
            </div>
        </>
    )
}

export default Signup