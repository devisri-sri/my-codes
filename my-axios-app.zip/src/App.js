import logo from './logo.svg';
import './App.css';
import CrudApp from './CrudApp';
import MyButton from './MyButton';
// import { Login, Logout } from './LoginButton';
import TableData from './TableData';
import Home from './Home';
import Greeting from './Greeting';
import SignIn from './SignIn';
import Signup from './Signup';
import Login from './Login';

function App() {
  return (
    <>
      <Login />
      {/* <Signup /> */}
      {/* <SignIn /> */}
      {/* <Greeting /> */}
      {/* <Home /> */}
      {/* <MyButton />
      <Login>Login</Login>
      <Logout>Logout</Logout> */}
      {/* <CrudApp /> */}
      {/* <TableData /> */}
    </>
  );
}

export default App;
