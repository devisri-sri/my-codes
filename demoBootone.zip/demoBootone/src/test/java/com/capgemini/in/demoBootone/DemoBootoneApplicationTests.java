package com.capgemini.in.demoBootone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBootoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
