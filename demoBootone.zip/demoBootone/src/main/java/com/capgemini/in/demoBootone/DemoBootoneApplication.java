package com.capgemini.in.demoBootone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;

import com.capgemini.in.demoBootone.bean.Mayatutorials;

@SpringBootApplication
@PropertySource(value = {"classpath:new.properties"})
public class DemoBootoneApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =SpringApplication.run(DemoBootoneApplication.class, args);
		Mayatutorials mybean = context.getBean(Mayatutorials.class);
		System.out.println(mybean);
		
	}
	
	@Bean
	@ConfigurationProperties
	public Mayatutorials getTutorials()
	{
		return new Mayatutorials();
	}

}
