package com.capgemini.in.demoBootone.bean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

//@Component
@ConfigurationProperties
public class Mayatutorials {
	private int channelId;
	private String channelName;
	private String url;
	
	public Mayatutorials() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Mayatutorials [channelId=" + channelId + ", channelName=" + channelName + ", url=" + url + "]";
	}
	public int getChannelId() {
		return channelId;
	}
	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Mayatutorials(int channelId, String channelName, String url) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.url = url;
	}

}
