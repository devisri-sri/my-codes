package com.capgemini.in.demotuesdayboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotuesdaybootApplicationTests {

	@Test
	void contextLoads() {
	}

}
