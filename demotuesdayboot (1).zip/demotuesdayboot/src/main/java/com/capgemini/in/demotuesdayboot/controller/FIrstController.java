package com.capgemini.in.demotuesdayboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FIrstController {
	@RequestMapping("/")
	public String getView()
	{
		return "Hello";
	}

}
