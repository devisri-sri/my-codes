function calcAreaC(rad) {
    return 3.14 * rad * rad;
}
var areac = calcAreaC("Smith");
console.log("Area of circle = " + areac);
