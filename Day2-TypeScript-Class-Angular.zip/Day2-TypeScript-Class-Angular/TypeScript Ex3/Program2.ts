function calcAreaC(r:number)
{
    let ans:number = 3.14*r*r;
    return ans;
}

function calcAreaT(base:number, height:number):number{
    return 0.5*base*height;
}

let areac:number = calcAreaC(3);
console.log("Area of circle = " + areac);

let areat:number = calcAreaT(8.4, 3.4);
console.log("Area of Triangle = " + areat);