function calcAreaC(r) {
    var ans = 3.14 * r * r;
    return ans;
}
function calcAreaT(base, height) {
    return 0.5 * base * height;
}
var areac = calcAreaC(3);
console.log("Area of circle = " + areac);
var areat = calcAreaT(8.4, 3.4);
console.log("Area of Triangle = " + areat);
