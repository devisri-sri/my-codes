

let showStudent = function(rollno:number, fname:string, lname:string, age:number, percentage:number)
{
    console.log("Roll Number = " + rollno);
    console.log("First Name = " + fname);
    console.log("Last Name = " + lname);
    console.log("Age = " + age);
    console.log("Percentage = " + percentage);
}

// showStudent(101, "Smith", "John", 28, "India");    -> Wrong types of function-parameters
// showStudent(10,20,30,40,50);

showStudent(120, "Smith", "Mathew", 29, 89.33);

