
interface Student{
    rollno:number,
    fname:string,
    lname:string,
    age:number,
    percentage:number
}


let showStudent = function(stud:Student)
{
    console.log("Roll Number = " + stud.rollno);
    console.log("First Name = " + stud.fname);
    console.log("Last Name = " + stud.lname);
    console.log("Age = " + stud.age);
    console.log("Percentage = " + stud.percentage);
}

// showStudent(101, "Smith", "John", 28, "India");    -> Wrong types of function-parameters
// showStudent(10,20,30,40,50);

showStudent({
    "rollno":101,
    "fname":"Smith",
    "lname":"Mathew",
    "age":29,
    "percentage":99.23    
});

