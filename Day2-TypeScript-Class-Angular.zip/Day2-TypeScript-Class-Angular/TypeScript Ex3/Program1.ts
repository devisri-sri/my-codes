function calcAreaC(rad)
{
    return 3.14*rad*rad;
}

let areac = calcAreaC("Smith");
console.log("Area of circle = " + areac);

/*
Comments: This Program allow any function-parameter. Function-Arguments are not
Strict to there datatypes 
*/