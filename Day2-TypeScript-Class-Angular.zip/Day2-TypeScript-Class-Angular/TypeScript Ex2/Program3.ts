let addition = (a, b) =>
{
    return a+b;
}

let subtraction = (a, b) =>
{
    return a-b;
}

let multiplication = (a, b) =>
{
    return a*b;
}

let division = (a, b) =>
{
    return a/b;
}

var addn = addition(18,4);
var subt = subtraction(18, 4);
var mult = multiplication(18, 4);
var div = division(18, 4);

console.log("Addition = " + addn);
console.log("Subtraction = " + subt);
console.log("Multiplication = " + mult);
console.log("Division = " + div);

