var addition = function (a, b) {
    return a + b;
};
var subtraction = function (a, b) {
    return a - b;
};
var multiplication = function (a, b) {
    return a * b;
};
var division = function (a, b) {
    return a / b;
};
var addn = addition(18, 4);
var subt = subtraction(18, 4);
var mult = multiplication(18, 4);
var div = division(18, 4);
console.log("Addition = " + addn);
console.log("Subtraction = " + subt);
console.log("Multiplication = " + mult);
console.log("Division = " + div);
