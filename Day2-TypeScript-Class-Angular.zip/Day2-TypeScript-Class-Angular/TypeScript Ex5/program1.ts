class Person{
    public fname:string;
    private lname:string;
    private gender:string;
    public age:number;

    constructor(fname:string, lname:string, gender:string, age:number){
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.age = age;
    }

    addPerson(fname:string, lname:string, gender:string, age:number):any
    {
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.age = age;
    }
}

// let p1 = new Person();
// p1.addPerson("Smith", "Mathew", "Male", 37);
// console.log(p1);

let records = [
    new Person("Aditya", "Sinha", "Male", 28),
    new Person("Nikhil", "Tripathi", "Male", 22),
    new Person("Vishal", "Shah", "Male", 20)
]

let sorted = records.sort((f,s)=>{
    return f.age-s.age;
});

console.log(sorted);