var Employee = /** @class */ (function () {
    function Employee(empCode, empName, salary, deptName) {
        if (empCode === void 0) { empCode = 101; }
        if (empName === void 0) { empName = "Smith"; }
        if (salary === void 0) { salary = 10000.00; }
        if (deptName === void 0) { deptName = "CompDept"; }
        this.empCode = empCode;
        this.empName = empName;
        this.salary = salary;
        this.deptName = deptName;
    }
    return Employee;
}());
var e1 = new Employee();
var e2 = new Employee(9332, "Peter", 19000.00, "AccDept");
console.log(e1);
console.log(e2);
