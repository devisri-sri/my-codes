class Employee{
    public empCode:number;
    public empName:string;
    public salary:number;
    public deptName:string;

    constructor(empCode:number=101, empName:string="Smith", salary:number=10000.00, deptName:string="CompDept"){
        this.empCode = empCode;
        this.empName = empName;
        this.salary = salary;
        this.deptName = deptName;        
    }
}

let e1 = new Employee();
let e2 = new Employee(9332, "Peter", 19000.00, "AccDept");

console.log(e1);
console.log(e2);