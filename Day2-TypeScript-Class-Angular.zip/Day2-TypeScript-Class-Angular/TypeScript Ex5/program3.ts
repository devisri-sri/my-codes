class Employee{
  
    constructor(
        public empCode:number=101, 
        public empName:string="Smith", 
        public salary:number=10000.00, 
        public deptName:string="CompDept"
    ){}
}

let e1 = new Employee();
let e2 = new Employee(9332, "Peter", 19000.00, "AccDept");

console.log(e1);
console.log(e2);