var Person = /** @class */ (function () {
    function Person(fname, lname, gender, age) {
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.age = age;
    }
    Person.prototype.addPerson = function (fname, lname, gender, age) {
        this.fname = fname;
        this.lname = lname;
        this.gender = gender;
        this.age = age;
    };
    return Person;
}());
// let p1 = new Person();
// p1.addPerson("Smith", "Mathew", "Male", 37);
// console.log(p1);
var records = [
    new Person("Aditya", "Sinha", "Male", 28),
    new Person("Nikhil", "Tripathi", "Male", 22),
    new Person("Vishal", "Shah", "Male", 20)
];
var sorted = records.sort(function (f, s) {
    return f.age - s.age;
});
console.log(sorted);
