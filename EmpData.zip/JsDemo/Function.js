/*function greetMe(name,year){
    console.log("Hpapy New Year "+ year +" To: "+name);
    console.log("Type of year:"+typeof(year));
}
greetMe("devisri",2022);*/
//---------------2-------------------
/*var greetMe=function(name,year){
    console.log("Hpapy New Year "+ year +" To: "+name);
    console.log("Type of year:"+typeof(year));
}  
greetMe("sri",2022);*/
//-------------------3-------------
var greetMe= new Function("name","year", " console.log('Hpapy New Year '+ year + ' To: ' +name)"); 
    greetMe("devisri",2022);
    console.log("type of greetme:"+typeof(greetMe));
    var obj1= new Date();
    var obj2= new Array();
    var obj3=new String();
    console.log(typeof(obj1));
