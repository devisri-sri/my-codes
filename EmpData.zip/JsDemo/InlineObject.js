//object creation using object
var emp4=new Object();
emp4.empId=444;
emp4.empName="devisri";
emp4.empSal=4000.0;
emp4.dispEmpInfo=function(){
    console.log("ID:"+this.empId + " Name: "+this.empName+" Salary :"+this.empSal)
};
emp4.calcEmpAnnualSal=function(){
    return (this.empSal*12);
};
emp4.getEmpSal=function(){
    return this.empSal;
};
emp4.setEmpSal=function(sal){
    this.empSal=sal;
};
emp4.dispEmpInfo();
console.log("Annual salary of Emp4 :"+emp4.calcEmpAnnualSal());
    
//-----3 method---------
var emp5={
    "empId":555,
    "empName":"sai",
    "empSal":5000.0,
    "dispEmpInfo":function()
    {
        console.log("ID:"+this.empId + " Name: "+this.empName 
        + " salary :"+this.empSal)
    },
    "calcEmpAnnualSal":function()
    {
        return(this.empSal*12);
    }
}
emp5.dispEmpInfo();
console.log("Anuual salary of Emp5 :"+emp5.calcEmpAnnualSal());
