//--object  creation using -- constructor function syntax
function  Employee(eId,eName,eSal)
{
    this.empId=eId;
    this.empName=eName;
    this.empSal=eSal;
    this.dispEmpInfo=function()
    {
        console.log("ID :"+this.empId+ " Name : "+ 
        this.empName + " Salary : "+ this.empSal)
    }
    this.calcEmpAnnualSal= function()
    {
        return (this.empSal*12);
    }
    this.getEmpSal=function()
    {
        return this.empSal;
    }
    this.setEmpSal=function(sal)
    {
        this.empSal=sal;
    }

}

//-----------------------
var emp1=new Employee(111,"vaishaliS",1000.0);
var emp2=new Employee(222,"naveen",2000.0);
var emp3=new Employee(333,"Pradip",3000.0);
//------------------------------
emp1.dispEmpInfo();
console.log("Annual salry Of Emp1 :"+emp1.calcEmpAnnualSal());
emp2.dispEmpInfo()
console.log("Annual salry Of Emp2 :"+emp2.calcEmpAnnualSal());
emp3.dispEmpInfo()
console.log("Annual salry Of Emp3 :"+emp3.calcEmpAnnualSal());