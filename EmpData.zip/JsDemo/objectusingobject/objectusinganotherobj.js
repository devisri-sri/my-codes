//-----------Objec craetyion using Object---
var emp4=new Object();
emp4.empId=444;
emp4.empName="Ashika";
emp4.empSal=4000.0;
emp4.dispEmpInfo=function()
{
    console.log("ID :"+this.empId+ " Name : "+ 
    this.empName + " Salary : "+ this.empSal)
};
emp4.calcEmpAnnualSal= function()
{
    return (this.empSal*12);
};
emp4.getEmpSal=function()
{
    return this.empSal;
};
emp4.setEmpSal=function(sal)
{
    this.empSal=sal;
};
emp4.dispEmpInfo();
console.log("Annual salry Of Emp4:"+emp4.calcEmpAnnualSal());
var mgr4=Object.create(emp4);
mgr4.deptName="Admin";
mgr4.mgrComm=23000.0;
mgr4.dispMgrInfo=function()
{
    this.dispEmpInfo();
    console.log("Dept :"+this.deptName);
};
mgr4.dispMgrInfo();

//-----object creation using inline object  creation-------
/*
var emp5={
    "empId":555,
    "empName":"sameer",
    "empSal":5000.0,
    "dispEmpInfo":function()
                {
              console.log("ID :"+this.empId+ " Name : "+ 
              this.empName + " Salary : "+ this.empSal)
                },
    "calcEmpAnnualSal":function()
        {
             return (this.empSal*12);
        }        
}

emp5.dispEmpInfo();
console.log("Annual salry Of Emp4:"+emp5.calcEmpAnnualSal());

var mgr={
    "deptName": "IT",
    "mgrComm":200000.0,
   "dispMgrInfo":function()
    {
        this.dispEmpInfo();
        console.log( " Dept Name :"+
      this.deptName + " Commision : "+ this.mgrComm);
    },
   "calcMgrAnnualSal":function()
    {
        return (this.calcEmpAnnualSal()+this.mgrComm);
    }
}
mgr.__proto__=emp5;

mgr.dispMgrInfo();
console.log("Annual salry Of Emp5:"+mgr.calcMgrAnnualSal());
*/