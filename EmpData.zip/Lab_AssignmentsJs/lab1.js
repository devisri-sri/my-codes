const readlineSync =require("readline-sync");
function product()
{
    let productId=readlineSync.question('Enter Product id:');
    console.log(`Product Id ${productId}!`);
    let productName=readlineSync.question('Enter Product Name:');
    console.log(`Product Name is ${productName}!`);
    let productPrice=readlineSync.question('Enter Product price:');
    console.log(`Product price ios ${productPrice}!`);
    let productDescription=readlineSync.question('Enter Product Description:');
    console.log(`Product Id ${productDescription}!`);
    console.log(`print all product details: the product id is: ` + productId+" and name is:"+productName +" and price is:"+
    productPrice+" and description is:"+productDescription);
}
product();