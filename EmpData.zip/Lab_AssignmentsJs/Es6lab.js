var numsArr=[30,20,10,20];
for(num of numsArr){
    console.log(num);
}
//1.----adding element to to array using push--------
numsArr.push(80);
// console.log(numsArr);
// console.log(numsArr.join("-"));
// console.log(numsArr.reverse());
//2.-----deleting element from array--------------
// numsArr.splice(0,2);
//-----------deleting  based on condition using filter method----------
var filtered=numsArr.filter(function(value,index,arr){
    return  value >30; }
    );
    console.log(filtered);

    //------------update array---------