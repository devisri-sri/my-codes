package com.capgemini.in.demotuesdayboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemotuesdaybootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemotuesdaybootApplication.class, args);
	}

}
