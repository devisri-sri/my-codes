package com.cg.onlineshop.services;

import com.cg.onlineshop.beans.Cart;
import com.cg.onlineshop.beans.Product;

public interface CartService {
	public Cart addProductToCart(int cartCode, Product product);
	public Cart removeProductFromCart(int cartCode, Product product);
}