package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.beans.ProductReviews;
import com.netflix.discovery.EurekaClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class CartServiceController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	EurekaClient  eurekaClient;

	@PostMapping("/addProductToCart/{cartId}")
	public ResponseEntity<String> addProductToCart(@PathVariable("cartId" )int cartId, @ModelAttribute Product product){
		return 	null;
	}
	
	@HystrixCommand(fallbackMethod = "getGenericComments")
	@GetMapping("/getReviews/{id}")
	public ResponseEntity<List<String>> getPurchesedProductReviews(@PathVariable("id") int id){
		/*
		@SuppressWarnings("unchecked")
		List<String>  reviews= restTemplate.getForObject("http://localhost:9998/getProductReviews/"+ id, List.class);
		return new ResponseEntity<List<String>>(reviews,HttpStatus.OK);
		*/
		
		  //@SuppressWarnings("unchecked") 
		List<String> reviews= restTemplate.getForObject("http://PRODUCT-REVIEW-SERVICE/getProductReviews/"+ id, List.class); return new
		  ResponseEntity<List<String>>(reviews,HttpStatus.OK);
		 
	}

	public ResponseEntity<List<String>> getGenericComments(int id){ 
		 List<String> genericComments= new ArrayList<>(); 
		 genericComments.add("Reviews are not avaliable at current instance");  
		 return new ResponseEntity<List<String>>(genericComments,HttpStatus.OK); 
	 }
	
}
