package com.cg.onlineshop.services;

import com.cg.onlineshop.beans.Cart;
import com.cg.onlineshop.beans.Product;

public class CartServiceImpl implements CartService {
	public Cart addProductToCart(int cartCode, Product product) {
			return null;
	}
	public Cart removeProductFromCart(int cartCode, Product product) {
		return null;
	}
}
