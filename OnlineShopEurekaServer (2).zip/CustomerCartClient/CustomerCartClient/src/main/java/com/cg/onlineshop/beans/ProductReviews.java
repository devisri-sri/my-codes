package com.cg.onlineshop.beans;

import java.util.ArrayList;
import java.util.List;

public class ProductReviews {
	List<String> reviews;

	public ProductReviews() {
		super();
		this.reviews = new ArrayList<>();
	}

	public List<String> getReviews() {
		return reviews;
	}

	public void setReviews(List<String> reviews) {
		this.reviews = reviews;
	}
	
	
	
	
}
