import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertybinding',
  templateUrl: './propertybinding.component.html',
  styleUrls: ['./propertybinding.component.css']
})
export class PropertybindingComponent implements OnInit {

  public customId = "txtName";
  public isDisabled = false;

  resultPass = "text-success";
  resultFail = "text-danger";
  isError = true;

  myfavclasses = {
    "text-primary":true,
    "m-3":true,
    "p-2":true,
    "border":false,
    "border-warning":true
  }

  constructor() { }

  ngOnInit() {
  }

}
