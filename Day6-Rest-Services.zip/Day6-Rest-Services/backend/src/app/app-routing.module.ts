import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthorComponent } from './components/author/author.component';
import { BookComponent } from './components/book/book.component';
import { ReviewComponent } from './components/review/review.component';

const routes: Routes = [
  {path:'', redirectTo:'book',pathMatch:'full'},
  {path:'books', component:BookComponent},
  {path:'authors', component:AuthorComponent},
  {path:'reviews', component:ReviewComponent},
  {path:'**', redirectTo:'home'}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
