import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './bankapp/header/header.component';
import { HomeComponent } from './bankapp/home/home.component';
import { EmicalculatorComponent } from './bankapp/emicalculator/emicalculator.component';
import { ContactComponent } from './bankapp/contact/contact.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UseraccountComponent } from './useraccount/useraccount.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    EmicalculatorComponent,
    ContactComponent,
    UseraccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
