import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-useraccount',
  templateUrl: './useraccount.component.html',
  styleUrls: ['./useraccount.component.css']
})
export class UseraccountComponent implements OnInit {

  registrationForm = new FormGroup({
    
    txtName:new FormControl("Shrenik Shah"),

    education:new FormGroup({
      txtPrimaryEdu:new FormControl(""),
      txtHigherEdu:new FormControl("")
    }),

    address:new FormGroup({
      txtStreet:new FormControl(""),
      txtLocation:new FormControl(""),
      txtCity:new FormControl(""),
      txtPincode:new FormControl("")
    }),

    txtEmailId:new FormControl("shrenik1919@gmail.com"),

    contact:new FormGroup({
      txtOfficeContact:new FormControl(""),
      txtPersonalContact:new FormControl("")
    })

  })

  constructor() { }

  ngOnInit() {
  }

}
