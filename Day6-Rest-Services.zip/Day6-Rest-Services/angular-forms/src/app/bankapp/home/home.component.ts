import { Component, OnInit } from '@angular/core';
import loanDetails from '../fakedatabase/database';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public loandata = loanDetails();
  
  constructor() { }

  ngOnInit() {
    console.log("fetching database records...");
    console.log(this.loandata);
  }

}
