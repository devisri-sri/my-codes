
class UserAccount
{
    constructor(
        public fname:string="",
        public lname:string="",
        public emailid:string="",
        public contactno:string="",
        public whatsapp:string=""
    ){}
}

export default UserAccount;