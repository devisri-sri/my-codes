
class LoanType
{
    constructor(
        public id=-1,
        public imgURL="",
        public loanTitle="",
        public descr=""
    ){}
}

let loanDetails = ()=>{
    let loan_data = [
        new LoanType(191, "https://img.freepik.com/free-vector/financial-obligation-document-promissory-bill-loan-agreement-debt-return-promise-issuer-payee-signing-contract-businessmen-making-deal_335657-848.jpg?size=338&ext=jpg", "Home Loan", "In publishing and graphic design, Lorem ipsum is a placeholder text"),
        new LoanType(192, "https://media.istockphoto.com/vectors/venture-capital-icon-vector-id1164213745?k=20&m=1164213745&s=612x612&w=0&h=00scK-CuHb6-5mQF-V2gXdyAsc3KKQqYxPC_wjYHzV4=", "Car Loan", "commonly used to demonstrate the visual form of a document or a"),
        new LoanType(193, "https://media.istockphoto.com/vectors/banker-offering-loan-vector-id1289188746?k=20&m=1289188746&s=612x612&w=0&h=6MSM_-wlx65hioF2ZL-tWtkQLTflMU9A7KuKNiKOVa0=", "Gold Loan", "Lorem ipsum may be used as a placeholder before the final copy is")
    ];

    return loan_data;
}

export default loanDetails;