import { Component, OnInit } from '@angular/core';
import UserAccount from '../fakedatabase/user';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  public usercAcc:UserAccount = new UserAccount();

  constructor() { }

  ngOnInit() {
  }

  createObject(formObject){
    console.log(formObject.value);
    this.usercAcc = new UserAccount(
      formObject.value["txtFname"],
      formObject.value["txtLname"],
      formObject.value["txtEmailId"],
      formObject.value["txtContactNo"],
      formObject.value["txtWhatsApp"]
    )
  }

}
