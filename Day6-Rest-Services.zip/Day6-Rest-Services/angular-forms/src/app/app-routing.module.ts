import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './bankapp/contact/contact.component';
import { EmicalculatorComponent } from './bankapp/emicalculator/emicalculator.component';
import { HomeComponent } from './bankapp/home/home.component';
import { UseraccountComponent } from './useraccount/useraccount.component';

const routes: Routes = [
  {path:'', redirectTo:'home',pathMatch:'full'},
  {path:'home', component:HomeComponent},
  {path:'emi', component:EmicalculatorComponent},
  {path:'contact', component:ContactComponent},
  {path:'form2', component:UseraccountComponent},
  {path:'**', redirectTo:'home'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
